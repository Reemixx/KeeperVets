/**
 * Client de l'API publique Fantrax (aucune authentification requise).
 *
 * Points d'attention encodés ici :
 * - getPlayerIds renvoie les noms au format « Nom, Prénom » ;
 * - getPlayerIds ne contient PAS l'identifiant NHL officiel ;
 * - les statuts observés hors-saison sont ACTIVE et MINORS. La valeur exacte
 *   du statut de blessé en saison est inconnue : elle est donc traitée en aval
 *   par un mapping configurable, jamais codée en dur.
 */

import { inverserNomFantrax, normaliser } from "../domain/noms.js";
import { normaliserPeriode, type Periode } from "../domain/periodes.js";
import type { FicheJoueur, LigneRoster } from "../domain/types.js";
import { recupererJson, type Resultat } from "./http.js";

const BASE = "https://www.fantrax.com/fxea/general";

interface ReponseRosters {
  period?: number;
  rosters?: Record<
    string,
    { teamName?: string; rosterItems?: { id?: string; position?: string; status?: string }[] }
  >;
}

interface ReponsePlayerIds {
  [fantraxId: string]: {
    name?: string;
    team?: string;
    position?: string;
  };
}

interface LigneClassement {
  teamName?: string;
  teamId?: string;
  rank?: number;
  points?: number;
}

/** Alignements complets de la ligue. */
export interface Alignements {
  periode: number | null;
  equipes: { teamId: string; nom: string }[];
  lignes: LigneRoster[];
}

/** Lit les alignements des 13 équipes du pool. */
export async function lireAlignements(
  leagueId: string,
): Promise<Resultat<Alignements>> {
  const reponse = await recupererJson<ReponseRosters>(
    `${BASE}/getTeamRosters?leagueId=${encodeURIComponent(leagueId)}`,
    { timeoutMs: 40_000 },
  );
  if (!reponse.ok) return reponse;

  const equipes: { teamId: string; nom: string }[] = [];
  const lignes: LigneRoster[] = [];

  for (const [teamId, equipe] of Object.entries(reponse.valeur.rosters ?? {})) {
    const nomEquipe = equipe?.teamName?.trim() || teamId;
    equipes.push({ teamId, nom: nomEquipe });

    for (const item of equipe?.rosterItems ?? []) {
      if (!item?.id) continue;
      lignes.push({
        fantraxId: String(item.id),
        teamId,
        teamName: nomEquipe,
        position: (item.position ?? "").trim(),
        // On conserve la valeur brute : c'est le mapping configurable qui
        // décidera de son sens métier.
        statutBrut: (item.status ?? "").trim().toUpperCase() || "INDEFINI",
      });
    }
  }

  return {
    ok: true,
    valeur: {
      periode: typeof reponse.valeur.period === "number" ? reponse.valeur.period : null,
      equipes,
      lignes,
    },
  };
}

/**
 * Lit le référentiel des joueurs NHL de Fantrax et rétablit l'ordre
 * « Prénom Nom » des noms.
 *
 * ⚠️ Ce référentiel contient près de 9000 joueurs, alors que le pool n'en
 * compte que quelques centaines. Normaliser l'ensemble coûterait une dizaine de
 * millisecondes de temps processeur, soit la totalité du budget d'une exécution
 * sur le plan gratuit de Cloudflare. On filtre donc AVANT de normaliser.
 *
 * `idsRecherches` restreint le traitement aux joueurs réellement utiles ;
 * omettre ce paramètre traite tout le référentiel.
 */
export async function lireFichesJoueurs(
  idsRecherches?: ReadonlySet<string>,
): Promise<Resultat<Map<string, FicheJoueur>>> {
  const reponse = await recupererJson<ReponsePlayerIds>(
    `${BASE}/getPlayerIds?sport=NHL`,
    { timeoutMs: 90_000 },
  );
  if (!reponse.ok) return reponse;

  const fiches = new Map<string, FicheJoueur>();
  const referentiel = reponse.valeur ?? {};

  const ajouter = (fantraxId: string, brut: ReponsePlayerIds[string]) => {
    if (!brut || typeof brut !== "object") return;
    const nom = inverserNomFantrax(brut.name);
    if (!nom) return;
    fiches.set(fantraxId, {
      fantraxId,
      nom,
      nomNormalise: normaliser(nom),
      equipeNhl: brut.team?.trim() || null,
      position: brut.position?.trim() || null,
    });
  };

  if (idsRecherches) {
    // Accès direct par clé : parcourir le référentiel entier pour n'en garder
    // que quelques centaines coûterait plusieurs millisecondes de processeur.
    for (const fantraxId of idsRecherches) {
      const brut = referentiel[fantraxId];
      if (brut) ajouter(fantraxId, brut);
    }
  } else {
    for (const [fantraxId, brut] of Object.entries(referentiel)) {
      ajouter(fantraxId, brut);
    }
  }

  return { ok: true, valeur: fiches };
}

/** Lit le classement de la ligue (rang et points par équipe). */
export async function lireClassement(
  leagueId: string,
): Promise<Resultat<{ teamId: string; nom: string; rang: number | null; points: number | null }[]>> {
  const reponse = await recupererJson<LigneClassement[] | { standings?: LigneClassement[] }>(
    `${BASE}/getStandings?leagueId=${encodeURIComponent(leagueId)}`,
  );
  if (!reponse.ok) return reponse;

  // L'API renvoie normalement un tableau ; on tolère une enveloppe objet.
  const brut = Array.isArray(reponse.valeur)
    ? reponse.valeur
    : (reponse.valeur?.standings ?? []);

  const classement = brut
    .filter((l) => l && typeof l.teamId === "string")
    .map((l) => ({
      teamId: l.teamId as string,
      nom: l.teamName?.trim() || (l.teamId as string),
      rang: typeof l.rank === "number" ? l.rank : null,
      points: typeof l.points === "number" ? l.points : null,
    }));

  return { ok: true, valeur: classement };
}

/** Calendrier de la ligue : bornes de saison et périodes de roster. */
export interface CalendrierLigue {
  nomLigue: string | null;
  saison: number | null;
  debutSaison: string | null;
  finSaison: string | null;
  periodes: Periode[];
}

/**
 * Lit le calendrier de la ligue.
 *
 * ⚠️ getLeagueInfo est volumineux (environ 386 Ko, il embarque le référentiel
 * complet des joueurs). Les périodes ne changent pas en cours de saison : cet
 * appel n'a donc pas à être répété à chaque exécution du robot.
 */
export async function lireCalendrier(
  leagueId: string,
  fuseau = "America/Toronto",
): Promise<Resultat<CalendrierLigue>> {
  const reponse = await recupererJson<{
    leagueName?: string;
    seasonYear?: number;
    startDate?: string;
    endDate?: string;
    rosterPeriods?: { number?: number; startDate?: string; endDate?: string }[];
  }>(`${BASE}/getLeagueInfo?leagueId=${encodeURIComponent(leagueId)}`, {
    timeoutMs: 120_000,
  });
  if (!reponse.ok) return reponse;

  const periodes = (reponse.valeur.rosterPeriods ?? [])
    .map((p) => normaliserPeriode(p, fuseau))
    .filter((p): p is Periode => p !== null)
    .sort((a, b) => a.numero - b.numero);

  if (periodes.length === 0) {
    return { ok: false, erreur: "aucune période de roster dans getLeagueInfo" };
  }

  return {
    ok: true,
    valeur: {
      nomLigue: reponse.valeur.leagueName?.trim() ?? null,
      saison: typeof reponse.valeur.seasonYear === "number" ? reponse.valeur.seasonYear : null,
      debutSaison: reponse.valeur.startDate ?? null,
      finSaison: reponse.valeur.endDate ?? null,
      periodes,
    },
  };
}
