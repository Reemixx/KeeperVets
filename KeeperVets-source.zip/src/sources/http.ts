/**
 * Utilitaire d'appel HTTP tolérant aux pannes.
 *
 * Principe directeur de l'application : si une source externe ne répond pas,
 * on le signale et on conserve les dernières données connues. On ne lève
 * jamais d'exception qui ferait échouer l'ensemble d'une exécution.
 */

import { CONFIG } from "../config.js";

/** Résultat d'un appel réseau : soit une valeur, soit une erreur décrite. */
export type Resultat<T> =
  | { ok: true; valeur: T }
  | { ok: false; erreur: string };

/**
 * Récupère et désérialise un JSON.
 * Applique un délai maximal et une nouvelle tentative sur erreur transitoire.
 */
export async function recupererJson<T>(
  url: string,
  options: { timeoutMs?: number; tentatives?: number } = {},
): Promise<Resultat<T>> {
  const timeoutMs = options.timeoutMs ?? CONFIG.timeoutMs;
  const tentatives = options.tentatives ?? 2;

  let derniereErreur = "erreur inconnue";

  for (let essai = 1; essai <= tentatives; essai++) {
    const minuteur = new AbortController();
    const chrono = setTimeout(() => minuteur.abort(), timeoutMs);
    try {
      const reponse = await fetch(url, {
        signal: minuteur.signal,
        headers: {
          accept: "application/json",
          // Certaines API publiques refusent les requêtes sans agent utilisateur.
          "user-agent": "KeeperVets/0.1 (outil d'administration de pool)",
        },
      });

      if (!reponse.ok) {
        derniereErreur = `HTTP ${reponse.status} ${reponse.statusText}`;
        // Une erreur 4xx ne se corrigera pas en réessayant.
        if (reponse.status >= 400 && reponse.status < 500) {
          return { ok: false, erreur: derniereErreur };
        }
      } else {
        const valeur = (await reponse.json()) as T;
        return { ok: true, valeur };
      }
    } catch (e) {
      derniereErreur =
        e instanceof Error ? `${e.name}: ${e.message}` : String(e);
    } finally {
      clearTimeout(chrono);
    }

    if (essai < tentatives) await pause(400 * essai);
  }

  return { ok: false, erreur: derniereErreur };
}

/** Petite pause, utilisée pour espacer les appels aux API publiques. */
export function pause(ms: number): Promise<void> {
  return new Promise((resoudre) => setTimeout(resoudre, ms));
}
