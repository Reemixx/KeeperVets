/**
 * Client des API publiques de la LNH.
 *
 * ⚠️ search.nhle.com est bloqué par le DNS du réseau corporatif : ce point de
 * terminaison n'est délibérément PAS utilisé ici. Le filet de sécurité pour
 * les joueurs non appariés est records.nhl.com.
 *
 * Stratégie d'appariement validée : construire un dictionnaire
 * « nom normalisé -> identifiant NHL » à partir des 32 alignements et des
 * 32 listes d'espoirs (environ 1690 joueurs).
 */

import { cleFamilleEquipe, expressionRecherchRecords, variantesNormalisees } from "../domain/noms.js";
import { recupererJson, type Resultat } from "./http.js";

const API = "https://api-web.nhle.com/v1";
const RECORDS = "https://records.nhl.com/site/api";

interface JoueurNhl {
  id?: number;
  firstName?: { default?: string };
  lastName?: { default?: string };
}

interface ReponseGroupes {
  forwards?: JoueurNhl[];
  defensemen?: JoueurNhl[];
  goalies?: JoueurNhl[];
}

interface ReponseClassement {
  standings?: { teamAbbrev?: { default?: string } }[];
}

interface ReponseFiche {
  careerTotals?: { regularSeason?: { gamesPlayed?: number } };
  position?: string;
}

/** Genre de source de joueurs pour une équipe NHL. */
export type GenreSource = "roster" | "prospects";

/** Une entrée du dictionnaire d'appariement. */
export interface EntreeIndex {
  /** Toutes les formes normalisées du nom complet. */
  variantes: string[];
  /** Clé de repli « équipe|nom de famille ». */
  cleFamille: string;
  nhlPlayerId: number;
}

/** Lit les 32 codes d'équipe de la LNH. */
export async function lireCodesEquipes(): Promise<Resultat<string[]>> {
  const reponse = await recupererJson<ReponseClassement>(`${API}/standings/now`, {
    timeoutMs: 40_000,
  });
  if (!reponse.ok) return reponse;

  const codes = [
    ...new Set(
      (reponse.valeur.standings ?? [])
        .map((e) => e.teamAbbrev?.default?.trim())
        .filter((c): c is string => Boolean(c)),
    ),
  ].sort();

  if (codes.length === 0) {
    return { ok: false, erreur: "aucun code d'équipe dans le classement NHL" };
  }
  return { ok: true, valeur: codes };
}

/**
 * Lit les joueurs d'une équipe : alignement courant ou liste d'espoirs.
 * Les espoirs sont essentiels : ils couvrent les joueurs pas encore établis
 * dans la LNH, très fréquents dans les slots farm.
 */
export async function lireJoueursEquipe(
  tri: string,
  genre: GenreSource,
): Promise<Resultat<EntreeIndex[]>> {
  const url =
    genre === "roster"
      ? `${API}/roster/${tri}/current`
      : `${API}/prospects/${tri}`;

  const reponse = await recupererJson<ReponseGroupes>(url, { timeoutMs: 30_000 });
  if (!reponse.ok) return reponse;

  const entrees: EntreeIndex[] = [];
  for (const groupe of ["forwards", "defensemen", "goalies"] as const) {
    for (const joueur of reponse.valeur[groupe] ?? []) {
      if (!joueur?.id) continue;
      const nomComplet = `${joueur.firstName?.default ?? ""} ${joueur.lastName?.default ?? ""}`;
      const variantes = variantesNormalisees(nomComplet);
      if (variantes.length === 0) continue;
      entrees.push({
        variantes,
        cleFamille: cleFamilleEquipe(tri, joueur.lastName?.default ?? nomComplet),
        nhlPlayerId: Number(joueur.id),
      });
    }
  }

  return { ok: true, valeur: entrees };
}

/**
 * Lit le nombre de parties de saison régulière jouées en carrière.
 *
 * Le champ peut être absent (joueur n'ayant jamais disputé de match dans la
 * LNH) : dans ce cas la valeur 0 est correcte et volontaire.
 * Un échec d'appel, lui, retourne une erreur — surtout pas 0.
 */
export async function lirePartiesCarriere(
  nhlPlayerId: number,
): Promise<Resultat<number>> {
  const reponse = await recupererJson<ReponseFiche>(
    `${API}/player/${nhlPlayerId}/landing`,
    { timeoutMs: 25_000 },
  );
  if (!reponse.ok) return reponse;

  const parties = reponse.valeur.careerTotals?.regularSeason?.gamesPlayed;
  return { ok: true, valeur: typeof parties === "number" ? parties : 0 };
}

/**
 * Filet de sécurité pour un joueur absent du dictionnaire :
 * recherche par nom complet dans les archives de la LNH.
 */
export async function chercherDansRecords(
  nom: string,
): Promise<Resultat<number | null>> {
  const expression = encodeURIComponent(expressionRecherchRecords(nom));
  const reponse = await recupererJson<{ data?: { id?: number }[] }>(
    `${RECORDS}/player?cayenneExp=${expression}`,
    { timeoutMs: 25_000 },
  );
  if (!reponse.ok) return reponse;

  const premier = reponse.valeur.data?.[0]?.id;
  return { ok: true, valeur: typeof premier === "number" ? premier : null };
}
