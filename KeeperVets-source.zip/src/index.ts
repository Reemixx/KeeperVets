/**
 * Point d'entrée du Worker.
 *
 * - `fetch`     : sert l'API. Les fichiers statiques de public/ sont servis
 *                 en amont par la couche « assets » de Cloudflare.
 * - `scheduled` : exécute le robot de synchronisation (Cron, aux 2 heures).
 */

import type { Env } from "./config.js";
import { router } from "./api/routes.js";
import { executerRobot } from "./robot/synchroniser.js";

export default {
  async fetch(requete: Request, env: Env, ctx: ExecutionContext): Promise<Response> {
    const url = new URL(requete.url);

    if (url.pathname.startsWith("/api/")) {
      try {
        return await router(requete, env, ctx);
      } catch (e) {
        // Aucune erreur ne doit faire tomber l'application : on renvoie un
        // message exploitable et on journalise la trace complète.
        console.error("[api] erreur non gérée", e);
        return new Response(
          JSON.stringify({
            erreur: "Erreur interne. Les dernières données connues restent disponibles.",
            detail: e instanceof Error ? e.message : String(e),
          }),
          { status: 500, headers: { "content-type": "application/json; charset=utf-8" } },
        );
      }
    }

    // Chemin non-API et non couvert par un fichier statique.
    return new Response("Page introuvable", { status: 404 });
  },

  async scheduled(evenement: ScheduledController, env: Env, ctx: ExecutionContext): Promise<void> {
    ctx.waitUntil(
      executerRobot(env, { declencheur: "cron" }).then((bilan) => {
        console.log(
          `[cron] exécution ${bilan.executionId} : ` +
            `succès=${bilan.succes} joueurs=${bilan.joueursVus} ` +
            `IR ouverts=${bilan.irOuverts} fermés=${bilan.irFermes} ` +
            `retours prématurés=${bilan.retoursPrematures} ` +
            `PJ rafraîchies=${bilan.pjRafraichies}`,
        );
      }),
    );
  },
} satisfies ExportedHandler<Env>;
