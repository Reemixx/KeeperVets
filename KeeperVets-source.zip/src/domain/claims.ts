/**
 * Suivi des claims (transactions) par équipe.
 *
 * Chaque équipe dispose de 4 claims par saison. Particularité de la ligue :
 * les claims s'échangent entre poolers, ce qui fait qu'un solde peut dépasser
 * 4 ou descendre en dessous.
 *
 * Le suivi repose sur un grand livre : le solde n'est jamais stocké, il est
 * toujours recalculé à partir des mouvements. Un solde est ainsi toujours
 * explicable, ce qui compte quand un pooler conteste son compte.
 *
 * Module pur : aucune dépendance réseau ni base de données.
 */

/** Nombre de claims alloués à chaque équipe au début de la saison. */
export const CLAIMS_PAR_SAISON = 4;

/** Nature d'un mouvement au grand livre. */
export type TypeMouvementClaim =
  | "ALLOCATION" // dotation de début de saison
  | "UTILISE" // claim consommé par une acquisition
  | "RECU" // claim obtenu d'une autre équipe
  | "CEDE" // claim donné à une autre équipe
  | "CORRECTION"; // ajustement manuel d'un administrateur

export interface MouvementClaim {
  teamId: string;
  type: TypeMouvementClaim;
  quantite: number;
}

/** Solde et ventilation d'une équipe. */
export interface SoldeClaims {
  teamId: string;
  solde: number;
  alloues: number;
  utilises: number;
  recus: number;
  cedes: number;
  corrections: number;
}

/** Somme des mouvements d'une équipe. */
export function calculerSolde(mouvements: readonly MouvementClaim[]): number {
  return mouvements.reduce((total, m) => total + m.quantite, 0);
}

/** Ventile les mouvements par équipe, avec le détail par nature. */
export function resumerParEquipe(
  mouvements: readonly MouvementClaim[],
): Map<string, SoldeClaims> {
  const resume = new Map<string, SoldeClaims>();

  for (const m of mouvements) {
    let ligne = resume.get(m.teamId);
    if (!ligne) {
      ligne = {
        teamId: m.teamId,
        solde: 0,
        alloues: 0,
        utilises: 0,
        recus: 0,
        cedes: 0,
        corrections: 0,
      };
      resume.set(m.teamId, ligne);
    }

    ligne.solde += m.quantite;
    switch (m.type) {
      case "ALLOCATION":
        ligne.alloues += m.quantite;
        break;
      case "UTILISE":
        // Compté en valeur absolue : « 2 claims utilisés » se lit mieux que « -2 ».
        ligne.utilises += Math.abs(m.quantite);
        break;
      case "RECU":
        ligne.recus += m.quantite;
        break;
      case "CEDE":
        ligne.cedes += Math.abs(m.quantite);
        break;
      case "CORRECTION":
        ligne.corrections += m.quantite;
        break;
    }
  }

  return resume;
}

/** Niveau d'alerte associé à un solde de claims. */
export type NiveauClaims =
  | "NON_DOTE" // la dotation de début de saison n'a pas encore eu lieu
  | "NEGATIF"
  | "EPUISE"
  | "DERNIER"
  | "FAIBLE"
  | "OK";

/**
 * Classe un solde.
 * `dote` distingue une équipe réellement à court de claims d'une équipe qui
 * n'a simplement pas encore reçu sa dotation de début de saison — les deux
 * affichent zéro, mais n'appellent pas du tout la même réaction.
 */
export function niveauPourSolde(solde: number, dote = true): NiveauClaims {
  if (!dote) return "NON_DOTE";
  if (solde < 0) return "NEGATIF";
  if (solde === 0) return "EPUISE";
  if (solde === 1) return "DERNIER";
  if (solde === 2) return "FAIBLE";
  return "OK";
}

/** Libellé français court, avec pastille, pour l'interface. */
export function libelleNiveauClaims(niveau: NiveauClaims): string {
  switch (niveau) {
    case "NON_DOTE":
      return "⏳ Pas encore doté";
    case "NEGATIF":
      return "⛔ Solde négatif";
    case "EPUISE":
      return "🔴 Épuisé";
    case "DERNIER":
      return "🟡 Dernier claim";
    case "FAIBLE":
      return "🟡 Il en reste 2";
    case "OK":
      return "✅ OK";
  }
}

/**
 * Valide un échange de claims entre deux équipes.
 * Une équipe ne peut pas céder plus de claims qu'elle n'en possède : sans cette
 * règle, un solde négatif passerait inaperçu jusqu'à la prochaine transaction.
 */
export function validerEchange(params: {
  deTeamId: string;
  versTeamId: string;
  quantite: number;
  soldeSource: number;
}): { ok: true } | { ok: false; erreur: string } {
  const { deTeamId, versTeamId, quantite, soldeSource } = params;

  if (!deTeamId || !versTeamId) {
    return { ok: false, erreur: "Les deux équipes doivent être précisées." };
  }
  if (deTeamId === versTeamId) {
    return { ok: false, erreur: "Une équipe ne peut pas s'échanger un claim à elle-même." };
  }
  if (!Number.isInteger(quantite) || quantite <= 0) {
    return { ok: false, erreur: "La quantité doit être un nombre entier positif." };
  }
  if (quantite > soldeSource) {
    return {
      ok: false,
      erreur:
        `L'équipe cédante n'a que ${soldeSource} claim${soldeSource > 1 ? "s" : ""} : ` +
        `elle ne peut pas en céder ${quantite}.`,
    };
  }

  return { ok: true };
}

/**
 * Message prêt à coller pour aviser un pooler de l'état de ses claims.
 */
export function messageClaims(equipe: string, solde: number, dote = true): string {
  if (!dote) {
    return (
      `Salut, petit suivi : la dotation de claims de ${equipe} n'a pas encore été ` +
      `distribuée pour la saison.`
    );
  }
  if (solde < 0) {
    return (
      `Salut, petit suivi : le compte de claims de ${equipe} est à ${solde}, ` +
      `donc en déficit. Il faut qu'on régularise ça ensemble.`
    );
  }
  if (solde === 0) {
    return (
      `Salut, petit suivi : ${equipe} n'a plus de claim disponible pour la saison. ` +
      `Il faudra en obtenir d'un autre pooler pour faire une nouvelle acquisition.`
    );
  }
  const pluriel = solde > 1 ? "s" : "";
  return (
    `Salut, petit suivi : il reste ${solde} claim${pluriel} à ${equipe} pour la saison.`
  );
}
