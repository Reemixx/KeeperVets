/**
 * Types partagés de l'application.
 */

/** Sens métier d'un statut brut reçu de Fantrax. */
export type TypeStatut = "ACTIF" | "FARM" | "IR" | "INCONNU";

/** Niveau d'alerte d'admissibilité farm, du plus grave au plus bénin. */
export type NiveauFarm =
  | "DEPASSE" // ⛔ seuil franchi : retrait immédiat requis
  | "URGENT" // 🔴 5 parties ou moins de marge
  | "CRITIQUE" // 🔴 10 parties ou moins
  | "SURVEILLER" // 🟡 30 parties ou moins
  | "OK" // ✅ marge confortable
  | "A_VERIFIER"; // ❔ parties jouées inconnues (appariement ou API en échec)

/** État d'un séjour sur la liste des blessés au regard de la règle des 10 jours. */
export type StatutIR =
  | "BLOQUE" // 🔴 doit rester sur IR
  | "ELIGIBLE_DEMAIN" // 🟡 dernière journée d'attente
  | "ELIGIBLE" // 🟢 peut être réactivé
  | "RETOUR_PREMATURE"; // ⚠️ réactivé avant la fin des 10 jours : infraction

/** Une ligne d'alignement telle que renvoyée par Fantrax. */
export interface LigneRoster {
  fantraxId: string;
  teamId: string;
  teamName: string;
  position: string;
  statutBrut: string;
}

/** Fiche d'identité d'un joueur issue de getPlayerIds. */
export interface FicheJoueur {
  fantraxId: string;
  nom: string; // « Prénom Nom »
  nomNormalise: string;
  equipeNhl: string | null;
  position: string | null;
}

/** Un joueur occupant un slot farm, avec son évaluation d'admissibilité. */
export interface LigneFarm {
  fantraxId: string;
  nom: string;
  equipePool: string;
  equipeNhl: string | null;
  position: string;
  seuil: number;
  partiesJouees: number | null;
  reste: number | null;
  niveau: NiveauFarm;
  nhlPlayerId: number | null;
  sourceAppariement: string | null;
  pjRecupereeLe: string | null;
}

/** Un séjour sur IR enrichi pour l'affichage. */
export interface LigneBlesse {
  id: number;
  fantraxId: string;
  nom: string;
  equipePool: string;
  position: string | null;
  dateIr: string;
  dateIrDetectee: string;
  dateEligibilite: string;
  jourCourant: number;
  statut: StatutIR;
  ouvert: boolean;
  dateRetour: string | null;
  retourPremature: boolean;
  joursManquants: number | null;
  corrigePar: string | null;
  corrigeLe: string | null;
  note: string | null;
}
