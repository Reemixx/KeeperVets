/**
 * Périodes de roster Fantrax.
 *
 * Une période est la fenêtre pendant laquelle un alignement est figé. Fantrax
 * en compte 194 pour la saison 2026-2027, du 29 septembre au 10 avril.
 *
 * Règle métier centrale : la date de mise sur la liste des blessés est la
 * **date de début de la période** durant laquelle le mouvement a été fait,
 * et non la date calendaire à laquelle le robot l'a constaté. Un joueur placé
 * sur IR pendant la période 1 est réputé mis sur IR le 29 septembre, même si
 * l'administrateur a fait le mouvement plus tôt.
 *
 * Module pur : aucune dépendance réseau ni base de données.
 */

/** Une période de roster, telle que conservée par l'application. */
export interface Periode {
  numero: number;
  /** Début, en ISO 8601 avec décalage horaire. */
  debut: string;
  /** Fin, en ISO 8601 avec décalage horaire. */
  fin: string;
  /** Date civile du début, au format YYYY-MM-DD. */
  dateDebut: string;
  debutMs: number;
  finMs: number;
}

/**
 * Extrait la date civile d'un horodatage Fantrax.
 *
 * Fantrax renvoie ses dates avec un décalage explicite
 * (« 2026-09-29T17:00:00-04:00 ») : les dix premiers caractères sont déjà la
 * date locale recherchée. Un horodatage en UTC (« ...Z ») est en revanche
 * converti vers le fuseau de la ligue, sans quoi une soirée de match
 * basculerait au lendemain.
 */
export function dateCivile(horodatage: string, fuseau = "America/Toronto"): string {
  const brut = horodatage.trim();

  // Décalage explicite non nul : la partie date est déjà locale.
  if (/[+-]\d{2}:?\d{2}$/.test(brut)) return brut.slice(0, 10);

  const instant = new Date(brut);
  if (Number.isNaN(instant.getTime())) {
    throw new Error(`Horodatage de période illisible : « ${horodatage} »`);
  }
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: fuseau,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(instant);
}

/** Convertit une période brute de Fantrax en période applicative. */
export function normaliserPeriode(
  brute: { number?: number; startDate?: string; endDate?: string },
  fuseau = "America/Toronto",
): Periode | null {
  if (
    typeof brute?.number !== "number" ||
    !brute.startDate ||
    !brute.endDate
  ) {
    return null;
  }

  const debutMs = Date.parse(brute.startDate);
  const finMs = Date.parse(brute.endDate);
  if (Number.isNaN(debutMs) || Number.isNaN(finMs)) return null;

  return {
    numero: brute.number,
    debut: brute.startDate,
    fin: brute.endDate,
    dateDebut: dateCivile(brute.startDate, fuseau),
    debutMs,
    finMs,
  };
}

/**
 * Détermine la période applicable à un instant donné.
 *
 * - Avant le début de la saison, c'est la première période qui s'applique :
 *   un mouvement fait hors-saison ne prend effet qu'à l'ouverture.
 * - Entre deux périodes (les bornes ne sont pas jointives à la seconde près),
 *   c'est la période suivante qui est retenue.
 * - Après la fin de la saison, c'est la dernière période.
 *
 * Retourne null si aucune période n'est connue.
 */
export function periodePourInstant(
  periodes: readonly Periode[],
  instantMs: number,
): Periode | null {
  if (periodes.length === 0) return null;

  const triees = [...periodes].sort((a, b) => a.debutMs - b.debutMs);
  const premiere = triees[0] as Periode;
  const derniere = triees[triees.length - 1] as Periode;

  if (instantMs < premiere.debutMs) return premiere;
  if (instantMs > derniere.finMs) return derniere;

  for (const periode of triees) {
    if (instantMs >= periode.debutMs && instantMs <= periode.finMs) {
      return periode;
    }
  }

  // Interstice entre deux périodes : on retient la suivante.
  return triees.find((p) => p.debutMs > instantMs) ?? derniere;
}

/**
 * Date à retenir comme date de mise sur la liste des blessés.
 * Repli sur la date calendaire fournie si aucune période n'est connue —
 * l'application doit rester fonctionnelle même sans les périodes.
 */
export function dateIrDepuisPeriode(
  periodes: readonly Periode[],
  instantMs: number,
  dateDeRepli: string,
): { dateIr: string; periode: number | null } {
  const periode = periodePourInstant(periodes, instantMs);
  if (!periode) return { dateIr: dateDeRepli, periode: null };
  return { dateIr: periode.dateDebut, periode: periode.numero };
}
