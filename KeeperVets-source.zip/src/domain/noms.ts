/**
 * Normalisation et appariement des noms de joueurs.
 *
 * Stratégie validée par la preuve de concept (reference/poc-farm-VALIDE.ps1) :
 * les 72 joueurs en slot farm ont tous été appariés avec cette normalisation.
 * Ne pas la modifier sans revalider l'appariement complet.
 */

/**
 * Normalise un nom pour la comparaison :
 * décomposition NFD, retrait des diacritiques, minuscules,
 * on ne garde que les lettres a-z et les espaces, espaces réduits à un seul.
 *
 * Exemple : « Tomáš Hertl » -> « tomas hertl »
 */
export function normaliser(valeur: string | null | undefined): string {
  if (!valeur) return "";
  return valeur
    .normalize("NFD")
    .replace(/\p{Mn}/gu, "") // retire les marques diacritiques (accents)
    .toLowerCase()
    .replace(/[^a-z ]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

/**
 * Toutes les clés sous lesquelles un nom doit pouvoir être retrouvé.
 *
 * Fantrax et la LNH n'orthographient pas toujours les noms composés de la même
 * façon : « Axel Sandin-Pellikka » côté LNH contre « Axel Sandin Pellikka »
 * côté Fantrax. La normalisation de base supprime le trait d'union sans le
 * remplacer, ce qui produit deux clés incompatibles
 * (« sandinpellikka » et « sandin pellikka »).
 * On indexe donc les deux formes.
 */
export function variantesNormalisees(valeur: string | null | undefined): string[] {
  if (!valeur) return [];
  const separateursEnEspaces = valeur.replace(/[-'’.]/g, " ");
  const variantes = new Set(
    [normaliser(valeur), normaliser(separateursEnEspaces)].filter(
      (v) => v.length > 0,
    ),
  );
  return [...variantes];
}

/**
 * Dernier segment du nom, utilisé comme clé de repli « nom de famille ».
 * Les traits d'union sont convertis en espaces au préalable, de sorte que
 * « Sandin-Pellikka » et « Sandin Pellikka » donnent tous deux « pellikka ».
 */
export function nomDeFamille(valeur: string | null | undefined): string {
  const normalise = normaliser((valeur ?? "").replace(/[-'’.]/g, " "));
  if (!normalise) return "";
  const morceaux = normalise.split(" ");
  return morceaux[morceaux.length - 1] ?? "";
}

/**
 * Clé de repli combinant l'équipe NHL et le nom de famille.
 * Elle n'est exploitée que si elle désigne un joueur unique dans l'équipe :
 * deux frères dans la même formation (les Hughes au New Jersey, par exemple)
 * rendraient l'appariement ambigu.
 */
export function cleFamilleEquipe(
  tri: string | null | undefined,
  nom: string | null | undefined,
): string {
  const famille = nomDeFamille(nom);
  const equipe = (tri ?? "").trim().toUpperCase();
  if (!famille || !equipe) return "";
  return `${equipe}|${famille}`;
}

/**
 * Fantrax renvoie les noms au format « Nom, Prénom ».
 * Cette fonction rétablit l'ordre « Prénom Nom ».
 * Une chaîne sans virgule est retournée telle quelle (après nettoyage des espaces).
 *
 * Exemple : « Bourque, Mavrik » -> « Mavrik Bourque »
 */
export function inverserNomFantrax(valeur: string | null | undefined): string {
  if (!valeur) return "";
  const brut = valeur.trim();
  const correspondance = /^(.+?),\s*(.+)$/.exec(brut);
  if (!correspondance) return brut.replace(/\s+/g, " ");
  return `${correspondance[2]} ${correspondance[1]}`.replace(/\s+/g, " ").trim();
}

/**
 * Construit l'expression cayenne du filet de sécurité records.nhl.com.
 * Les guillemets doubles sont retirés du nom pour ne pas casser l'expression.
 */
export function expressionRecherchRecords(nom: string): string {
  const propre = nom.replace(/"/g, "").trim();
  return `fullName likeIgnoreCase "${propre}"`;
}
