/**
 * Admissibilité aux slots farm.
 *
 * Un joueur demeure admissible tant qu'il n'a pas dépassé son seuil de parties
 * de saison régulière en carrière dans la LNH. Les séries éliminatoires ne
 * comptent pas (l'API NHL expose déjà la statistique séparément).
 *
 * Dès qu'un joueur dépasse son seuil, il doit être retiré du farm immédiatement.
 */

import type { NiveauFarm } from "./types.js";

/** Seuil de parties pour un gardien. */
export const SEUIL_GARDIEN = 124;
/** Seuil de parties pour un patineur (attaquant ou défenseur). */
export const SEUIL_PATINEUR = 164;

/** Marge, en parties restantes, déclenchant chaque niveau d'alerte. */
export const MARGES = {
  urgent: 5,
  critique: 10,
  surveiller: 30,
} as const;

/**
 * Détermine le seuil applicable selon la position.
 * Toute position commençant par « G » est traitée comme un gardien ;
 * Fantrax peut renvoyer « G », et l'API NHL « Goalie ».
 */
export function seuilPour(position: string | null | undefined): number {
  const p = (position ?? "").trim().toUpperCase();
  return p.startsWith("G") ? SEUIL_GARDIEN : SEUIL_PATINEUR;
}

/**
 * Évalue l'admissibilité d'un joueur.
 * `partiesJouees` à null signifie que l'information n'a pu être obtenue :
 * on ne suppose surtout pas 0, on signale « à vérifier ».
 */
export function evaluerFarm(
  partiesJouees: number | null | undefined,
  seuil: number,
): { reste: number | null; niveau: NiveauFarm } {
  if (partiesJouees === null || partiesJouees === undefined) {
    return { reste: null, niveau: "A_VERIFIER" };
  }
  const reste = seuil - partiesJouees;
  return { reste, niveau: niveauPourReste(reste) };
}

/** Classe une marge de parties restantes en niveau d'alerte. */
export function niveauPourReste(reste: number): NiveauFarm {
  if (reste <= 0) return "DEPASSE";
  if (reste <= MARGES.urgent) return "URGENT";
  if (reste <= MARGES.critique) return "CRITIQUE";
  if (reste <= MARGES.surveiller) return "SURVEILLER";
  return "OK";
}

/** Un niveau qui exige une action ou une surveillance de l'administrateur. */
export function estAlerte(niveau: NiveauFarm): boolean {
  return (
    niveau === "DEPASSE" ||
    niveau === "URGENT" ||
    niveau === "CRITIQUE" ||
    niveau === "SURVEILLER"
  );
}

/** Ordre de tri : les cas les plus graves d'abord. */
export function poidsNiveau(niveau: NiveauFarm): number {
  switch (niveau) {
    case "DEPASSE":
      return 0;
    case "URGENT":
      return 1;
    case "CRITIQUE":
      return 2;
    case "SURVEILLER":
      return 3;
    case "A_VERIFIER":
      return 4;
    case "OK":
      return 5;
  }
}

/** Libellé français court, avec pastille, pour l'interface. */
export function libelleNiveau(niveau: NiveauFarm): string {
  switch (niveau) {
    case "DEPASSE":
      return "⛔ Dépassé";
    case "URGENT":
      return "🔴 Urgent";
    case "CRITIQUE":
      return "🔴 Critique";
    case "SURVEILLER":
      return "🟡 Surveiller";
    case "A_VERIFIER":
      return "❔ À vérifier";
    case "OK":
      return "✅ OK";
  }
}

/**
 * Génère le message prêt à coller sur le groupe Facebook pour aviser un pooler.
 * Le ton est amical : l'objectif est de prévenir, pas de sanctionner.
 */
export function messageFacebook(joueur: {
  nom: string;
  partiesJouees: number | null;
  seuil: number;
  reste: number | null;
  equipePool?: string;
}): string {
  const { nom, partiesJouees, seuil, reste } = joueur;

  if (partiesJouees === null || reste === null) {
    return (
      `Salut, avis amical : je n'arrive pas à confirmer le nombre de parties en carrière de ${nom}. ` +
      `Peux-tu vérifier son admissibilité farm (seuil de ${seuil} parties) de ton côté ?`
    );
  }

  if (reste <= 0) {
    const excedent = Math.abs(reste);
    const parties = excedent <= 1 ? "partie" : "parties";
    return (
      `Salut, ${nom} a atteint ${partiesJouees}/${seuil} parties en carrière : ` +
      `il n'est plus admissible au farm (${excedent} ${parties} de trop). ` +
      `Il doit être retiré du farm immédiatement — dis-moi quel mouvement tu veux qu'on fasse.`
    );
  }

  const matchs = reste <= 1 ? "match" : "matchs";
  return (
    `Salut, avis amical : ${nom} est à ${partiesJouees}/${seuil} parties. ` +
    `Il lui reste ${reste} ${matchs} avant de perdre son admissibilité farm — prévois ton coup.`
  );
}
