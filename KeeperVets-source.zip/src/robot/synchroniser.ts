/**
 * Robot de synchronisation.
 *
 * Exécuté aux 2 heures par un déclencheur Cron, et déclenchable manuellement.
 * Enchaînement :
 *   1. lecture des alignements Fantrax et du référentiel des joueurs ;
 *   2. résolution du sens de chaque statut via le mapping configurable ;
 *   3. détection des transitions (entrées et sorties de la liste des blessés) ;
 *   4. rafraîchissement par lots du dictionnaire d'appariement NHL ;
 *   5. appariement des joueurs en slot farm et rafraîchissement de leurs
 *      parties jouées en carrière (les plus proches du seuil en priorité).
 *
 * Robustesse : chaque étape est isolée. Si Fantrax ou la LNH ne répond pas,
 * l'état existant est conservé intact et l'échec est journalisé.
 */

import { CLES_ETAT, CONFIG, type Env } from "../config.js";
import { Repo, type LigneRosterBd } from "../db/repo.js";
import { CLAIMS_PAR_SAISON } from "../domain/claims.js";
import { seuilPour } from "../domain/farm.js";
import { calculerEligibilite, dateDuJour, evaluerRetour } from "../domain/ir.js";
import { cleFamilleEquipe, variantesNormalisees } from "../domain/noms.js";
import { dateIrDepuisPeriode, dateCivile, type Periode } from "../domain/periodes.js";
import {
  detecterTransitions,
  resoudreTypeStatut,
  type Transition,
} from "../domain/transitions.js";
import type { TypeStatut } from "../domain/types.js";
import * as fantrax from "../sources/fantrax.js";
import * as nhl from "../sources/nhl.js";
import { pause } from "../sources/http.js";

export interface BilanExecution {
  executionId: number;
  succes: boolean;
  fantraxOk: boolean;
  nhlOk: boolean;
  joueursVus: number;
  sourcesNhlLues: number;
  pjRafraichies: number;
  irOuverts: number;
  irFermes: number;
  retoursPrematures: number;
  claimsUtilises: number;
  claimsAlloues: number;
  statutsInconnus: number;
  statutsInconnusDetail: string[];
  avertissements: string[];
  erreur: string | null;
}

export async function executerRobot(
  env: Env,
  options: { declencheur: "cron" | "manuel"; complet?: boolean } = {
    declencheur: "cron",
  },
): Promise<BilanExecution> {
  const repo = new Repo(env.DB);
  const maintenant = new Date().toISOString();
  const aujourdhui = dateDuJour(env.FUSEAU ?? "America/Toronto");
  const complet = options.complet === true;

  const executionId = await repo.demarrerExecution(
    options.declencheur,
    complet,
    maintenant,
  );

  const bilan: BilanExecution = {
    executionId,
    succes: false,
    fantraxOk: false,
    nhlOk: false,
    joueursVus: 0,
    sourcesNhlLues: 0,
    pjRafraichies: 0,
    irOuverts: 0,
    irFermes: 0,
    retoursPrematures: 0,
    claimsUtilises: 0,
    claimsAlloues: 0,
    statutsInconnus: 0,
    statutsInconnusDetail: [],
    avertissements: [],
    erreur: null,
  };

  try {
    // -----------------------------------------------------------------------
    // Étape 1 — Fantrax
    // -----------------------------------------------------------------------
    const alignements = await fantrax.lireAlignements(env.LEAGUE_ID);

    if (!alignements.ok) {
      // Source indisponible : on ne touche à rien, les dernières données
      // connues restent affichées avec leur horodatage.
      bilan.erreur = `Fantrax indisponible : ${alignements.erreur}`;
      bilan.avertissements.push(bilan.erreur);
      await repo.terminerExecution(executionId, { ...bilan, details: bilan }, new Date().toISOString());
      return bilan;
    }
    bilan.fantraxOk = true;
    bilan.joueursVus = alignements.valeur.lignes.length;

    await repo.majEquipes(alignements.valeur.equipes, maintenant);
    if (alignements.valeur.periode !== null) {
      await repo.ecrireEtat(
        CLES_ETAT.periodeFantrax,
        String(alignements.valeur.periode),
        maintenant,
      );
    }

    // Référentiel des noms : utile mais non bloquant.
    //
    // Ce fichier pèse plus d'un mégaoctet et couvre près de 9000 joueurs. On ne
    // le télécharge donc que lorsque des joueurs du pool n'ont pas encore de
    // fiche, ce qui n'arrive qu'après une acquisition. Le reste du temps,
    // l'étape est entièrement sautée : c'est ce qui garde le robot sous le
    // budget de temps processeur du plan gratuit de Cloudflare.
    const idsPresents = new Set(alignements.valeur.lignes.map((l) => l.fantraxId));
    const idsConnus = await repo.idsJoueursConnus();
    const idsManquants = new Set(
      [...idsPresents].filter((id) => !idsConnus.has(id)),
    );

    let referentielLu = false;
    if (idsManquants.size > 0 || complet) {
      const aChercher = complet ? idsPresents : idsManquants;
      const fiches = await fantrax.lireFichesJoueurs(aChercher);
      referentielLu = true;
      if (fiches.ok) {
        await repo.majJoueurs([...fiches.valeur.values()], maintenant);
      } else {
        bilan.avertissements.push(
          `Référentiel des joueurs Fantrax indisponible : ${fiches.erreur}`,
        );
      }
    }

    // Classement : purement informatif.
    const classement = await fantrax.lireClassement(env.LEAGUE_ID);
    if (classement.ok && classement.valeur.length > 0) {
      await repo.majEquipes(
        classement.valeur.map((c) => ({
          teamId: c.teamId,
          nom: c.nom,
          rang: c.rang,
          points: c.points,
        })),
        maintenant,
      );
    }

    await repo.ecrireEtat(CLES_ETAT.dernierSuccesFantrax, maintenant, maintenant);

    // -----------------------------------------------------------------------
    // Étape 1b — Périodes de roster
    // -----------------------------------------------------------------------
    // getLeagueInfo est volumineux et les périodes ne changent pas en cours de
    // saison : on ne le relit que si elles manquent, ou en exécution complète.
    let periodes = await repo.lirePeriodes();
    if (periodes.length === 0 || complet) {
      const calendrier = await fantrax.lireCalendrier(
        env.LEAGUE_ID,
        env.FUSEAU ?? "America/Toronto",
      );
      if (calendrier.ok) {
        await repo.majPeriodes(calendrier.valeur.periodes, maintenant);
        periodes = calendrier.valeur.periodes;
        if (calendrier.valeur.debutSaison) {
          await repo.ecrireEtat(
            CLES_ETAT.debutSaison,
            calendrier.valeur.debutSaison,
            maintenant,
          );
        }
        if (calendrier.valeur.finSaison) {
          await repo.ecrireEtat(
            CLES_ETAT.finSaison,
            calendrier.valeur.finSaison,
            maintenant,
          );
        }
      } else {
        // Sans les périodes, on retombe sur la date calendaire : l'application
        // reste utilisable, l'administrateur pourra corriger la date.
        bilan.avertissements.push(
          `Calendrier des périodes indisponible : ${calendrier.erreur}. ` +
            `Les dates de mise sur IR utiliseront la date du jour.`,
        );
      }
    }

    // -----------------------------------------------------------------------
    // Étape 2 — Résolution des statuts
    // -----------------------------------------------------------------------
    const mapping = await repo.lireMapping();
    const compteursStatuts = new Map<string, number>();

    const observes = alignements.valeur.lignes.map((l) => {
      compteursStatuts.set(
        l.statutBrut,
        (compteursStatuts.get(l.statutBrut) ?? 0) + 1,
      );
      const statutType: TypeStatut = resoudreTypeStatut(l.statutBrut, mapping);
      return {
        fantraxId: l.fantraxId,
        teamId: l.teamId,
        position: l.position,
        statutBrut: l.statutBrut,
        statutType,
      };
    });

    await repo.enregistrerStatutsObserves(compteursStatuts, maintenant);

    const inconnus = [...compteursStatuts.keys()].filter(
      (s) => !mapping.has(s),
    );
    bilan.statutsInconnus = inconnus.length;
    bilan.statutsInconnusDetail = inconnus;
    if (inconnus.length > 0) {
      // Attendu en début de saison : le statut de blessé n'est pas encore connu.
      console.warn(
        `[robot] statuts Fantrax non répertoriés (à classer par un admin) : ${inconnus.join(", ")}`,
      );
      bilan.avertissements.push(
        `Statuts Fantrax non répertoriés : ${inconnus.join(", ")}`,
      );
    }

    // -----------------------------------------------------------------------
    // Étape 3 — Transitions de la liste des blessés
    // -----------------------------------------------------------------------
    const precedents = await repo.lireRosterCourant();
    const transitions = detecterTransitions(precedents, observes);

    for (const t of transitions) {
      if (t.genre === "ENTREE_IR") {
        // Un séjour déjà ouvert ne doit pas être dupliqué (cas d'un aller-retour
        // entre deux exécutions, ou d'un statut reclassé par un admin).
        const dejaOuvert = await repo.sejourOuvertPour(t.fantraxId);
        if (dejaOuvert) continue;

        // La date retenue est celle du DÉBUT DE LA PÉRIODE Fantrax en cours,
        // et non la date du jour : c'est la règle appliquée dans la ligue.
        const { dateIr, periode } = dateIrDepuisPeriode(
          periodes,
          Date.parse(maintenant),
          aujourdhui,
        );

        await repo.ouvrirSejour({
          fantraxId: t.fantraxId,
          teamId: t.teamId,
          dateIr,
          dateEligibilite: calculerEligibilite(dateIr),
          statutBrutIr: t.statutBrut,
          periodeIr: periode,
          maintenant,
        });
        bilan.irOuverts++;
      } else if (t.genre === "SORTIE_IR") {
        const sejour = await repo.sejourOuvertPour(t.fantraxId);
        if (!sejour) continue;
        const evaluation = evaluerRetour(sejour.date_ir, aujourdhui);
        await repo.fermerSejour({
          id: sejour.id,
          dateRetour: aujourdhui,
          statutApres: t.statutApres,
          premature: evaluation.premature,
          joursManquants: evaluation.joursManquants,
          motif: "retour",
          maintenant,
        });
        bilan.irFermes++;
        if (evaluation.premature) {
          bilan.retoursPrematures++;
          console.warn(
            `[robot] retour prématuré détecté : joueur ${t.fantraxId}, ` +
              `${evaluation.joursManquants} jour(s) écourté(s)`,
          );
        }
      } else if (t.genre === "RETIRE_DU_POOL") {
        const sejour = await repo.sejourOuvertPour(t.fantraxId);
        if (!sejour) continue;
        // Le joueur n'est plus dans le pool : le séjour est clos sans juger
        // d'une infraction, le mouvement n'étant plus observable.
        await repo.fermerSejour({
          id: sejour.id,
          dateRetour: aujourdhui,
          statutApres: null,
          premature: false,
          joursManquants: 0,
          motif: "retire-du-pool",
          maintenant,
        });
        bilan.irFermes++;
      } else if (t.genre === "CHANGEMENT_EQUIPE") {
        const sejour = await repo.sejourOuvertPour(t.fantraxId);
        if (sejour) await repo.majEquipeSejour(sejour.id, t.teamId);
      }
    }

    // -----------------------------------------------------------------------
    // Étape 3b — Claims consommés
    // -----------------------------------------------------------------------
    // Une ENTREE_POOL correspond à une acquisition depuis l'extérieur du pool,
    // donc à un claim. Un échange entre deux équipes produit un
    // CHANGEMENT_EQUIPE et ne consomme rien.
    const resultatClaims = await suivreClaims(repo, {
      transitions,
      equipes: alignements.valeur.equipes,
      periodes,
      aujourdhui,
      maintenant,
      executionId,
      dernierReleve: await repo.dateDernierReleve(),
    });
    bilan.claimsUtilises = resultatClaims.utilises;
    bilan.claimsAlloues = resultatClaims.alloues;
    bilan.avertissements.push(...resultatClaims.avertissements);

    // L'état courant n'est remplacé qu'après une lecture Fantrax réussie.
    const lignesBd: LigneRosterBd[] = observes.map((o) => ({
      fantraxId: o.fantraxId,
      teamId: o.teamId,
      position: o.position || null,
      statutBrut: o.statutBrut,
      statutType: o.statutType,
    }));
    await repo.remplacerRosterCourant(lignesBd, maintenant);

    // -----------------------------------------------------------------------
    // Étape 4 — Dictionnaire d'appariement NHL (par lots rotatifs)
    // -----------------------------------------------------------------------
    // Si le gros référentiel Fantrax vient d'être analysé, on allège le lot NHL
    // de cette exécution : le budget de temps processeur du plan gratuit est de
    // 10 ms, et il vaut mieux étaler le travail sur deux passages que risquer
    // une interruption.
    const resultatNhl = await rafraichirIndexNhl(
      repo,
      complet,
      maintenant,
      referentielLu && !complet,
    );
    bilan.sourcesNhlLues = resultatNhl.sourcesLues;
    bilan.nhlOk = resultatNhl.ok;
    if (!resultatNhl.ok) {
      bilan.avertissements.push(...resultatNhl.avertissements);
    }

    // -----------------------------------------------------------------------
    // Étape 5 — Appariement et parties jouées des joueurs en slot farm
    // -----------------------------------------------------------------------
    const resultatFarm = await rafraichirFarm(repo, complet, maintenant);
    bilan.pjRafraichies = resultatFarm.pjRafraichies;
    bilan.avertissements.push(...resultatFarm.avertissements);

    if (bilan.nhlOk || resultatFarm.pjRafraichies > 0) {
      await repo.ecrireEtat(CLES_ETAT.dernierSuccesNhl, maintenant, maintenant);
    }

    bilan.succes = true;
  } catch (e) {
    bilan.erreur = e instanceof Error ? `${e.name}: ${e.message}` : String(e);
    console.error("[robot] échec inattendu", e);
  }

  const fin = new Date().toISOString();
  await repo.ecrireEtat(CLES_ETAT.derniereExecution, fin, fin);
  await repo.terminerExecution(
    executionId,
    {
      succes: bilan.succes,
      fantraxOk: bilan.fantraxOk,
      nhlOk: bilan.nhlOk,
      joueursVus: bilan.joueursVus,
      sourcesNhlLues: bilan.sourcesNhlLues,
      pjRafraichies: bilan.pjRafraichies,
      irOuverts: bilan.irOuverts,
      irFermes: bilan.irFermes,
      retoursPrematures: bilan.retoursPrematures,
      statutsInconnus: bilan.statutsInconnus,
      erreur: bilan.erreur,
      details: {
        avertissements: bilan.avertissements,
        statutsInconnus: bilan.statutsInconnusDetail,
        claimsUtilises: bilan.claimsUtilises,
        claimsAlloues: bilan.claimsAlloues,
      },
    },
    fin,
  );

  return bilan;
}

/**
 * Dotation de début de saison et décompte des claims consommés.
 *
 * La dotation n'est distribuée qu'une fois par saison, et seulement une fois la
 * saison ouverte. Le décompte automatique ne s'applique lui aussi qu'en saison :
 * les mouvements de la préparation et du repêchage ne consomment pas de claim.
 */
async function suivreClaims(
  repo: Repo,
  contexte: {
    transitions: readonly Transition[];
    equipes: readonly { teamId: string; nom: string }[];
    periodes: readonly Periode[];
    aujourdhui: string;
    maintenant: string;
    executionId: number;
    /** Horodatage du relevé précédent, avant son remplacement. */
    dernierReleve: string | null;
  },
): Promise<{ utilises: number; alloues: number; avertissements: string[] }> {
  const avertissements: string[] = [];
  const { periodes, aujourdhui, maintenant, executionId } = contexte;

  if (periodes.length === 0) {
    return { utilises: 0, alloues: 0, avertissements };
  }

  const premiere = periodes.reduce((a, b) => (a.numero <= b.numero ? a : b));
  const saison = Number(premiere.dateDebut.slice(0, 4));
  const saisonOuverte = aujourdhui >= premiere.dateDebut;

  if (!saisonOuverte) {
    // Avant le coup d'envoi, on ne dote ni ne décompte : les mouvements de
    // préparation et de repêchage ne consomment pas de claim.
    return { utilises: 0, alloues: 0, avertissements };
  }

  // --- Dotation annuelle ---
  // Seules les équipes n'ayant aucun mouvement pour la saison sont dotées.
  // Cette règle rend l'opération idempotente et protège contre le double
  // comptage lorsqu'un administrateur a déjà saisi un solde à la main.
  let alloues = 0;
  const aDoter = await repo.equipesSansMouvementClaims(saison);
  const equipesConnues = new Set(contexte.equipes.map((e) => e.teamId));

  for (const teamId of aDoter) {
    if (!equipesConnues.has(teamId)) continue;
    await repo.ajouterMouvementClaim({
      teamId,
      saison,
      type: "ALLOCATION",
      quantite: CLAIMS_PAR_SAISON,
      dateEffet: premiere.dateDebut,
      motif: `Dotation de début de saison ${saison}`,
      auteur: "robot",
      executionId,
      maintenant,
    });
    alloues++;
  }

  if (alloues > 0) {
    console.log(
      `[robot] dotation de ${CLAIMS_PAR_SAISON} claims distribuée à ${alloues} équipe(s) pour ${saison}`,
    );
  }

  // --- Claims consommés ---
  //
  // Le décompte n'a de sens que si l'état précédent date lui aussi de la
  // saison. Le repêchage a lieu avant l'ouverture : si le robot n'a pas tourné
  // entre les deux, comparer avec un relevé d'avant le repêchage ferait passer
  // toutes les recrues pour des acquisitions payantes.
  const dernierReleve = contexte.dernierReleve;
  const releveAJour =
    dernierReleve !== null && dateCivile(dernierReleve) >= premiere.dateDebut;

  if (!releveAJour) {
    const vu = dernierReleve ? dateCivile(dernierReleve) : "aucun";
    avertissements.push(
      `Décompte des claims ignoré : le relevé précédent (${vu}) est antérieur ` +
        `à l'ouverture de la saison (${premiere.dateDebut}). ` +
        `Les mouvements du repêchage ne consomment pas de claim.`,
    );
    console.warn(
      `[robot] decompte des claims ignore, releve precedent trop ancien (${vu})`,
    );
    return { utilises: 0, alloues, avertissements };
  }

  let utilises = 0;
  for (const t of contexte.transitions) {
    if (t.genre !== "ENTREE_POOL") continue;
    const ajoute = await repo.enregistrerClaimUtilise({
      teamId: t.teamId,
      saison,
      fantraxId: t.fantraxId,
      dateEffet: aujourdhui,
      executionId,
      maintenant,
    });
    if (ajoute) {
      utilises++;
      console.log(
        `[robot] claim consommé : équipe ${t.teamId}, joueur ${t.fantraxId}`,
      );
    }
  }

  return { utilises, alloues, avertissements };
}

/**
 * Rafraîchit le dictionnaire « nom -> identifiant NHL » par lots.
 * Les sources les moins récemment lues sont traitées en premier, de sorte que
 * les 64 sources sont couvertes en quelques exécutions.
 */
async function rafraichirIndexNhl(
  repo: Repo,
  complet: boolean,
  maintenant: string,
  lotReduit = false,
): Promise<{ ok: boolean; sourcesLues: number; avertissements: string[] }> {
  const avertissements: string[] = [];

  // La liste des 32 équipes n'est établie qu'une fois, puis complétée si besoin.
  const dejaInitialise = (await repo.prochainesSourcesNhl(1)).length > 0;
  if (!dejaInitialise) {
    const codes = await nhl.lireCodesEquipes();
    if (!codes.ok) {
      return {
        ok: false,
        sourcesLues: 0,
        avertissements: [`Classement NHL indisponible : ${codes.erreur}`],
      };
    }
    await repo.initialiserSourcesNhl(codes.valeur);
  }

  const limite = complet
    ? CONFIG.maxSourcesNhlComplet
    : lotReduit
      ? CONFIG.maxSourcesNhlLotReduit
      : CONFIG.maxSourcesNhlParRun;
  const sources = await repo.prochainesSourcesNhl(limite);

  let lues = 0;
  let echecs = 0;

  for (const source of sources) {
    const resultat = await nhl.lireJoueursEquipe(
      source.tri,
      source.genre as nhl.GenreSource,
    );
    if (resultat.ok) {
      await repo.majIndexNhl(
        resultat.valeur.flatMap((e) =>
          e.variantes.map((variante) => ({
            nomNormalise: variante,
            nhlPlayerId: e.nhlPlayerId,
            tri: source.tri,
            genre: source.genre,
          })),
        ),
        maintenant,
      );
      await repo.majIndexFamille(
        resultat.valeur.map((e) => ({
          cle: e.cleFamille,
          nhlPlayerId: e.nhlPlayerId,
          tri: source.tri,
        })),
        maintenant,
      );
      await repo.marquerSourceNhl(
        source.cle,
        true,
        maintenant,
        resultat.valeur.length,
        null,
      );
      lues++;
    } else {
      echecs++;
      await repo.marquerSourceNhl(source.cle, false, maintenant, 0, resultat.erreur);
      avertissements.push(`Source NHL ${source.cle} : ${resultat.erreur}`);
    }
    await pause(CONFIG.pauseEntreAppelsMs);
  }

  return { ok: lues > 0 || echecs === 0, sourcesLues: lues, avertissements };
}

/**
 * Apparie les joueurs en slot farm au dictionnaire NHL puis rafraîchit leurs
 * parties jouées en carrière.
 *
 * Priorité de rafraîchissement : les joueurs dont le cache est absent, puis
 * ceux dont la marge est la plus faible, puis les caches les plus anciens.
 * C'est ce qui garantit qu'un joueur sur le point de dépasser son seuil est
 * suivi de près, même quand le quota d'appels est serré.
 */
async function rafraichirFarm(
  repo: Repo,
  complet: boolean,
  maintenant: string,
): Promise<{ pjRafraichies: number; avertissements: string[] }> {
  const avertissements: string[] = [];

  // --- Appariement des joueurs farm non encore résolus ---
  const aApparier = await repo.joueursFarmSansAppariement();
  if (aApparier.length > 0) {
    const appariements: {
      fantraxId: string;
      nhlPlayerId: number | null;
      source: string;
    }[] = [];

    // Étape A — nom complet, sous toutes ses formes normalisées.
    const variantesParJoueur = aApparier.map((j) => variantesNormalisees(j.nom ?? ""));
    const parNom = await repo.chercherDansIndex(variantesParJoueur.flat());

    const restants: typeof aApparier = [];
    for (const [i, joueur] of aApparier.entries()) {
      const trouve = (variantesParJoueur[i] ?? [])
        .map((v) => parNom.get(v))
        .find((id): id is number => typeof id === "number");
      if (trouve) {
        appariements.push({
          fantraxId: joueur.fantrax_id,
          nhlPlayerId: trouve,
          source: "nhl-index",
        });
      } else {
        restants.push(joueur);
      }
    }

    // Étape B — repli « équipe NHL + nom de famille ».
    // Couvre les diminutifs (« Ben » contre « Benjamin ») et les variantes de
    // trait d'union que le nom complet ne permet pas de rapprocher.
    const encoreRestants: typeof aApparier = [];
    if (restants.length > 0) {
      const clesFamille = restants.map((j) => cleFamilleEquipe(j.equipe_nhl, j.nom));
      const parFamille = await repo.chercherParFamille(clesFamille);

      for (const [i, joueur] of restants.entries()) {
        const id = parFamille.get(clesFamille[i] ?? "");
        if (id) {
          appariements.push({
            fantraxId: joueur.fantrax_id,
            nhlPlayerId: id,
            source: "nhl-famille",
          });
        } else {
          encoreRestants.push(joueur);
        }
      }
    }

    // Étape C — filet de sécurité : recherche nominative dans les archives.
    const quota = complet ? encoreRestants.length : 5;
    for (const joueur of encoreRestants.slice(0, quota)) {
      if (!joueur.nom) continue;
      const recherche = await nhl.chercherDansRecords(joueur.nom);
      if (recherche.ok && recherche.valeur) {
        appariements.push({
          fantraxId: joueur.fantrax_id,
          nhlPlayerId: recherche.valeur,
          source: "records",
        });
      } else {
        // Volontairement laissé non apparié plutôt que supposé à zéro partie :
        // un échec d'appariement ne prouve pas que le joueur n'a jamais joué.
        avertissements.push(
          `Joueur farm non apparié : ${joueur.nom ?? joueur.fantrax_id}`,
        );
      }
      await pause(CONFIG.pauseEntreAppelsMs);
    }

    if (appariements.length > 0) {
      await repo.majAppariements(appariements, maintenant);
    }
  }

  // --- Rafraîchissement des parties jouées ---
  const farm = await repo.vueFarm();
  const limiteMs = CONFIG.ttlCachePjHeures * 3_600_000;
  const instant = Date.parse(maintenant);

  const candidats = farm
    .filter((f) => f.nhl_player_id !== null)
    .map((f) => {
      const age = f.recupere_le ? instant - Date.parse(f.recupere_le) : Infinity;
      const seuil = seuilPour(f.position);
      const marge =
        f.parties_jouees === null ? -1 : seuil - f.parties_jouees;
      return { ...f, age, marge };
    })
    .filter((f) => f.age >= limiteMs)
    .sort((a, b) => {
      // Jamais mesuré d'abord, puis marge la plus faible, puis cache le plus vieux.
      if (a.marge < 0 && b.marge >= 0) return -1;
      if (b.marge < 0 && a.marge >= 0) return 1;
      if (a.marge !== b.marge) return a.marge - b.marge;
      return b.age - a.age;
    });

  const quota = complet
    ? CONFIG.maxFichesJoueursComplet
    : CONFIG.maxFichesJoueursParRun;

  const aEcrire: { nhlPlayerId: number; parties: number }[] = [];
  for (const candidat of candidats.slice(0, quota)) {
    const resultat = await nhl.lirePartiesCarriere(candidat.nhl_player_id as number);
    if (resultat.ok) {
      aEcrire.push({
        nhlPlayerId: candidat.nhl_player_id as number,
        parties: resultat.valeur,
      });
    } else {
      avertissements.push(
        `Parties en carrière indisponibles pour ${candidat.nom ?? candidat.fantrax_id} : ${resultat.erreur}`,
      );
    }
    await pause(CONFIG.pauseEntreAppelsMs);
  }

  if (aEcrire.length > 0) await repo.ecrireCachePj(aEcrire, maintenant);

  return { pjRafraichies: aEcrire.length, avertissements };
}
