/**
 * Couche d'accès à la base D1.
 *
 * Toutes les écritures en volume passent par des lots (`batch`) découpés,
 * pour rester sous les limites de taille de requête de D1.
 */

import type { TypeMouvementClaim } from "../domain/claims.js";
import type { Periode } from "../domain/periodes.js";
import type { TypeStatut } from "../domain/types.js";

/** Taille des lots d'écriture envoyés à D1. */
const TAILLE_LOT = 80;

export interface LigneRosterBd {
  fantraxId: string;
  teamId: string;
  position: string | null;
  statutBrut: string;
  statutType: TypeStatut;
}

export interface SejourBd {
  id: number;
  fantrax_id: string;
  team_id: string;
  date_ir: string;
  date_ir_detectee: string;
  detecte_le: string;
  date_eligibilite: string;
  statut_brut_ir: string | null;
  date_retour: string | null;
  retour_detecte_le: string | null;
  statut_apres: string | null;
  retour_premature: number;
  jours_manquants: number | null;
  motif_fermeture: string | null;
  ouvert: number;
  corrige_par: string | null;
  corrige_le: string | null;
  note: string | null;
  periode_ir: number | null;
  cree_le: string;
}

export class Repo {
  constructor(private readonly db: D1Database) {}

  // -------------------------------------------------------------------------
  // Utilitaire de lot
  // -------------------------------------------------------------------------

  private async executerParLots(requetes: D1PreparedStatement[]): Promise<void> {
    for (let i = 0; i < requetes.length; i += TAILLE_LOT) {
      await this.db.batch(requetes.slice(i, i + TAILLE_LOT));
    }
  }

  // -------------------------------------------------------------------------
  // État applicatif
  // -------------------------------------------------------------------------

  async lireEtat(cle: string): Promise<string | null> {
    const ligne = await this.db
      .prepare("SELECT valeur FROM etat_app WHERE cle = ?")
      .bind(cle)
      .first<{ valeur: string | null }>();
    return ligne?.valeur ?? null;
  }

  async lireTousEtats(): Promise<Record<string, string | null>> {
    const { results } = await this.db
      .prepare("SELECT cle, valeur FROM etat_app")
      .all<{ cle: string; valeur: string | null }>();
    return Object.fromEntries((results ?? []).map((l) => [l.cle, l.valeur]));
  }

  async ecrireEtat(cle: string, valeur: string, maintenant: string): Promise<void> {
    await this.db
      .prepare(
        `INSERT INTO etat_app (cle, valeur, maj_le) VALUES (?, ?, ?)
         ON CONFLICT(cle) DO UPDATE SET valeur = excluded.valeur, maj_le = excluded.maj_le`,
      )
      .bind(cle, valeur, maintenant)
      .run();
  }

  // -------------------------------------------------------------------------
  // Mapping des statuts
  // -------------------------------------------------------------------------

  async lireMapping(): Promise<Map<string, TypeStatut>> {
    const { results } = await this.db
      .prepare("SELECT statut_brut, type FROM mapping_statuts")
      .all<{ statut_brut: string; type: TypeStatut }>();
    return new Map((results ?? []).map((l) => [l.statut_brut, l.type]));
  }

  async listerMapping(): Promise<
    {
      statut_brut: string;
      type: TypeStatut;
      libelle: string | null;
      auto_decouvert: number;
      nb_observations: number;
      premiere_vue: string | null;
      derniere_vue: string | null;
      maj_par: string | null;
    }[]
  > {
    const { results } = await this.db
      .prepare(
        `SELECT statut_brut, type, libelle, auto_decouvert, nb_observations,
                premiere_vue, derniere_vue, maj_par
         FROM mapping_statuts ORDER BY type, statut_brut`,
      )
      .all();
    return (results ?? []) as never;
  }

  /**
   * Enregistre les statuts bruts observés lors d'une lecture.
   * Un statut jamais vu est créé automatiquement en INCONNU : l'application
   * continue de fonctionner et l'administrateur pourra le reclasser.
   */
  async enregistrerStatutsObserves(
    compteurs: Map<string, number>,
    maintenant: string,
  ): Promise<void> {
    const requetes = [...compteurs].map(([statut, nb]) =>
      this.db
        .prepare(
          `INSERT INTO mapping_statuts
             (statut_brut, type, libelle, auto_decouvert, nb_observations, premiere_vue, derniere_vue)
           VALUES (?, 'INCONNU', NULL, 1, ?, ?, ?)
           ON CONFLICT(statut_brut) DO UPDATE SET
             nb_observations = ?,
             derniere_vue = excluded.derniere_vue`,
        )
        .bind(statut, nb, maintenant, maintenant, nb),
    );
    await this.executerParLots(requetes);
  }

  async majTypeStatut(
    statutBrut: string,
    type: TypeStatut,
    libelle: string | null,
    admin: string,
    maintenant: string,
  ): Promise<void> {
    await this.db
      .prepare(
        `INSERT INTO mapping_statuts (statut_brut, type, libelle, auto_decouvert, maj_par, maj_le)
         VALUES (?, ?, ?, 0, ?, ?)
         ON CONFLICT(statut_brut) DO UPDATE SET
           type = excluded.type, libelle = excluded.libelle,
           maj_par = excluded.maj_par, maj_le = excluded.maj_le`,
      )
      .bind(statutBrut, type, libelle, admin, maintenant)
      .run();
  }

  // -------------------------------------------------------------------------
  // Équipes
  // -------------------------------------------------------------------------

  async majEquipes(
    equipes: { teamId: string; nom: string; rang?: number | null; points?: number | null }[],
    maintenant: string,
  ): Promise<void> {
    const requetes = equipes.map((e) =>
      this.db
        .prepare(
          `INSERT INTO equipes (team_id, nom, rang, points, maj_le)
           VALUES (?, ?, ?, ?, ?)
           ON CONFLICT(team_id) DO UPDATE SET
             nom = excluded.nom,
             rang = COALESCE(excluded.rang, equipes.rang),
             points = COALESCE(excluded.points, equipes.points),
             maj_le = excluded.maj_le`,
        )
        .bind(e.teamId, e.nom, e.rang ?? null, e.points ?? null, maintenant),
    );
    await this.executerParLots(requetes);
  }

  async listerEquipes(): Promise<
    { team_id: string; nom: string; rang: number | null; points: number | null }[]
  > {
    const { results } = await this.db
      .prepare("SELECT team_id, nom, rang, points FROM equipes ORDER BY rang, nom")
      .all();
    return (results ?? []) as never;
  }

  // -------------------------------------------------------------------------
  // Joueurs
  // -------------------------------------------------------------------------

  async majJoueurs(
    joueurs: {
      fantraxId: string;
      nom: string;
      nomNormalise: string;
      equipeNhl: string | null;
      position: string | null;
    }[],
    maintenant: string,
  ): Promise<void> {
    const requetes = joueurs.map((j) =>
      this.db
        .prepare(
          `INSERT INTO joueurs (fantrax_id, nom, nom_normalise, equipe_nhl, position, maj_le)
           VALUES (?, ?, ?, ?, ?, ?)
           ON CONFLICT(fantrax_id) DO UPDATE SET
             nom = excluded.nom,
             nom_normalise = excluded.nom_normalise,
             equipe_nhl = COALESCE(excluded.equipe_nhl, joueurs.equipe_nhl),
             position = COALESCE(excluded.position, joueurs.position),
             maj_le = excluded.maj_le`,
        )
        .bind(
          j.fantraxId,
          j.nom,
          j.nomNormalise,
          j.equipeNhl,
          j.position,
          maintenant,
        ),
    );
    await this.executerParLots(requetes);
  }

  /** Identifiants Fantrax des joueurs déjà connus au référentiel. */
  async idsJoueursConnus(): Promise<Set<string>> {
    const { results } = await this.db
      .prepare("SELECT fantrax_id FROM joueurs")
      .all<{ fantrax_id: string }>();
    return new Set((results ?? []).map((l) => l.fantrax_id));
  }

  async majAppariements(
    appariements: { fantraxId: string; nhlPlayerId: number | null; source: string }[],
    maintenant: string,
  ): Promise<void> {
    const requetes = appariements.map((a) =>
      this.db
        .prepare(
          `UPDATE joueurs SET nhl_player_id = ?, source_appariement = ?, apparie_le = ?
           WHERE fantrax_id = ?`,
        )
        .bind(a.nhlPlayerId, a.source, maintenant, a.fantraxId),
    );
    await this.executerParLots(requetes);
  }

  // -------------------------------------------------------------------------
  // Dictionnaire d'appariement NHL
  // -------------------------------------------------------------------------

  async majIndexNhl(
    entrees: { nomNormalise: string; nhlPlayerId: number; tri: string; genre: string }[],
    maintenant: string,
  ): Promise<void> {
    const requetes = entrees.map((e) =>
      this.db
        .prepare(
          `INSERT INTO nhl_index (nom_normalise, nhl_player_id, tri, genre, maj_le)
           VALUES (?, ?, ?, ?, ?)
           ON CONFLICT(nom_normalise) DO UPDATE SET
             nhl_player_id = excluded.nhl_player_id,
             tri = excluded.tri, genre = excluded.genre, maj_le = excluded.maj_le`,
        )
        .bind(e.nomNormalise, e.nhlPlayerId, e.tri, e.genre, maintenant),
    );
    await this.executerParLots(requetes);
  }

  async chercherDansIndex(nomsNormalises: string[]): Promise<Map<string, number>> {
    const trouves = new Map<string, number>();
    // Découpage : SQLite limite le nombre de paramètres liés par requête.
    for (let i = 0; i < nomsNormalises.length; i += 50) {
      const tranche = nomsNormalises.slice(i, i + 50);
      const trous = tranche.map(() => "?").join(",");
      const { results } = await this.db
        .prepare(
          `SELECT nom_normalise, nhl_player_id FROM nhl_index WHERE nom_normalise IN (${trous})`,
        )
        .bind(...tranche)
        .all<{ nom_normalise: string; nhl_player_id: number }>();
      for (const l of results ?? []) trouves.set(l.nom_normalise, l.nhl_player_id);
    }
    return trouves;
  }

  async compterIndexNhl(): Promise<number> {
    const ligne = await this.db
      .prepare("SELECT COUNT(*) AS n FROM nhl_index")
      .first<{ n: number }>();
    return ligne?.n ?? 0;
  }

  /**
   * Alimente l'index de repli « équipe|nom de famille ».
   * Une clé déjà présente pour un autre joueur est marquée ambiguë : elle ne
   * sera plus utilisée pour apparier (cas de deux frères dans la même équipe).
   */
  async majIndexFamille(
    entrees: { cle: string; nhlPlayerId: number; tri: string }[],
    maintenant: string,
  ): Promise<void> {
    const requetes = entrees
      .filter((e) => e.cle.length > 0)
      .map((e) =>
        this.db
          .prepare(
            `INSERT INTO nhl_index_famille (cle, nhl_player_id, tri, ambigu, maj_le)
             VALUES (?, ?, ?, 0, ?)
             ON CONFLICT(cle) DO UPDATE SET
               ambigu = CASE WHEN nhl_index_famille.nhl_player_id = excluded.nhl_player_id
                             THEN nhl_index_famille.ambigu ELSE 1 END,
               maj_le = excluded.maj_le`,
          )
          .bind(e.cle, e.nhlPlayerId, e.tri, maintenant),
      );
    await this.executerParLots(requetes);
  }

  /** Recherche par clé de repli, en écartant les clés ambiguës. */
  async chercherParFamille(cles: string[]): Promise<Map<string, number>> {
    const trouves = new Map<string, number>();
    const utiles = cles.filter((c) => c.length > 0);
    for (let i = 0; i < utiles.length; i += 50) {
      const tranche = utiles.slice(i, i + 50);
      const trous = tranche.map(() => "?").join(",");
      const { results } = await this.db
        .prepare(
          `SELECT cle, nhl_player_id FROM nhl_index_famille
           WHERE ambigu = 0 AND cle IN (${trous})`,
        )
        .bind(...tranche)
        .all<{ cle: string; nhl_player_id: number }>();
      for (const l of results ?? []) trouves.set(l.cle, l.nhl_player_id);
    }
    return trouves;
  }

  // -------------------------------------------------------------------------
  // Rotation des sources NHL
  // -------------------------------------------------------------------------

  async initialiserSourcesNhl(codes: string[]): Promise<void> {
    const requetes: D1PreparedStatement[] = [];
    for (const tri of codes) {
      for (const genre of ["roster", "prospects"]) {
        requetes.push(
          this.db
            .prepare(
              `INSERT INTO nhl_sources (cle, tri, genre) VALUES (?, ?, ?)
               ON CONFLICT(cle) DO NOTHING`,
            )
            .bind(`${tri}:${genre}`, tri, genre),
        );
      }
    }
    await this.executerParLots(requetes);
  }

  /** Sources les plus anciennement rafraîchies d'abord (rotation). */
  async prochainesSourcesNhl(
    limite: number,
  ): Promise<{ cle: string; tri: string; genre: string }[]> {
    const { results } = await this.db
      .prepare(
        `SELECT cle, tri, genre FROM nhl_sources
         ORDER BY COALESCE(dernier_succes, '0000') ASC, cle ASC
         LIMIT ?`,
      )
      .bind(limite)
      .all<{ cle: string; tri: string; genre: string }>();
    return results ?? [];
  }

  async marquerSourceNhl(
    cle: string,
    succes: boolean,
    maintenant: string,
    nbJoueurs: number,
    erreur: string | null,
  ): Promise<void> {
    const drapeau = succes ? 1 : 0;
    await this.db
      .prepare(
        `UPDATE nhl_sources SET
           dernier_essai = ?,
           dernier_succes = CASE WHEN ? = 1 THEN ? ELSE dernier_succes END,
           nb_joueurs = CASE WHEN ? = 1 THEN ? ELSE nb_joueurs END,
           derniere_erreur = ?
         WHERE cle = ?`,
      )
      .bind(maintenant, drapeau, maintenant, drapeau, nbJoueurs, erreur, cle)
      .run();
  }

  // -------------------------------------------------------------------------
  // Cache des parties jouées
  // -------------------------------------------------------------------------

  async lireCachePj(): Promise<Map<number, { parties: number; recupereLe: string }>> {
    const { results } = await this.db
      .prepare("SELECT nhl_player_id, parties_jouees, recupere_le FROM cache_pj")
      .all<{ nhl_player_id: number; parties_jouees: number; recupere_le: string }>();
    return new Map(
      (results ?? []).map((l) => [
        l.nhl_player_id,
        { parties: l.parties_jouees, recupereLe: l.recupere_le },
      ]),
    );
  }

  async ecrireCachePj(
    entrees: { nhlPlayerId: number; parties: number }[],
    maintenant: string,
  ): Promise<void> {
    const requetes = entrees.map((e) =>
      this.db
        .prepare(
          `INSERT INTO cache_pj (nhl_player_id, parties_jouees, recupere_le)
           VALUES (?, ?, ?)
           ON CONFLICT(nhl_player_id) DO UPDATE SET
             parties_jouees = excluded.parties_jouees,
             recupere_le = excluded.recupere_le`,
        )
        .bind(e.nhlPlayerId, e.parties, maintenant),
    );
    await this.executerParLots(requetes);
  }

  // -------------------------------------------------------------------------
  // Alignements courants
  // -------------------------------------------------------------------------

  async lireRosterCourant(): Promise<
    { fantraxId: string; teamId: string; statutBrut: string; statutType: TypeStatut }[]
  > {
    const { results } = await this.db
      .prepare(
        "SELECT fantrax_id, team_id, statut_brut, statut_type FROM roster_courant",
      )
      .all<{
        fantrax_id: string;
        team_id: string;
        statut_brut: string;
        statut_type: TypeStatut;
      }>();
    return (results ?? []).map((l) => ({
      fantraxId: l.fantrax_id,
      teamId: l.team_id,
      statutBrut: l.statut_brut,
      statutType: l.statut_type,
    }));
  }

  /**
   * Horodatage du dernier relevé d'alignements conservé.
   * Sert à savoir si l'état précédent est assez récent pour qu'une comparaison
   * ait du sens : après un repêchage, comparer avec un relevé antérieur ferait
   * passer toutes les recrues pour des acquisitions.
   */
  async dateDernierReleve(): Promise<string | null> {
    const ligne = await this.db
      .prepare("SELECT MAX(observe_le) AS le FROM roster_courant")
      .first<{ le: string | null }>();
    return ligne?.le ?? null;
  }

  /**
   * Remplace intégralement l'état courant.
   * Le remplacement n'a lieu que si la lecture Fantrax a réussi : on n'efface
   * jamais l'état connu sur la foi d'une source indisponible.
   */
  async remplacerRosterCourant(
    lignes: LigneRosterBd[],
    maintenant: string,
  ): Promise<void> {
    await this.db.prepare("DELETE FROM roster_courant").run();
    const requetes = lignes.map((l) =>
      this.db
        .prepare(
          `INSERT INTO roster_courant
             (fantrax_id, team_id, position, statut_brut, statut_type, observe_le)
           VALUES (?, ?, ?, ?, ?, ?)`,
        )
        .bind(l.fantraxId, l.teamId, l.position, l.statutBrut, l.statutType, maintenant),
    );
    await this.executerParLots(requetes);
  }

  // -------------------------------------------------------------------------
  // Séjours sur la liste des blessés
  // -------------------------------------------------------------------------

  async sejoursOuverts(): Promise<SejourBd[]> {
    const { results } = await this.db
      .prepare("SELECT * FROM sejours_ir WHERE ouvert = 1")
      .all<SejourBd>();
    return results ?? [];
  }

  async sejourOuvertPour(fantraxId: string): Promise<SejourBd | null> {
    return await this.db
      .prepare("SELECT * FROM sejours_ir WHERE ouvert = 1 AND fantrax_id = ?")
      .bind(fantraxId)
      .first<SejourBd>();
  }

  async ouvrirSejour(s: {
    fantraxId: string;
    teamId: string;
    dateIr: string;
    dateEligibilite: string;
    statutBrutIr: string;
    periodeIr: number | null;
    maintenant: string;
  }): Promise<void> {
    await this.db
      .prepare(
        `INSERT INTO sejours_ir
           (fantrax_id, team_id, date_ir, date_ir_detectee, detecte_le,
            date_eligibilite, statut_brut_ir, periode_ir, ouvert, cree_le)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?)`,
      )
      .bind(
        s.fantraxId,
        s.teamId,
        s.dateIr,
        s.dateIr,
        s.maintenant,
        s.dateEligibilite,
        s.statutBrutIr,
        s.periodeIr,
        s.maintenant,
      )
      .run();
  }

  async fermerSejour(s: {
    id: number;
    dateRetour: string;
    statutApres: string | null;
    premature: boolean;
    joursManquants: number;
    motif: string;
    maintenant: string;
  }): Promise<void> {
    await this.db
      .prepare(
        `UPDATE sejours_ir SET
           ouvert = 0, date_retour = ?, retour_detecte_le = ?, statut_apres = ?,
           retour_premature = ?, jours_manquants = ?, motif_fermeture = ?
         WHERE id = ?`,
      )
      .bind(
        s.dateRetour,
        s.maintenant,
        s.statutApres,
        s.premature ? 1 : 0,
        s.joursManquants,
        s.motif,
        s.id,
      )
      .run();
  }

  async majEquipeSejour(id: number, teamId: string): Promise<void> {
    await this.db
      .prepare("UPDATE sejours_ir SET team_id = ? WHERE id = ?")
      .bind(teamId, id)
      .run();
  }

  async corrigerDateIr(s: {
    id: number;
    dateIr: string;
    dateEligibilite: string;
    retourPremature: boolean;
    joursManquants: number | null;
    admin: string;
    note: string | null;
    maintenant: string;
  }): Promise<void> {
    await this.db
      .prepare(
        `UPDATE sejours_ir SET
           date_ir = ?, date_eligibilite = ?, retour_premature = ?, jours_manquants = ?,
           corrige_par = ?, corrige_le = ?, note = ?
         WHERE id = ?`,
      )
      .bind(
        s.dateIr,
        s.dateEligibilite,
        s.retourPremature ? 1 : 0,
        s.joursManquants,
        s.admin,
        s.maintenant,
        s.note,
        s.id,
      )
      .run();
  }

  async lireSejour(id: number): Promise<SejourBd | null> {
    return await this.db
      .prepare("SELECT * FROM sejours_ir WHERE id = ?")
      .bind(id)
      .first<SejourBd>();
  }

  // -------------------------------------------------------------------------
  // Vues d'affichage
  // -------------------------------------------------------------------------

  /**
   * Séjours enrichis du nom du joueur et de l'équipe du pool.
   *
   * Le mode « courant » retient les séjours ouverts ET les retours prématurés
   * récents : une infraction ferme le séjour, elle disparaîtrait donc aussitôt
   * du tableau de bord alors que c'est précisément ce qu'un administrateur
   * doit voir.
   */
  async vueSejours(
    mode: "courant" | "tous",
    options: { depuis?: string; limite?: number } = {},
  ): Promise<
    (SejourBd & { nom: string | null; position: string | null; equipe: string | null })[]
  > {
    const limite = options.limite ?? 300;
    const filtre =
      mode === "courant"
        ? "WHERE s.ouvert = 1 OR (s.retour_premature = 1 AND s.date_retour >= ?)"
        : "";

    const requete = this.db.prepare(
      `SELECT s.*, j.nom AS nom, j.position AS position, e.nom AS equipe
       FROM sejours_ir s
       LEFT JOIN joueurs j ON j.fantrax_id = s.fantrax_id
       LEFT JOIN equipes e ON e.team_id = s.team_id
       ${filtre}
       ORDER BY s.ouvert DESC, s.date_eligibilite ASC, s.id DESC
       LIMIT ?`,
    );

    const { results } =
      mode === "courant"
        ? await requete.bind(options.depuis ?? "0000-00-00", limite).all()
        : await requete.bind(limite).all();

    return (results ?? []) as never;
  }

  /** Joueurs actuellement en slot farm, avec leurs parties en carrière. */
  async vueFarm(): Promise<
    {
      fantrax_id: string;
      team_id: string;
      equipe: string | null;
      nom: string | null;
      position: string | null;
      equipe_nhl: string | null;
      nhl_player_id: number | null;
      source_appariement: string | null;
      parties_jouees: number | null;
      recupere_le: string | null;
      statut_brut: string;
    }[]
  > {
    const { results } = await this.db
      .prepare(
        `SELECT r.fantrax_id, r.team_id, r.statut_brut,
                e.nom AS equipe,
                j.nom AS nom, COALESCE(r.position, j.position) AS position,
                j.equipe_nhl, j.nhl_player_id, j.source_appariement,
                c.parties_jouees, c.recupere_le
         FROM roster_courant r
         LEFT JOIN equipes e ON e.team_id = r.team_id
         LEFT JOIN joueurs j ON j.fantrax_id = r.fantrax_id
         LEFT JOIN cache_pj c ON c.nhl_player_id = j.nhl_player_id
         WHERE r.statut_type = 'FARM'`,
      )
      .all();
    return (results ?? []) as never;
  }

  /** Joueurs en slot farm dont l'identifiant NHL reste inconnu. */
  async joueursFarmSansAppariement(): Promise<
    {
      fantrax_id: string;
      nom: string | null;
      nom_normalise: string | null;
      equipe_nhl: string | null;
    }[]
  > {
    const { results } = await this.db
      .prepare(
        `SELECT r.fantrax_id, j.nom, j.nom_normalise, j.equipe_nhl
         FROM roster_courant r
         LEFT JOIN joueurs j ON j.fantrax_id = r.fantrax_id
         WHERE r.statut_type = 'FARM' AND j.nhl_player_id IS NULL`,
      )
      .all();
    return (results ?? []) as never;
  }

  // -------------------------------------------------------------------------
  // Périodes de roster
  // -------------------------------------------------------------------------

  async majPeriodes(periodes: readonly Periode[], maintenant: string): Promise<void> {
    const requetes = periodes.map((p) =>
      this.db
        .prepare(
          `INSERT INTO periodes (numero, debut, fin, date_debut, debut_ms, fin_ms, maj_le)
           VALUES (?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(numero) DO UPDATE SET
             debut = excluded.debut, fin = excluded.fin,
             date_debut = excluded.date_debut,
             debut_ms = excluded.debut_ms, fin_ms = excluded.fin_ms,
             maj_le = excluded.maj_le`,
        )
        .bind(p.numero, p.debut, p.fin, p.dateDebut, p.debutMs, p.finMs, maintenant),
    );
    await this.executerParLots(requetes);
  }

  async lirePeriodes(): Promise<Periode[]> {
    const { results } = await this.db
      .prepare(
        "SELECT numero, debut, fin, date_debut, debut_ms, fin_ms FROM periodes ORDER BY numero",
      )
      .all<{
        numero: number;
        debut: string;
        fin: string;
        date_debut: string;
        debut_ms: number;
        fin_ms: number;
      }>();
    return (results ?? []).map((l) => ({
      numero: l.numero,
      debut: l.debut,
      fin: l.fin,
      dateDebut: l.date_debut,
      debutMs: l.debut_ms,
      finMs: l.fin_ms,
    }));
  }

  async compterPeriodes(): Promise<number> {
    const ligne = await this.db
      .prepare("SELECT COUNT(*) AS n FROM periodes")
      .first<{ n: number }>();
    return ligne?.n ?? 0;
  }

  // -------------------------------------------------------------------------
  // Claims (transactions)
  // -------------------------------------------------------------------------

  async lireMouvementsClaims(
    saison: number,
  ): Promise<
    {
      id: number;
      team_id: string;
      saison: number;
      type: TypeMouvementClaim;
      quantite: number;
      date_effet: string;
      motif: string | null;
      fantrax_id: string | null;
      contrepartie_team_id: string | null;
      auteur: string;
      cree_le: string;
    }[]
  > {
    const { results } = await this.db
      .prepare(
        `SELECT id, team_id, saison, type, quantite, date_effet, motif,
                fantrax_id, contrepartie_team_id, auteur, cree_le
         FROM claims_mouvements WHERE saison = ?
         ORDER BY date_effet DESC, id DESC`,
      )
      .bind(saison)
      .all();
    return (results ?? []) as never;
  }

  async ajouterMouvementClaim(m: {
    teamId: string;
    saison: number;
    type: TypeMouvementClaim;
    quantite: number;
    dateEffet: string;
    motif?: string | null;
    fantraxId?: string | null;
    contrepartieTeamId?: string | null;
    auteur: string;
    executionId?: number | null;
    maintenant: string;
  }): Promise<void> {
    await this.db
      .prepare(
        `INSERT INTO claims_mouvements
           (team_id, saison, type, quantite, date_effet, motif, fantrax_id,
            contrepartie_team_id, auteur, execution_id, cree_le)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      )
      .bind(
        m.teamId,
        m.saison,
        m.type,
        m.quantite,
        m.dateEffet,
        m.motif ?? null,
        m.fantraxId ?? null,
        m.contrepartieTeamId ?? null,
        m.auteur,
        m.executionId ?? null,
        m.maintenant,
      )
      .run();
  }

  /**
   * Enregistre un claim consommé.
   * L'index unique sur (saison, équipe, joueur) empêche de compter deux fois
   * la même acquisition ; le conflit est ignoré silencieusement.
   * Retourne vrai si le mouvement a bien été ajouté.
   */
  async enregistrerClaimUtilise(m: {
    teamId: string;
    saison: number;
    fantraxId: string;
    dateEffet: string;
    executionId: number;
    maintenant: string;
  }): Promise<boolean> {
    const resultat = await this.db
      .prepare(
        `INSERT INTO claims_mouvements
           (team_id, saison, type, quantite, date_effet, motif, fantrax_id,
            auteur, execution_id, cree_le)
         VALUES (?, ?, 'UTILISE', -1, ?, 'Acquisition détectée automatiquement', ?,
                 'robot', ?, ?)
         ON CONFLICT DO NOTHING`,
      )
      .bind(
        m.teamId,
        m.saison,
        m.dateEffet,
        m.fantraxId,
        m.executionId,
        m.maintenant,
      )
      .run();
    return (resultat.meta?.changes ?? 0) > 0;
  }

  /**
   * Équipes n'ayant encore aucun mouvement pour la saison.
   * Sert à ne doter que celles-là : une équipe dont un administrateur a déjà
   * saisi le solde à la main ne doit pas recevoir une dotation en plus, ce qui
   * doublerait son compte.
   */
  async equipesSansMouvementClaims(saison: number): Promise<string[]> {
    const { results } = await this.db
      .prepare(
        `SELECT e.team_id FROM equipes e
         WHERE NOT EXISTS (
           SELECT 1 FROM claims_mouvements m
           WHERE m.team_id = e.team_id AND m.saison = ?
         )`,
      )
      .bind(saison)
      .all<{ team_id: string }>();
    return (results ?? []).map((l) => l.team_id);
  }

  /** Vrai si la dotation de début de saison a déjà été distribuée. */
  async allocationClaimsFaite(saison: number): Promise<boolean> {
    const ligne = await this.db
      .prepare(
        "SELECT COUNT(*) AS n FROM claims_mouvements WHERE saison = ? AND type = 'ALLOCATION'",
      )
      .bind(saison)
      .first<{ n: number }>();
    return (ligne?.n ?? 0) > 0;
  }

  async supprimerMouvementClaim(id: number): Promise<boolean> {
    const resultat = await this.db
      .prepare("DELETE FROM claims_mouvements WHERE id = ?")
      .bind(id)
      .run();
    return (resultat.meta?.changes ?? 0) > 0;
  }

  // -------------------------------------------------------------------------
  // Journaux
  // -------------------------------------------------------------------------

  async demarrerExecution(declencheur: string, complet: boolean, maintenant: string): Promise<number> {
    const ligne = await this.db
      .prepare(
        `INSERT INTO executions (demarre_le, declencheur, complet) VALUES (?, ?, ?)
         RETURNING id`,
      )
      .bind(maintenant, declencheur, complet ? 1 : 0)
      .first<{ id: number }>();
    return ligne?.id ?? 0;
  }

  async terminerExecution(
    id: number,
    bilan: {
      succes: boolean;
      fantraxOk: boolean;
      nhlOk: boolean;
      joueursVus: number;
      sourcesNhlLues: number;
      pjRafraichies: number;
      irOuverts: number;
      irFermes: number;
      retoursPrematures: number;
      statutsInconnus: number;
      erreur: string | null;
      details: unknown;
    },
    maintenant: string,
  ): Promise<void> {
    await this.db
      .prepare(
        `UPDATE executions SET
           termine_le = ?, succes = ?, fantrax_ok = ?, nhl_ok = ?, joueurs_vus = ?,
           sources_nhl_lues = ?, pj_rafraichies = ?, ir_ouverts = ?, ir_fermes = ?,
           retours_prematures = ?, statuts_inconnus = ?, erreur = ?, details = ?
         WHERE id = ?`,
      )
      .bind(
        maintenant,
        bilan.succes ? 1 : 0,
        bilan.fantraxOk ? 1 : 0,
        bilan.nhlOk ? 1 : 0,
        bilan.joueursVus,
        bilan.sourcesNhlLues,
        bilan.pjRafraichies,
        bilan.irOuverts,
        bilan.irFermes,
        bilan.retoursPrematures,
        bilan.statutsInconnus,
        bilan.erreur,
        JSON.stringify(bilan.details ?? {}),
        id,
      )
      .run();
  }

  async dernieresExecutions(limite = 20): Promise<Record<string, unknown>[]> {
    const { results } = await this.db
      .prepare("SELECT * FROM executions ORDER BY id DESC LIMIT ?")
      .bind(limite)
      .all();
    return (results ?? []) as never;
  }

  async journaliser(entree: {
    admin: string;
    action: string;
    cible?: string | null;
    cibleId?: string | null;
    details?: unknown;
    maintenant: string;
  }): Promise<void> {
    await this.db
      .prepare(
        `INSERT INTO journal_admin (le, admin, action, cible, cible_id, details)
         VALUES (?, ?, ?, ?, ?, ?)`,
      )
      .bind(
        entree.maintenant,
        entree.admin,
        entree.action,
        entree.cible ?? null,
        entree.cibleId ?? null,
        entree.details === undefined ? null : JSON.stringify(entree.details),
      )
      .run();
  }

  async lireJournal(limite = 100): Promise<Record<string, unknown>[]> {
    const { results } = await this.db
      .prepare("SELECT * FROM journal_admin ORDER BY id DESC LIMIT ?")
      .bind(limite)
      .all();
    return (results ?? []) as never;
  }
}
