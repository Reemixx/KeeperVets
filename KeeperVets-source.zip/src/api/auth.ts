/**
 * Authentification des administrateurs.
 *
 * Le pool compte trois administrateurs qui partagent un mot de passe unique :
 * il n'y a donc pas de comptes individuels à gérer. Pour conserver malgré tout
 * une traçabilité, l'administrateur choisit son nom au moment de se connecter ;
 * ce nom est scellé dans un cookie signé et sert à alimenter le journal.
 *
 * Limite assumée : ce dispositif n'empêche pas un administrateur de se déclarer
 * sous le nom d'un autre. Il répond au besoin de traçabilité, pas à un besoin
 * d'authentification forte.
 */

import { CONFIG, listeAdmins, type Env } from "../config.js";

const NOM_COOKIE = "kv_session";

export interface Session {
  admin: string;
  /** Date d'expiration, en millisecondes depuis l'époque Unix. */
  exp: number;
}

const encodeur = new TextEncoder();

function base64UrlEncoder(octets: Uint8Array): string {
  let binaire = "";
  for (const o of octets) binaire += String.fromCharCode(o);
  return btoa(binaire).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function base64UrlDecoder(texte: string): Uint8Array {
  const complete = texte.replace(/-/g, "+").replace(/_/g, "/");
  const binaire = atob(complete + "=".repeat((4 - (complete.length % 4)) % 4));
  return Uint8Array.from(binaire, (c) => c.charCodeAt(0));
}

async function cle(secret: string): Promise<CryptoKey> {
  return crypto.subtle.importKey(
    "raw",
    encodeur.encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign", "verify"],
  );
}

/**
 * Comparaison à temps constant : évite de révéler le mot de passe
 * par la durée de la comparaison.
 */
export function comparerConstant(a: string, b: string): boolean {
  const oa = encodeur.encode(a);
  const ob = encodeur.encode(b);
  // La différence de longueur reste observable ; on compare quand même
  // l'intégralité des octets pour ne pas court-circuiter.
  let difference = oa.length ^ ob.length;
  const taille = Math.max(oa.length, ob.length);
  for (let i = 0; i < taille; i++) {
    difference |= (oa[i] ?? 0) ^ (ob[i] ?? 0);
  }
  return difference === 0;
}

/** Fabrique un jeton de session signé. */
export async function creerJeton(admin: string, secret: string): Promise<string> {
  const charge: Session = {
    admin,
    exp: Date.now() + CONFIG.sessionDureeHeures * 3_600_000,
  };
  const corps = base64UrlEncoder(encodeur.encode(JSON.stringify(charge)));
  const signature = await crypto.subtle.sign("HMAC", await cle(secret), encodeur.encode(corps));
  return `${corps}.${base64UrlEncoder(new Uint8Array(signature))}`;
}

/** Vérifie un jeton et retourne la session, ou null si invalide ou expiré. */
export async function verifierJeton(
  jeton: string | null,
  secret: string,
): Promise<Session | null> {
  if (!jeton) return null;
  const [corps, signature] = jeton.split(".");
  if (!corps || !signature) return null;

  try {
    const valide = await crypto.subtle.verify(
      "HMAC",
      await cle(secret),
      base64UrlDecoder(signature),
      encodeur.encode(corps),
    );
    if (!valide) return null;

    const session = JSON.parse(
      new TextDecoder().decode(base64UrlDecoder(corps)),
    ) as Session;
    if (typeof session.exp !== "number" || session.exp < Date.now()) return null;
    if (typeof session.admin !== "string" || session.admin.length === 0) return null;
    return session;
  } catch {
    return null;
  }
}

/** Extrait le jeton de session des en-têtes de la requête. */
export function lireCookieSession(requete: Request): string | null {
  const brut = requete.headers.get("cookie");
  if (!brut) return null;
  for (const morceau of brut.split(";")) {
    const [nom, ...reste] = morceau.trim().split("=");
    if (nom === NOM_COOKIE) return reste.join("=");
  }
  return null;
}

/** En-tête Set-Cookie pour ouvrir une session. */
export function cookieOuverture(jeton: string, securise: boolean): string {
  const attributs = [
    `${NOM_COOKIE}=${jeton}`,
    "Path=/",
    "HttpOnly",
    "SameSite=Strict",
    `Max-Age=${CONFIG.sessionDureeHeures * 3600}`,
  ];
  if (securise) attributs.push("Secure");
  return attributs.join("; ");
}

/** En-tête Set-Cookie pour fermer une session. */
export function cookieFermeture(): string {
  return `${NOM_COOKIE}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0`;
}

/** Retourne la session courante si la requête est authentifiée. */
export async function sessionCourante(
  requete: Request,
  env: Env,
): Promise<Session | null> {
  const session = await verifierJeton(lireCookieSession(requete), env.SESSION_SECRET);
  if (!session) return null;
  // Un administrateur retiré de la liste perd immédiatement son accès.
  if (!listeAdmins(env).includes(session.admin)) return null;
  return session;
}
