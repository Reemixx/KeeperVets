-- Retire les séjours de démonstration créés par scripts/demo-blesses.sql.
-- Les séjours réels détectés par le robot ne sont pas touchés.
--
--   npx wrangler d1 execute keepervets --local --file scripts/demo-blesses-nettoyage.sql

DELETE FROM sejours_ir WHERE statut_brut_ir = 'DEMO';
