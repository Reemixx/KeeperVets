-- Jeu de démonstration du module « liste des blessés ».
--
-- Hors-saison, aucun joueur n'est sur IR : ce script crée quatre séjours
-- fictifs couvrant les quatre statuts, pour vérifier le rendu du tableau de
-- bord avant le début de la saison.
--
-- Les dates sont RELATIVES à la date d'exécution : le script reste valable
-- n'importe quand. Il est ré-exécutable (il purge d'abord ses propres données).
--
-- Utilisation :
--   npx wrangler d1 execute keepervets --local --file scripts/demo-blesses.sql
--
-- Nettoyage :
--   npx wrangler d1 execute keepervets --local --file scripts/demo-blesses-nettoyage.sql
--
-- ⚠️ Les séjours créés portent le statut « DEMO » : ils sont reconnaissables
-- et n'interfèrent pas avec les séjours réels détectés par le robot.

DELETE FROM sejours_ir WHERE statut_brut_ir = 'DEMO';

-- 🔴 Bloqué — mis sur IR il y a 3 jours, jour 3/10.
INSERT INTO sejours_ir
  (fantrax_id, team_id, date_ir, date_ir_detectee, detecte_le, date_eligibilite,
   statut_brut_ir, ouvert, cree_le)
SELECT fantrax_id, team_id,
       date('now', '-3 days'), date('now', '-3 days'), datetime('now', '-3 days'),
       date('now', '+7 days'), 'DEMO', 1, datetime('now', '-3 days')
FROM roster_courant WHERE statut_type = 'ACTIF'
ORDER BY fantrax_id LIMIT 1 OFFSET 0;

-- 🟡 Éligible demain — mis sur IR il y a 9 jours, jour 9/10.
INSERT INTO sejours_ir
  (fantrax_id, team_id, date_ir, date_ir_detectee, detecte_le, date_eligibilite,
   statut_brut_ir, ouvert, cree_le)
SELECT fantrax_id, team_id,
       date('now', '-9 days'), date('now', '-9 days'), datetime('now', '-9 days'),
       date('now', '+1 days'), 'DEMO', 1, datetime('now', '-9 days')
FROM roster_courant WHERE statut_type = 'ACTIF'
ORDER BY fantrax_id LIMIT 1 OFFSET 1;

-- 🟢 Éligible maintenant — mis sur IR il y a 12 jours ; la date a par ailleurs
-- été corrigée par un administrateur (détectée un jour plus tard).
INSERT INTO sejours_ir
  (fantrax_id, team_id, date_ir, date_ir_detectee, detecte_le, date_eligibilite,
   statut_brut_ir, ouvert, corrige_par, corrige_le, note, cree_le)
SELECT fantrax_id, team_id,
       date('now', '-12 days'), date('now', '-11 days'), datetime('now', '-11 days'),
       date('now', '-2 days'), 'DEMO', 1,
       'Pierre-Luc', datetime('now', '-10 days'), 'Date confirmée avec le pooler',
       datetime('now', '-11 days')
FROM roster_courant WHERE statut_type = 'ACTIF'
ORDER BY fantrax_id LIMIT 1 OFFSET 2;

-- ⚠️ Retour prématuré — réactivé après 4 jours seulement : 6 jours écourtés.
INSERT INTO sejours_ir
  (fantrax_id, team_id, date_ir, date_ir_detectee, detecte_le, date_eligibilite,
   statut_brut_ir, date_retour, retour_detecte_le, statut_apres,
   retour_premature, jours_manquants, motif_fermeture, ouvert, cree_le)
SELECT fantrax_id, team_id,
       date('now', '-20 days'), date('now', '-20 days'), datetime('now', '-20 days'),
       date('now', '-10 days'), 'DEMO',
       date('now', '-16 days'), datetime('now', '-16 days'), 'ACTIVE',
       1, 6, 'retour', 0, datetime('now', '-20 days')
FROM roster_courant WHERE statut_type = 'ACTIF'
ORDER BY fantrax_id LIMIT 1 OFFSET 3;
