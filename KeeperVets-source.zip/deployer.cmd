@echo off
REM ===========================================================================
REM  Le Keeper des Vets - deploiement sur Cloudflare
REM
REM  Double-clique sur ce fichier pour publier l'application en ligne.
REM  Le script est re-executable : il ne refait que ce qui manque.
REM ===========================================================================

title Le Keeper des Vets - deploiement
cd /d "%~dp0"

powershell -NoProfile -ExecutionPolicy Bypass -File "scripts\deployer.ps1"

echo.
pause
