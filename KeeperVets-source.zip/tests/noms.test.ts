import { describe, expect, it } from "vitest";
import {
  cleFamilleEquipe,
  expressionRecherchRecords,
  inverserNomFantrax,
  nomDeFamille,
  normaliser,
  variantesNormalisees,
} from "../src/domain/noms.js";

describe("normaliser", () => {
  it("retire les accents et met en minuscules", () => {
    expect(normaliser("Tomáš Hertl")).toBe("tomas hertl");
    expect(normaliser("Émile Bélanger")).toBe("emile belanger");
    expect(normaliser("MAVRIK BOURQUE")).toBe("mavrik bourque");
  });

  it("supprime la ponctuation et les chiffres", () => {
    expect(normaliser("K'Andre Miller")).toBe("kandre miller");
    expect(normaliser("Marc-Édouard Vlasic")).toBe("marcedouard vlasic");
    expect(normaliser("T.J. Oshie")).toBe("tj oshie");
    expect(normaliser("Zach Werenski Jr. 2")).toBe("zach werenski jr");
  });

  it("réduit les espaces multiples et coupe les extrémités", () => {
    expect(normaliser("  Nick   Suzuki  ")).toBe("nick suzuki");
  });

  it("gère les valeurs vides sans planter", () => {
    expect(normaliser("")).toBe("");
    expect(normaliser(null)).toBe("");
    expect(normaliser(undefined)).toBe("");
  });
});

describe("inverserNomFantrax", () => {
  it("inverse le format « Nom, Prénom »", () => {
    expect(inverserNomFantrax("Bourque, Mavrik")).toBe("Mavrik Bourque");
    expect(inverserNomFantrax("Tavares, John")).toBe("John Tavares");
    expect(inverserNomFantrax("Woll, Joseph")).toBe("Joseph Woll");
  });

  it("gère les noms composés après la virgule", () => {
    expect(inverserNomFantrax("Van Riemsdyk, James")).toBe(
      "James Van Riemsdyk",
    );
    expect(inverserNomFantrax("Miller, K'Andre")).toBe("K'Andre Miller");
  });

  it("retourne la chaîne telle quelle en l'absence de virgule", () => {
    expect(inverserNomFantrax("Sidney Crosby")).toBe("Sidney Crosby");
  });

  it("gère les valeurs vides sans planter", () => {
    expect(inverserNomFantrax(null)).toBe("");
    expect(inverserNomFantrax("")).toBe("");
  });

  it("s'enchaîne correctement avec la normalisation", () => {
    expect(normaliser(inverserNomFantrax("Kochetkov, Pyotr"))).toBe(
      "pyotr kochetkov",
    );
  });
});

describe("expressionRecherchRecords", () => {
  it("construit l'expression cayenne attendue", () => {
    expect(expressionRecherchRecords("Nick Suzuki")).toBe(
      'fullName likeIgnoreCase "Nick Suzuki"',
    );
  });

  it("neutralise les guillemets qui casseraient l'expression", () => {
    expect(expressionRecherchRecords('Bob "Le Gros" Tremblay')).toBe(
      'fullName likeIgnoreCase "Bob Le Gros Tremblay"',
    );
  });
});

/**
 * Cas réels rencontrés le 2026-09-01 : la normalisation seule ne rapprochait
 * pas ces joueurs, alors qu'ils existent bel et bien dans la LNH.
 */
describe("variantesNormalisees", () => {
  it("produit une forme avec et une forme sans trait d'union", () => {
    expect(variantesNormalisees("Axel Sandin-Pellikka")).toEqual([
      "axel sandinpellikka",
      "axel sandin pellikka",
    ]);
  });

  it("permet de rapprocher les deux orthographes de Sandin-Pellikka", () => {
    const cotesNhl = variantesNormalisees("Axel Sandin-Pellikka");
    const cotesFantrax = variantesNormalisees("Axel Sandin Pellikka");
    const commun = cotesNhl.filter((v) => cotesFantrax.includes(v));
    expect(commun).toContain("axel sandin pellikka");
  });

  it("ne produit qu'une seule forme pour un nom simple", () => {
    expect(variantesNormalisees("Nick Suzuki")).toEqual(["nick suzuki"]);
  });

  it("gère les apostrophes des noms comme K'Andre Miller", () => {
    const variantes = variantesNormalisees("K'Andre Miller");
    expect(variantes).toContain("kandre miller");
    expect(variantes).toContain("k andre miller");
  });

  it("retourne une liste vide pour une valeur absente", () => {
    expect(variantesNormalisees(null)).toEqual([]);
    expect(variantesNormalisees("")).toEqual([]);
  });
});

describe("nomDeFamille", () => {
  it("extrait le dernier segment du nom", () => {
    expect(nomDeFamille("Ben Kindel")).toBe("kindel");
    expect(nomDeFamille("Benjamin Kindel")).toBe("kindel");
  });

  it("traite le trait d'union comme un séparateur", () => {
    expect(nomDeFamille("Axel Sandin-Pellikka")).toBe("pellikka");
    expect(nomDeFamille("Axel Sandin Pellikka")).toBe("pellikka");
  });

  it("retourne une chaîne vide sans nom", () => {
    expect(nomDeFamille(null)).toBe("");
  });
});

describe("cleFamilleEquipe", () => {
  it("rapproche un diminutif de son prénom complet", () => {
    // « Ben Kindel » côté LNH, « Benjamin Kindel » côté Fantrax, tous deux à Pittsburgh.
    expect(cleFamilleEquipe("PIT", "Kindel")).toBe("PIT|kindel");
    expect(cleFamilleEquipe("PIT", "Benjamin Kindel")).toBe("PIT|kindel");
  });

  it("normalise la casse du code d'équipe", () => {
    expect(cleFamilleEquipe("det", "Sandin-Pellikka")).toBe("DET|pellikka");
  });

  it("refuse de produire une clé incomplète", () => {
    expect(cleFamilleEquipe(null, "Kindel")).toBe("");
    expect(cleFamilleEquipe("PIT", null)).toBe("");
    expect(cleFamilleEquipe("", "")).toBe("");
  });
});
