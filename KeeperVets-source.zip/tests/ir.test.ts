import { describe, expect, it } from "vitest";
import {
  JOURS_IR,
  ajouterJours,
  calculerEligibilite,
  dateDuJour,
  ecartJours,
  evaluerRetour,
  jourDuSejour,
  joursRestants,
  statutAffichage,
  statutSejourOuvert,
} from "../src/domain/ir.js";

describe("calculerEligibilite", () => {
  it("respecte l'exemple de référence : IR le 5 novembre, retour le 15", () => {
    expect(calculerEligibilite("2026-11-05")).toBe("2026-11-15");
  });

  it("applique bien 10 jours de calendrier", () => {
    expect(JOURS_IR).toBe(10);
    expect(calculerEligibilite("2027-01-01")).toBe("2027-01-11");
  });

  it("traverse correctement une fin de mois", () => {
    expect(calculerEligibilite("2026-10-25")).toBe("2026-11-04");
    expect(calculerEligibilite("2026-12-28")).toBe("2027-01-07");
  });

  it("gère le 29 février d'une année bissextile", () => {
    // 2028 est bissextile : le 22 février + 10 jours = 3 mars.
    expect(calculerEligibilite("2028-02-22")).toBe("2028-03-03");
    // 2027 ne l'est pas : le 22 février + 10 jours = 4 mars.
    expect(calculerEligibilite("2027-02-22")).toBe("2027-03-04");
  });

  it("refuse une date mal formée", () => {
    expect(() => calculerEligibilite("05-11-2026")).toThrow();
    expect(() => calculerEligibilite("pas une date")).toThrow();
  });
});

describe("ajouterJours et ecartJours", () => {
  it("ajoute et retire des jours", () => {
    expect(ajouterJours("2026-11-05", 1)).toBe("2026-11-06");
    expect(ajouterJours("2026-11-05", -5)).toBe("2026-10-31");
  });

  it("calcule l'écart entre deux dates", () => {
    expect(ecartJours("2026-11-05", "2026-11-15")).toBe(10);
    expect(ecartJours("2026-11-15", "2026-11-05")).toBe(-10);
    expect(ecartJours("2026-11-05", "2026-11-05")).toBe(0);
  });

  it("n'est pas perturbé par le changement d'heure d'automne", () => {
    // L'heure avancée se termine le 1er novembre 2026 en Amérique du Nord.
    // Le calcul se fait en UTC, la journée civile ne doit pas se décaler.
    expect(ecartJours("2026-10-30", "2026-11-05")).toBe(6);
    expect(calculerEligibilite("2026-10-30")).toBe("2026-11-09");
  });

  it("n'est pas perturbé par le changement d'heure du printemps", () => {
    // L'heure avancée débute le 14 mars 2027.
    expect(ecartJours("2027-03-10", "2027-03-20")).toBe(10);
    expect(calculerEligibilite("2027-03-10")).toBe("2027-03-20");
  });
});

describe("jourDuSejour", () => {
  it("compte le jour de mise sur IR comme le jour 0", () => {
    expect(jourDuSejour("2026-11-05", "2026-11-05")).toBe(0);
    expect(jourDuSejour("2026-11-05", "2026-11-10")).toBe(5);
    expect(jourDuSejour("2026-11-05", "2026-11-15")).toBe(10);
  });

  it("plafonne à 10 pour rester lisible sur un long séjour", () => {
    expect(jourDuSejour("2026-11-05", "2026-12-25")).toBe(10);
  });

  it("ne descend pas sous zéro si la date corrigée est dans le futur", () => {
    expect(jourDuSejour("2026-11-05", "2026-11-01")).toBe(0);
  });
});

describe("statutSejourOuvert", () => {
  const dateIr = "2026-11-05"; // éligible le 15

  it("est bloqué tant qu'il reste plus d'une journée", () => {
    expect(statutSejourOuvert(dateIr, "2026-11-05")).toBe("BLOQUE");
    expect(statutSejourOuvert(dateIr, "2026-11-13")).toBe("BLOQUE");
  });

  it("passe à « éligible demain » la veille", () => {
    expect(statutSejourOuvert(dateIr, "2026-11-14")).toBe("ELIGIBLE_DEMAIN");
  });

  it("devient éligible le jour même, et le reste ensuite", () => {
    expect(statutSejourOuvert(dateIr, "2026-11-15")).toBe("ELIGIBLE");
    expect(statutSejourOuvert(dateIr, "2026-11-20")).toBe("ELIGIBLE");
  });
});

describe("joursRestants", () => {
  it("décompte jusqu'à l'éligibilité", () => {
    expect(joursRestants("2026-11-05", "2026-11-05")).toBe(10);
    expect(joursRestants("2026-11-05", "2026-11-14")).toBe(1);
  });

  it("ne descend pas sous zéro une fois éligible", () => {
    expect(joursRestants("2026-11-05", "2026-11-15")).toBe(0);
    expect(joursRestants("2026-11-05", "2026-12-01")).toBe(0);
  });
});

describe("evaluerRetour", () => {
  it("ne signale rien si le joueur a purgé ses 10 jours", () => {
    expect(evaluerRetour("2026-11-05", "2026-11-15")).toEqual({
      premature: false,
      joursManquants: 0,
    });
    expect(evaluerRetour("2026-11-05", "2026-11-20")).toEqual({
      premature: false,
      joursManquants: 0,
    });
  });

  it("détecte une infraction et chiffre les jours écourtés", () => {
    expect(evaluerRetour("2026-11-05", "2026-11-14")).toEqual({
      premature: true,
      joursManquants: 1,
    });
    expect(evaluerRetour("2026-11-05", "2026-11-08")).toEqual({
      premature: true,
      joursManquants: 7,
    });
  });

  it("traite un retour le jour même comme 10 jours écourtés", () => {
    expect(evaluerRetour("2026-11-05", "2026-11-05")).toEqual({
      premature: true,
      joursManquants: 10,
    });
  });
});

describe("statutAffichage", () => {
  it("conserve le marqueur d'infraction sur un séjour clos prématurément", () => {
    const statut = statutAffichage(
      {
        dateIr: "2026-11-05",
        ouvert: false,
        dateRetour: "2026-11-09",
        retourPremature: true,
      },
      "2027-01-15",
    );
    expect(statut).toBe("RETOUR_PREMATURE");
  });

  it("évalue normalement un séjour encore ouvert", () => {
    expect(
      statutAffichage(
        {
          dateIr: "2026-11-05",
          ouvert: true,
          dateRetour: null,
          retourPremature: false,
        },
        "2026-11-14",
      ),
    ).toBe("ELIGIBLE_DEMAIN");
  });
});

describe("dateDuJour", () => {
  it("retourne la date civile du Québec, pas la date UTC", () => {
    // 2026-11-06T02:30:00Z correspond au 5 novembre 21 h 30 à Toronto.
    const instant = new Date("2026-11-06T02:30:00Z");
    expect(dateDuJour("America/Toronto", instant)).toBe("2026-11-05");
    expect(instant.toISOString().slice(0, 10)).toBe("2026-11-06");
  });

  it("produit un format YYYY-MM-DD", () => {
    expect(dateDuJour("America/Toronto", new Date("2026-01-02T18:00:00Z"))).toBe(
      "2026-01-02",
    );
  });
});
