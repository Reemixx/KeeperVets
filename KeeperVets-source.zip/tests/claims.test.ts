import { describe, expect, it } from "vitest";
import {
  CLAIMS_PAR_SAISON,
  calculerSolde,
  libelleNiveauClaims,
  messageClaims,
  niveauPourSolde,
  resumerParEquipe,
  validerEchange,
  type MouvementClaim,
} from "../src/domain/claims.js";

describe("calculerSolde", () => {
  it("additionne les mouvements", () => {
    const mouvements: MouvementClaim[] = [
      { teamId: "a", type: "ALLOCATION", quantite: 4 },
      { teamId: "a", type: "UTILISE", quantite: -1 },
      { teamId: "a", type: "RECU", quantite: 1 },
    ];
    expect(calculerSolde(mouvements)).toBe(4);
  });

  it("retourne zéro sans mouvement", () => {
    expect(calculerSolde([])).toBe(0);
  });
});

/**
 * Cas réel décrit par l'administrateur : chaque équipe reçoit 4 claims, et les
 * Gamblers en ont cédé un aux Déesses de Laval. Résultat attendu : 5 et 3.
 */
describe("resumerParEquipe — cas réel de l'échange Gamblers / Déesses", () => {
  const mouvements: MouvementClaim[] = [
    { teamId: "deesses", type: "ALLOCATION", quantite: CLAIMS_PAR_SAISON },
    { teamId: "gamblers", type: "ALLOCATION", quantite: CLAIMS_PAR_SAISON },
    { teamId: "gamblers", type: "CEDE", quantite: -1 },
    { teamId: "deesses", type: "RECU", quantite: 1 },
  ];

  it("donne 5 aux Déesses et 3 aux Gamblers", () => {
    const resume = resumerParEquipe(mouvements);
    expect(resume.get("deesses")?.solde).toBe(5);
    expect(resume.get("gamblers")?.solde).toBe(3);
  });

  it("conserve le total de la ligue lors d'un échange", () => {
    const total = [...resumerParEquipe(mouvements).values()].reduce(
      (s, e) => s + e.solde,
      0,
    );
    expect(total).toBe(2 * CLAIMS_PAR_SAISON);
  });

  it("ventile correctement reçus et cédés", () => {
    const resume = resumerParEquipe(mouvements);
    expect(resume.get("deesses")?.recus).toBe(1);
    expect(resume.get("deesses")?.cedes).toBe(0);
    expect(resume.get("gamblers")?.cedes).toBe(1);
    expect(resume.get("gamblers")?.recus).toBe(0);
  });
});

describe("resumerParEquipe", () => {
  it("compte les claims utilisés en valeur absolue", () => {
    const resume = resumerParEquipe([
      { teamId: "a", type: "ALLOCATION", quantite: 4 },
      { teamId: "a", type: "UTILISE", quantite: -1 },
      { teamId: "a", type: "UTILISE", quantite: -1 },
    ]);
    expect(resume.get("a")?.utilises).toBe(2);
    expect(resume.get("a")?.solde).toBe(2);
  });

  it("prend en compte les ajustements manuels, positifs comme négatifs", () => {
    const resume = resumerParEquipe([
      { teamId: "a", type: "ALLOCATION", quantite: 4 },
      { teamId: "a", type: "CORRECTION", quantite: -2 },
      { teamId: "a", type: "CORRECTION", quantite: 1 },
    ]);
    expect(resume.get("a")?.corrections).toBe(-1);
    expect(resume.get("a")?.solde).toBe(3);
  });
});

describe("niveauPourSolde", () => {
  it("classe les soldes par urgence", () => {
    expect(niveauPourSolde(-1)).toBe("NEGATIF");
    expect(niveauPourSolde(0)).toBe("EPUISE");
    expect(niveauPourSolde(1)).toBe("DERNIER");
    expect(niveauPourSolde(2)).toBe("FAIBLE");
    expect(niveauPourSolde(3)).toBe("OK");
    expect(niveauPourSolde(5)).toBe("OK");
  });

  it("distingue « pas encore doté » de « épuisé »", () => {
    // Avant la dotation du début de saison, un solde nul ne veut pas dire
    // que l'équipe a consommé ses claims.
    expect(niveauPourSolde(0, false)).toBe("NON_DOTE");
    expect(niveauPourSolde(0, true)).toBe("EPUISE");
  });

  it("fournit un libellé pour chaque niveau", () => {
    for (const solde of [-1, 0, 1, 2, 4]) {
      expect(libelleNiveauClaims(niveauPourSolde(solde))).toMatch(/\S/);
    }
    expect(libelleNiveauClaims(niveauPourSolde(0, false))).toContain("Pas encore");
  });
});

describe("validerEchange", () => {
  const base = { deTeamId: "a", versTeamId: "b", quantite: 1, soldeSource: 4 };

  it("accepte un échange normal", () => {
    expect(validerEchange(base)).toEqual({ ok: true });
  });

  it("refuse de céder plus de claims qu'on en possède", () => {
    const r = validerEchange({ ...base, quantite: 5, soldeSource: 3 });
    expect(r.ok).toBe(false);
    if (!r.ok) expect(r.erreur).toContain("3 claims");
  });

  it("autorise une équipe à céder tout ce qu'elle a", () => {
    expect(validerEchange({ ...base, quantite: 3, soldeSource: 3 })).toEqual({ ok: true });
  });

  it("refuse un échange d'une équipe vers elle-même", () => {
    const r = validerEchange({ ...base, versTeamId: "a" });
    expect(r.ok).toBe(false);
  });

  it("refuse une quantité nulle, négative ou fractionnaire", () => {
    expect(validerEchange({ ...base, quantite: 0 }).ok).toBe(false);
    expect(validerEchange({ ...base, quantite: -1 }).ok).toBe(false);
    expect(validerEchange({ ...base, quantite: 1.5 }).ok).toBe(false);
  });

  it("refuse un échange dont une équipe manque", () => {
    expect(validerEchange({ ...base, deTeamId: "" }).ok).toBe(false);
    expect(validerEchange({ ...base, versTeamId: "" }).ok).toBe(false);
  });
});

describe("messageClaims", () => {
  it("accorde le singulier et le pluriel", () => {
    expect(messageClaims("Déesses de Laval", 1)).toContain("reste 1 claim ");
    expect(messageClaims("Déesses de Laval", 3)).toContain("reste 3 claims");
  });

  it("signale un solde épuisé", () => {
    const m = messageClaims("Gamblers de Las Vegas", 0);
    expect(m).toContain("n'a plus de claim");
  });

  it("signale un déficit", () => {
    const m = messageClaims("Gamblers de Las Vegas", -1);
    expect(m).toContain("déficit");
  });

  it("signale une dotation pas encore distribuée", () => {
    const m = messageClaims("Voisins de Laval", 0, false);
    expect(m).toContain("n'a pas encore été");
  });
});
