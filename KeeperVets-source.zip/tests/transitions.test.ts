import { describe, expect, it } from "vitest";
import {
  detecterTransitions,
  resoudreTypeStatut,
  type EtatConnu,
  type EtatObserve,
} from "../src/domain/transitions.js";
import type { TypeStatut } from "../src/domain/types.js";

const observe = (
  fantraxId: string,
  teamId: string,
  statutBrut: string,
  statutType: TypeStatut,
): EtatObserve => ({
  fantraxId,
  teamId,
  position: "F",
  statutBrut,
  statutType,
});

const connu = (
  fantraxId: string,
  teamId: string,
  statutBrut: string,
  statutType: TypeStatut,
): EtatConnu => ({ fantraxId, teamId, statutBrut, statutType });

describe("detecterTransitions", () => {
  it("détecte une mise sur la liste des blessés", () => {
    const t = detecterTransitions(
      [connu("p1", "e1", "ACTIVE", "ACTIF")],
      [observe("p1", "e1", "INJURED_RESERVE", "IR")],
    );
    expect(t).toEqual([
      {
        genre: "ENTREE_IR",
        fantraxId: "p1",
        teamId: "e1",
        statutBrut: "INJURED_RESERVE",
      },
    ]);
  });

  it("détecte un retour d'IR et conserve le statut d'arrivée", () => {
    const t = detecterTransitions(
      [connu("p1", "e1", "IR", "IR")],
      [observe("p1", "e1", "ACTIVE", "ACTIF")],
    );
    expect(t).toEqual([
      { genre: "SORTIE_IR", fantraxId: "p1", teamId: "e1", statutApres: "ACTIVE" },
    ]);
  });

  it("traite un retour vers le farm comme une sortie d'IR", () => {
    const t = detecterTransitions(
      [connu("p1", "e1", "IR", "IR")],
      [observe("p1", "e1", "MINORS", "FARM")],
    );
    expect(t.map((x) => x.genre)).toEqual(["SORTIE_IR"]);
  });

  it("ne signale rien quand le statut ne change pas", () => {
    const t = detecterTransitions(
      [
        connu("p1", "e1", "ACTIVE", "ACTIF"),
        connu("p2", "e1", "IR", "IR"),
        connu("p3", "e2", "MINORS", "FARM"),
      ],
      [
        observe("p1", "e1", "ACTIVE", "ACTIF"),
        observe("p2", "e1", "IR", "IR"),
        observe("p3", "e2", "MINORS", "FARM"),
      ],
    );
    expect(t).toEqual([]);
  });

  it("démarre l'horloge d'un joueur acquis alors qu'il est déjà blessé", () => {
    // Relevé précédent non vide : l'acquisition est bien détectée comme telle.
    const t = detecterTransitions(
      [connu("p1", "e1", "ACTIVE", "ACTIF")],
      [observe("p1", "e1", "ACTIVE", "ACTIF"), observe("p9", "e3", "IR", "IR")],
    );
    expect(t).toEqual([
      { genre: "ENTREE_POOL", fantraxId: "p9", teamId: "e3" },
      { genre: "ENTREE_IR", fantraxId: "p9", teamId: "e3", statutBrut: "IR" },
    ]);
  });

  it("ne produit aucune entrée dans le pool au tout premier relevé", () => {
    // Sans référence, l'ensemble du pool serait compté comme des acquisitions.
    const t = detecterTransitions(
      [],
      [observe("p1", "e1", "ACTIVE", "ACTIF"), observe("p2", "e1", "IR", "IR")],
    );
    expect(t.filter((x) => x.genre === "ENTREE_POOL")).toEqual([]);
    expect(t).toEqual([
      { genre: "ENTREE_IR", fantraxId: "p2", teamId: "e1", statutBrut: "IR" },
    ]);
  });

  it("distingue une acquisition d'un échange entre équipes du pool", () => {
    const t = detecterTransitions(
      [connu("p1", "e1", "ACTIVE", "ACTIF")],
      [
        observe("p1", "e2", "ACTIVE", "ACTIF"), // échangé : ne consomme pas de claim
        observe("p2", "e1", "ACTIVE", "ACTIF"), // acquis : consomme un claim
      ],
    );
    expect(t).toEqual([
      {
        genre: "CHANGEMENT_EQUIPE",
        fantraxId: "p1",
        teamId: "e2",
        ancienneEquipe: "e1",
      },
      { genre: "ENTREE_POOL", fantraxId: "p2", teamId: "e1" },
    ]);
    expect(t.filter((x) => x.genre === "ENTREE_POOL")).toHaveLength(1);
  });

  it("n'invente pas de retour de blessure lors d'un échange entre équipes du pool", () => {
    const t = detecterTransitions(
      [connu("p1", "e1", "IR", "IR")],
      [observe("p1", "e2", "IR", "IR")],
    );
    expect(t).toEqual([
      {
        genre: "CHANGEMENT_EQUIPE",
        fantraxId: "p1",
        teamId: "e2",
        ancienneEquipe: "e1",
      },
    ]);
    expect(t.some((x) => x.genre === "SORTIE_IR")).toBe(false);
  });

  it("signale un joueur disparu des alignements", () => {
    const t = detecterTransitions(
      [connu("p1", "e1", "IR", "IR"), connu("p2", "e1", "ACTIVE", "ACTIF")],
      [observe("p2", "e1", "ACTIVE", "ACTIF")],
    );
    expect(t).toEqual([
      { genre: "RETIRE_DU_POOL", fantraxId: "p1", teamId: "e1" },
    ]);
  });

  it("ne considère pas un statut inconnu comme un retour d'IR par erreur", () => {
    // Un statut jamais vu est classé INCONNU : il sort donc de l'état IR.
    // C'est volontaire et visible, mais l'administrateur peut reclasser le
    // statut pour que le séjour reparte du bon pied.
    const t = detecterTransitions(
      [connu("p1", "e1", "IR", "IR")],
      [observe("p1", "e1", "IR_LONG_TERM", "INCONNU")],
    );
    expect(t).toEqual([
      {
        genre: "SORTIE_IR",
        fantraxId: "p1",
        teamId: "e1",
        statutApres: "IR_LONG_TERM",
      },
    ]);
  });

  it("gère un relevé Fantrax vide sans planter", () => {
    const t = detecterTransitions([connu("p1", "e1", "ACTIVE", "ACTIF")], []);
    expect(t).toEqual([
      { genre: "RETIRE_DU_POOL", fantraxId: "p1", teamId: "e1" },
    ]);
  });
});

describe("resoudreTypeStatut", () => {
  const mapping = new Map<string, TypeStatut>([
    ["ACTIVE", "ACTIF"],
    ["MINORS", "FARM"],
    ["IR", "IR"],
  ]);

  it("résout les statuts connus", () => {
    expect(resoudreTypeStatut("ACTIVE", mapping)).toBe("ACTIF");
    expect(resoudreTypeStatut("MINORS", mapping)).toBe("FARM");
    expect(resoudreTypeStatut("IR", mapping)).toBe("IR");
  });

  it("normalise la casse et les espaces", () => {
    expect(resoudreTypeStatut(" minors ", mapping)).toBe("FARM");
  });

  it("classe INCONNU tout statut non répertorié, sans planter", () => {
    expect(resoudreTypeStatut("INJURED_RESERVE_LT", mapping)).toBe("INCONNU");
    expect(resoudreTypeStatut("", mapping)).toBe("INCONNU");
  });
});
