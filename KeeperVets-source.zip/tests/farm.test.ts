import { describe, expect, it } from "vitest";
import {
  SEUIL_GARDIEN,
  SEUIL_PATINEUR,
  evaluerFarm,
  messageFacebook,
  niveauPourReste,
  poidsNiveau,
  seuilPour,
} from "../src/domain/farm.js";

describe("seuilPour", () => {
  it("applique 124 parties aux gardiens", () => {
    expect(seuilPour("G")).toBe(SEUIL_GARDIEN);
    expect(seuilPour("g")).toBe(124);
    expect(seuilPour("Goalie")).toBe(124);
  });

  it("applique 164 parties aux patineurs", () => {
    expect(seuilPour("F")).toBe(SEUIL_PATINEUR);
    expect(seuilPour("D")).toBe(164);
    expect(seuilPour("C")).toBe(164);
    expect(seuilPour("RW")).toBe(164);
    expect(seuilPour("LW")).toBe(164);
  });

  it("retombe sur le seuil patineur si la position est absente", () => {
    expect(seuilPour(null)).toBe(164);
    expect(seuilPour("")).toBe(164);
  });
});

describe("niveauPourReste", () => {
  it("classe selon les paliers demandés", () => {
    expect(niveauPourReste(-1102)).toBe("DEPASSE");
    expect(niveauPourReste(-1)).toBe("DEPASSE");
    expect(niveauPourReste(0)).toBe("DEPASSE");
    expect(niveauPourReste(1)).toBe("URGENT");
    expect(niveauPourReste(5)).toBe("URGENT");
    expect(niveauPourReste(6)).toBe("CRITIQUE");
    expect(niveauPourReste(10)).toBe("CRITIQUE");
    expect(niveauPourReste(11)).toBe("SURVEILLER");
    expect(niveauPourReste(30)).toBe("SURVEILLER");
    expect(niveauPourReste(31)).toBe("OK");
  });
});

describe("evaluerFarm", () => {
  it("ne suppose jamais 0 partie quand l'information manque", () => {
    expect(evaluerFarm(null, 164)).toEqual({ reste: null, niveau: "A_VERIFIER" });
    expect(evaluerFarm(undefined, 124)).toEqual({
      reste: null,
      niveau: "A_VERIFIER",
    });
  });

  it("traite un joueur sans partie NHL comme largement admissible", () => {
    expect(evaluerFarm(0, 164)).toEqual({ reste: 164, niveau: "OK" });
  });
});

/**
 * Non-régression : valeurs réellement observées le 2026-08-31 par la preuve
 * de concept (reference/farm-status-exemple.csv). Toute dérive de la logique
 * de seuil sera détectée ici.
 */
describe("non-régression sur les données réelles du 2026-08-31", () => {
  const cas = [
    { nom: "Justin Brazeau", pos: "F", pj: 159, reste: 5, niveau: "URGENT" },
    { nom: "Joseph Woll", pos: "G", pj: 117, reste: 7, niveau: "CRITIQUE" },
    { nom: "Mavrik Bourque", pos: "F", pj: 156, reste: 8, niveau: "CRITIQUE" },
    { nom: "Joel Hofer", pos: "G", pj: 115, reste: 9, niveau: "CRITIQUE" },
    { nom: "Simon Nemec", pos: "D", pj: 155, reste: 9, niveau: "CRITIQUE" },
    { nom: "Josh Doan", pos: "F", pj: 144, reste: 20, niveau: "SURVEILLER" },
  ] as const;

  for (const c of cas) {
    it(`${c.nom} : ${c.pj} PJ -> ${c.reste} parties restantes`, () => {
      const seuil = seuilPour(c.pos);
      const resultat = evaluerFarm(c.pj, seuil);
      expect(resultat.reste).toBe(c.reste);
      expect(resultat.niveau).toBe(c.niveau);
    });
  }

  it("détecte les anomalies hors-saison en slot farm", () => {
    // John Tavares : 1266 parties, largement au-delà du seuil patineur.
    expect(evaluerFarm(1266, seuilPour("F"))).toEqual({
      reste: -1102,
      niveau: "DEPASSE",
    });
    // Ivan Barbashev : 667 parties.
    expect(evaluerFarm(667, seuilPour("F"))).toEqual({
      reste: -503,
      niveau: "DEPASSE",
    });
    // Pyotr Kochetkov : gardien à 125 parties, tout juste au-dessus de 124.
    expect(evaluerFarm(125, seuilPour("G"))).toEqual({
      reste: -1,
      niveau: "DEPASSE",
    });
  });
});

describe("poidsNiveau", () => {
  it("place les cas les plus graves en tête de tri", () => {
    const ordre = [
      "OK",
      "SURVEILLER",
      "DEPASSE",
      "A_VERIFIER",
      "URGENT",
      "CRITIQUE",
    ] as const;
    const trie = [...ordre].sort((a, b) => poidsNiveau(a) - poidsNiveau(b));
    expect(trie).toEqual([
      "DEPASSE",
      "URGENT",
      "CRITIQUE",
      "SURVEILLER",
      "A_VERIFIER",
      "OK",
    ]);
  });
});

describe("messageFacebook", () => {
  it("reprend la formulation demandée pour un avis préventif", () => {
    const message = messageFacebook({
      nom: "Mavrik Bourque",
      partiesJouees: 156,
      seuil: 164,
      reste: 8,
    });
    expect(message).toBe(
      "Salut, avis amical : Mavrik Bourque est à 156/164 parties. " +
        "Il lui reste 8 matchs avant de perdre son admissibilité farm — prévois ton coup.",
    );
  });

  it("accorde le singulier quand il ne reste qu'un match", () => {
    const message = messageFacebook({
      nom: "Test Joueur",
      partiesJouees: 163,
      seuil: 164,
      reste: 1,
    });
    expect(message).toContain("Il lui reste 1 match avant");
  });

  it("bascule sur un message d'urgence quand le seuil est franchi", () => {
    const message = messageFacebook({
      nom: "Pyotr Kochetkov",
      partiesJouees: 125,
      seuil: 124,
      reste: -1,
    });
    expect(message).toContain("125/124 parties");
    expect(message).toContain("n'est plus admissible au farm");
    expect(message).toContain("1 partie de trop");
    expect(message).toContain("retiré du farm immédiatement");
  });

  it("accorde le pluriel sur un dépassement important", () => {
    const message = messageFacebook({
      nom: "John Tavares",
      partiesJouees: 1266,
      seuil: 164,
      reste: -1102,
    });
    expect(message).toContain("1102 parties de trop");
  });

  it("demande une vérification manuelle si les parties sont inconnues", () => {
    const message = messageFacebook({
      nom: "Joueur Inconnu",
      partiesJouees: null,
      seuil: 164,
      reste: null,
    });
    expect(message).toContain("je n'arrive pas à confirmer");
    expect(message).toContain("164 parties");
  });
});
