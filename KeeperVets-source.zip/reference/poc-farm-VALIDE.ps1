$ErrorActionPreference = 'Stop'
$lid = 'dj5yxdi4mr3pi83o'
$dir = $PSScriptRoot

function Norm([string]$s) {
    if (-not $s) { return '' }
    $n = $s.Normalize([Text.NormalizationForm]::FormD)
    $sb = [Text.StringBuilder]::new()
    foreach ($c in $n.ToCharArray()) {
        if ([Globalization.CharUnicodeInfo]::GetUnicodeCategory($c) -ne 'NonSpacingMark') { [void]$sb.Append($c) }
    }
    return ($sb.ToString().ToLower() -replace "[^a-z ]", '' -replace '\s+', ' ').Trim()
}

Write-Host "1/5 Equipes NHL..."
$std = Invoke-RestMethod "https://api-web.nhle.com/v1/standings/now" -TimeoutSec 40
$tris = $std.standings | ForEach-Object { $_.teamAbbrev.default } | Sort-Object -Unique
Write-Host "   -> $($tris.Count) equipes"

Write-Host "2/5 Construction du dictionnaire nom -> playerId (alignements + espoirs)..."
$dict = @{}
function AddP($p) {
    if (-not $p.id) { return }
    $k = Norm("$($p.firstName.default) $($p.lastName.default)")
    if ($k -and -not $dict.ContainsKey($k)) { $dict[$k] = [int]$p.id }
}
foreach ($tri in $tris) {
    foreach ($url in @("https://api-web.nhle.com/v1/roster/$tri/current", "https://api-web.nhle.com/v1/prospects/$tri")) {
        try {
            $d = Invoke-RestMethod $url -TimeoutSec 30
            foreach ($grp in 'forwards', 'defensemen', 'goalies') { foreach ($p in $d.$grp) { AddP $p } }
        } catch { }
    }
}
Write-Host "   -> $($dict.Count) joueurs indexes"

Write-Host "3/5 Alignements Fantrax..."
$rosters = Invoke-RestMethod "https://www.fantrax.com/fxea/general/getTeamRosters?leagueId=$lid" -TimeoutSec 60
$pmap = Invoke-RestMethod "https://www.fantrax.com/fxea/general/getPlayerIds?sport=NHL" -TimeoutSec 120

$minors = @()
foreach ($t in $rosters.rosters.PSObject.Properties) {
    foreach ($i in $t.Value.rosterItems) {
        if ($i.status -ne 'MINORS') { continue }
        $p = $pmap.($i.id)
        $full = if ($p) { $p.name } else { "?$($i.id)" }
        if ($full -match '^(.+?),\s*(.+)$') { $full = "$($Matches[2]) $($Matches[1])" }
        $minors += [pscustomobject]@{
            Equipe = $t.Value.teamName; Nom = $full
            NHL = if ($p) { $p.team } else { '?' }; Pos = $i.position
            Seuil = if ($i.position -eq 'G') { 124 } else { 164 }
            PJ = $null; Reste = $null; Statut = $null; Source = $null
        }
    }
}
Write-Host "   -> $($minors.Count) joueurs MINORS"

Write-Host "4/5 Parties jouees carriere (API NHL)..."
$n = 0
foreach ($m in $minors) {
    $n++; Write-Progress -Activity 'NHL' -Status "$n/$($minors.Count)" -PercentComplete ($n * 100 / $minors.Count)
    $id = $dict[(Norm $m.Nom)]
    if (-not $id) {
        try {
            $exp = 'fullName likeIgnoreCase "' + ($m.Nom -replace '"', '') + '"'
            $rec = Invoke-RestMethod "https://records.nhl.com/site/api/player?cayenneExp=$([uri]::EscapeDataString($exp))" -TimeoutSec 25
            if ($rec.data.Count -ge 1) { $id = [int]$rec.data[0].id; $m.Source = 'records' }
        } catch { }
    } else { $m.Source = 'nhl-roster' }

    if ($id) {
        try {
            $l = Invoke-RestMethod "https://api-web.nhle.com/v1/player/$id/landing" -TimeoutSec 25
            $gp = $l.careerTotals.regularSeason.gamesPlayed
            $m.PJ = if ($null -eq $gp) { 0 } else { [int]$gp }
        } catch { $m.PJ = $null }
    } else { $m.PJ = 0; $m.Source = 'aucun match NHL' }

    if ($null -eq $m.PJ) { $m.Statut = 'A VERIFIER' }
    else {
        $m.Reste = $m.Seuil - $m.PJ
        $m.Statut = if ($m.Reste -le 0) { 'DEPASSE' } elseif ($m.Reste -le 10) { 'CRITIQUE' }
                    elseif ($m.Reste -le 30) { 'SURVEILLER' } else { 'OK' }
    }
    Start-Sleep -Milliseconds 80
}

$minors | Sort-Object Reste | ConvertTo-Json -Depth 4 | Set-Content "$dir\farm-status.json" -Encoding UTF8
$minors | Sort-Object Reste | Export-Csv "$dir\farm-status.csv" -NoTypeInformation -Encoding UTF8

"`n===== A RISQUE (30 parties ou moins de marge) ====="
$risk = $minors | Where-Object { $_.Statut -in 'DEPASSE', 'CRITIQUE', 'SURVEILLER' } | Sort-Object Reste
if ($risk) { $risk | Format-Table Equipe, Nom, NHL, Pos, PJ, Seuil, Reste, Statut -AutoSize | Out-String } else { "aucun" }
"===== REPARTITION ====="
$minors | Group-Object Statut | Sort-Object Count -Descending | Format-Table Name, Count -AutoSize | Out-String
"===== TOP 12 PLUS PROCHES DU SEUIL ====="
$minors | Where-Object { $null -ne $_.Reste } | Sort-Object Reste | Select-Object -First 12 |
    Format-Table Equipe, Nom, NHL, Pos, PJ, Seuil, Reste -AutoSize | Out-String
