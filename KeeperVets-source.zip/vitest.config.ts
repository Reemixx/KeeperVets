import { defineConfig } from "vitest/config";

// La logique métier (src/domain) est volontairement pure : aucun accès réseau
// ni base de données. Elle se teste donc avec Vitest en Node, sans émuler Workers.
export default defineConfig({
  test: {
    include: ["tests/**/*.test.ts"],
    environment: "node",
  },
});
