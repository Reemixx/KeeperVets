-- Appariement de repli « équipe NHL + nom de famille ».
--
-- Motif : Fantrax et la LNH n'orthographient pas toujours les noms de la même
-- façon (« Ben Kindel » contre « Benjamin Kindel », « Sandin-Pellikka » contre
-- « Sandin Pellikka »). Quand le nom complet ne suffit pas, on retombe sur le
-- couple équipe + nom de famille, à condition qu'il désigne un joueur unique.

CREATE TABLE nhl_index_famille (
  cle           TEXT PRIMARY KEY,          -- « PIT|kindel »
  nhl_player_id INTEGER NOT NULL,
  tri           TEXT NOT NULL,
  ambigu        INTEGER NOT NULL DEFAULT 0, -- 1 si plusieurs joueurs partagent la clé
  maj_le        TEXT NOT NULL
);
