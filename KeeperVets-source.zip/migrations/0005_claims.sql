-- Suivi des claims (transactions) par équipe.
--
-- Règles de la ligue :
--   * chaque équipe reçoit 4 claims au début de la saison ;
--   * les claims s'échangent entre poolers (un pooler peut en céder à un autre) ;
--   * un claim est consommé lorsqu'une équipe fait entrer un joueur dans le
--     pool depuis l'extérieur (un échange entre deux équipes n'en consomme pas).
--
-- Le suivi prend la forme d'un grand livre : chaque mouvement est conservé avec
-- son auteur, sa date et son motif. Le solde d'une équipe est la somme de ses
-- mouvements, ce qui permet de toujours expliquer un compte à un pooler qui
-- le conteste.

CREATE TABLE claims_mouvements (
  id                   INTEGER PRIMARY KEY AUTOINCREMENT,
  team_id              TEXT NOT NULL,
  saison               INTEGER NOT NULL,
  type                 TEXT NOT NULL,    -- ALLOCATION | UTILISE | RECU | CEDE | CORRECTION
  quantite             INTEGER NOT NULL, -- positif ou négatif
  date_effet           TEXT NOT NULL,    -- YYYY-MM-DD
  motif                TEXT,
  fantrax_id           TEXT,             -- joueur concerné, pour un claim utilisé
  contrepartie_team_id TEXT,             -- équipe partenaire, pour un échange
  auteur               TEXT NOT NULL,    -- « robot » ou nom d'administrateur
  execution_id         INTEGER,          -- exécution du robot à l'origine du mouvement
  cree_le              TEXT NOT NULL
);

CREATE INDEX idx_claims_equipe ON claims_mouvements (saison, team_id);
CREATE INDEX idx_claims_date ON claims_mouvements (date_effet DESC, id DESC);

-- Empêche de compter deux fois le même claim si le robot repasse sur un
-- mouvement déjà enregistré.
CREATE UNIQUE INDEX idx_claims_utilise_unique
  ON claims_mouvements (saison, team_id, fantrax_id)
  WHERE type = 'UTILISE';
