-- Schéma initial de KeeperVets
-- Base D1 (SQLite). Toutes les dates de calendrier sont au format YYYY-MM-DD
-- exprimées dans le fuseau America/Toronto. Tous les horodatages sont en ISO 8601 UTC.

-- ---------------------------------------------------------------------------
-- Équipes du pool (13)
-- ---------------------------------------------------------------------------
CREATE TABLE equipes (
  team_id TEXT PRIMARY KEY,
  nom     TEXT NOT NULL,
  rang    INTEGER,
  points  REAL,
  maj_le  TEXT NOT NULL
);

-- ---------------------------------------------------------------------------
-- Référentiel des joueurs vus dans les alignements Fantrax
-- ---------------------------------------------------------------------------
CREATE TABLE joueurs (
  fantrax_id         TEXT PRIMARY KEY,
  nom                TEXT NOT NULL,          -- « Prénom Nom » (déjà inversé)
  nom_normalise      TEXT NOT NULL,          -- sans accents, minuscules, [a-z ]
  equipe_nhl         TEXT,
  position           TEXT,
  nhl_player_id      INTEGER,                -- NULL tant que non apparié
  source_appariement TEXT,                   -- nhl-index | records | aucun
  apparie_le         TEXT,
  maj_le             TEXT NOT NULL
);
CREATE INDEX idx_joueurs_norm ON joueurs (nom_normalise);
CREATE INDEX idx_joueurs_nhlid ON joueurs (nhl_player_id);

-- ---------------------------------------------------------------------------
-- Dictionnaire persistant « nom normalisé -> identifiant NHL »
-- Construit à partir des 32 alignements + 32 listes d'espoirs (~1690 joueurs).
-- ---------------------------------------------------------------------------
CREATE TABLE nhl_index (
  nom_normalise TEXT PRIMARY KEY,
  nhl_player_id INTEGER NOT NULL,
  tri           TEXT,                        -- code d'équipe NHL (ex. MTL)
  genre         TEXT,                        -- roster | prospects
  maj_le        TEXT NOT NULL
);

-- ---------------------------------------------------------------------------
-- Rotation des sources NHL à rafraîchir (32 alignements + 32 listes d'espoirs).
-- Le robot n'en traite qu'un lot par exécution pour respecter la limite de
-- sous-requêtes de Cloudflare Workers.
-- ---------------------------------------------------------------------------
CREATE TABLE nhl_sources (
  cle             TEXT PRIMARY KEY,          -- « MTL:roster »
  tri             TEXT NOT NULL,
  genre           TEXT NOT NULL,             -- roster | prospects
  dernier_succes  TEXT,
  dernier_essai   TEXT,
  derniere_erreur TEXT,
  nb_joueurs      INTEGER NOT NULL DEFAULT 0
);

-- ---------------------------------------------------------------------------
-- Cache des parties jouées en carrière (évite de refrapper l'API NHL)
-- ---------------------------------------------------------------------------
CREATE TABLE cache_pj (
  nhl_player_id  INTEGER PRIMARY KEY,
  parties_jouees INTEGER NOT NULL,
  recupere_le    TEXT NOT NULL
);

-- ---------------------------------------------------------------------------
-- Dernier état connu des alignements (base de la détection de transitions).
-- Clé = fantrax_id seul : un joueur échangé entre deux équipes du pool ne doit
-- pas être interprété comme un retour de blessure.
-- ---------------------------------------------------------------------------
CREATE TABLE roster_courant (
  fantrax_id  TEXT PRIMARY KEY,
  team_id     TEXT NOT NULL,
  position    TEXT,
  statut_brut TEXT NOT NULL,                 -- valeur telle que reçue de Fantrax
  statut_type TEXT NOT NULL,                 -- ACTIF | FARM | IR | INCONNU
  observe_le  TEXT NOT NULL
);
CREATE INDEX idx_roster_type ON roster_courant (statut_type);

-- ---------------------------------------------------------------------------
-- Mapping configurable « statut brut Fantrax -> sens métier ».
-- La valeur exacte du statut de blessé en saison est inconnue : tout statut
-- non répertorié est ajouté automatiquement en INCONNU, journalisé, et un
-- administrateur peut ensuite le reclasser depuis l'interface.
-- ---------------------------------------------------------------------------
CREATE TABLE mapping_statuts (
  statut_brut     TEXT PRIMARY KEY,
  type            TEXT NOT NULL,             -- ACTIF | FARM | IR | INCONNU
  libelle         TEXT,
  auto_decouvert  INTEGER NOT NULL DEFAULT 0,
  nb_observations INTEGER NOT NULL DEFAULT 0,
  premiere_vue    TEXT,
  derniere_vue    TEXT,
  maj_par         TEXT,
  maj_le          TEXT
);

-- Amorce : les deux seuls statuts observés hors-saison.
INSERT INTO mapping_statuts (statut_brut, type, libelle, auto_decouvert) VALUES
  ('ACTIVE', 'ACTIF', 'Alignement actif', 0),
  ('MINORS', 'FARM',  'Slot farm (mineures)', 0);

-- ---------------------------------------------------------------------------
-- Séjours sur la liste des blessés (courants et historiques)
-- ---------------------------------------------------------------------------
CREATE TABLE sejours_ir (
  id                 INTEGER PRIMARY KEY AUTOINCREMENT,
  fantrax_id         TEXT NOT NULL,
  team_id            TEXT NOT NULL,
  date_ir            TEXT NOT NULL,          -- date retenue (corrigeable par un admin)
  date_ir_detectee   TEXT NOT NULL,          -- date détectée à l'origine par le robot
  detecte_le         TEXT NOT NULL,
  date_eligibilite   TEXT NOT NULL,          -- date_ir + 10 jours
  statut_brut_ir     TEXT,
  date_retour        TEXT,
  retour_detecte_le  TEXT,
  statut_apres       TEXT,                   -- statut brut observé au retour
  retour_premature   INTEGER NOT NULL DEFAULT 0,
  jours_manquants    INTEGER,                -- nombre de jours écourtés si retour prématuré
  motif_fermeture    TEXT,                   -- retour | retire-du-pool | manuel
  ouvert             INTEGER NOT NULL DEFAULT 1,
  corrige_par        TEXT,
  corrige_le         TEXT,
  note               TEXT,
  cree_le            TEXT NOT NULL
);
CREATE INDEX idx_sejours_ouvert ON sejours_ir (ouvert, fantrax_id);
CREATE INDEX idx_sejours_joueur ON sejours_ir (fantrax_id, date_ir DESC);

-- ---------------------------------------------------------------------------
-- Journal des exécutions du robot
-- ---------------------------------------------------------------------------
CREATE TABLE executions (
  id                 INTEGER PRIMARY KEY AUTOINCREMENT,
  demarre_le         TEXT NOT NULL,
  termine_le         TEXT,
  declencheur        TEXT NOT NULL,          -- cron | manuel
  complet            INTEGER NOT NULL DEFAULT 0,
  succes             INTEGER NOT NULL DEFAULT 0,
  fantrax_ok         INTEGER NOT NULL DEFAULT 0,
  nhl_ok             INTEGER NOT NULL DEFAULT 0,
  joueurs_vus        INTEGER NOT NULL DEFAULT 0,
  sources_nhl_lues   INTEGER NOT NULL DEFAULT 0,
  pj_rafraichies     INTEGER NOT NULL DEFAULT 0,
  ir_ouverts         INTEGER NOT NULL DEFAULT 0,
  ir_fermes          INTEGER NOT NULL DEFAULT 0,
  retours_prematures INTEGER NOT NULL DEFAULT 0,
  statuts_inconnus   INTEGER NOT NULL DEFAULT 0,
  erreur             TEXT,
  details            TEXT                    -- JSON libre
);

-- ---------------------------------------------------------------------------
-- Journal d'audit des actions administratives
-- ---------------------------------------------------------------------------
CREATE TABLE journal_admin (
  id       INTEGER PRIMARY KEY AUTOINCREMENT,
  le       TEXT NOT NULL,
  admin    TEXT NOT NULL,
  action   TEXT NOT NULL,
  cible    TEXT,
  cible_id TEXT,
  details  TEXT                              -- JSON libre
);
CREATE INDEX idx_journal_le ON journal_admin (le DESC);

-- ---------------------------------------------------------------------------
-- État applicatif (clé/valeur) : dernier rafraîchissement réussi, période, etc.
-- ---------------------------------------------------------------------------
CREATE TABLE etat_app (
  cle    TEXT PRIMARY KEY,
  valeur TEXT,
  maj_le TEXT NOT NULL
);
