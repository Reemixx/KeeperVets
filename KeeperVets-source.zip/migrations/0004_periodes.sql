-- Périodes de roster Fantrax.
--
-- Règle métier : la date de mise sur la liste des blessés n'est PAS la date
-- calendaire à laquelle le robot a détecté le mouvement, mais la date de début
-- de la période Fantrax durant laquelle le mouvement a été effectué.
--
-- Exemple confirmé le 2026-09-01 : Connor Bedard placé sur IR pendant la
-- période 1 (débutant le 2026-09-29) est réputé mis sur IR le 29 septembre,
-- et donc éligible le 9 octobre.
--
-- Les 194 périodes de la saison proviennent de getLeagueInfo (rosterPeriods).

CREATE TABLE periodes (
  numero     INTEGER PRIMARY KEY,
  debut      TEXT NOT NULL,    -- ISO 8601 avec décalage, tel que reçu de Fantrax
  fin        TEXT NOT NULL,
  date_debut TEXT NOT NULL,    -- date civile du début, format YYYY-MM-DD
  debut_ms   INTEGER NOT NULL, -- horodatages pour comparaison directe
  fin_ms     INTEGER NOT NULL,
  maj_le     TEXT NOT NULL
);

CREATE INDEX idx_periodes_bornes ON periodes (debut_ms, fin_ms);

-- Trace la période retenue au moment d'ouvrir un séjour, pour pouvoir
-- expliquer d'où vient la date affichée.
ALTER TABLE sejours_ir ADD COLUMN periode_ir INTEGER;
