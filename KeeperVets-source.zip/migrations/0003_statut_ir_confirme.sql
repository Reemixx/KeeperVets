-- Statut de blessé confirmé en conditions réelles.
--
-- La valeur exacte du statut de la liste des blessés n'était pas connue lors de
-- la conception : elle n'avait donc pas été devinée. Elle a été observée le
-- 2026-09-01, lorsqu'un administrateur a placé Connor Bedard sur la liste des
-- blessés dans Fantrax. La valeur renvoyée par getTeamRosters est
-- « INJURED_RESERVE ».
--
-- L'amorcer ici évite qu'une base neuve rate le tout premier séjour IR de la
-- saison, faute d'un statut classé à temps.
--
-- Le classement manuel d'un administrateur reste prioritaire : la mise à jour
-- ne s'applique que si le statut avait été découvert automatiquement.

INSERT INTO mapping_statuts (statut_brut, type, libelle, auto_decouvert)
VALUES ('INJURED_RESERVE', 'IR', 'Liste des blessés', 0)
ON CONFLICT(statut_brut) DO UPDATE SET
  type = CASE WHEN mapping_statuts.auto_decouvert = 1 THEN 'IR' ELSE mapping_statuts.type END,
  libelle = COALESCE(mapping_statuts.libelle, 'Liste des blessés'),
  auto_decouvert = 0;
