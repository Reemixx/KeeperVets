@echo off
REM ===========================================================================
REM  Le Keeper des Vets - demarrage en un clic
REM
REM  Double-clique sur ce fichier : il prepare tout ce qu'il faut, demarre le
REM  serveur local et ouvre le navigateur.
REM
REM  Pour arreter : Ctrl+C dans la fenetre, ou ferme-la simplement.
REM ===========================================================================

title Le Keeper des Vets
cd /d "%~dp0"

powershell -NoProfile -ExecutionPolicy Bypass -File "scripts\demarrer.ps1"

echo.
pause
