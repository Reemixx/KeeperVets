/**
 * Règle des 7 jours de la liste des blessés (livre des règlements V3, règle 6.3.3).
 *
 * Un joueur mis sur IR doit y demeurer 7 jours de calendrier complets à partir
 * de la date de mise sur IR, même s'il est rétabli avant.
 * Exemple de référence : mis sur IR le 5 novembre -> éligible le 12 novembre.
 *
 * Historique : la règle était de 10 jours jusqu'à la V3 du livre des
 * règlements (29 septembre 2026). Seule la constante JOURS_IR change ; la
 * migration 0006 recalcule les échéances déjà enregistrées.
 *
 * Convention retenue pour l'affichage « jour X/7 » :
 * X = nombre de jours écoulés depuis la mise sur IR.
 * Le 5 novembre est le jour 0/7, le 9 novembre le jour 4/7,
 * le 12 novembre le jour 7/7, qui est aussi le premier jour d'éligibilité.
 *
 * Ce module est volontairement pur : dates manipulées sous forme de chaînes
 * « YYYY-MM-DD » et calculs faits en UTC pour éviter toute dérive de fuseau.
 */

import type { StatutIR } from "./types.js";

/** Nombre de jours de calendrier complets à purger sur la liste des blessés. */
export const JOURS_IR = 7;

const FORMAT_DATE = /^\d{4}-\d{2}-\d{2}$/;

/**
 * Retourne la date du jour dans le fuseau demandé, au format « YYYY-MM-DD ».
 * Le fuseau importe : une journée de calendrier du pool est une journée civile
 * au Québec, pas une journée UTC.
 */
export function dateDuJour(
  fuseau = "America/Toronto",
  maintenant: Date = new Date(),
): string {
  // Le format « en-CA » produit directement YYYY-MM-DD.
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: fuseau,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(maintenant);
}

/** Convertit « YYYY-MM-DD » en nombre de jours depuis l'époque Unix. */
function versJours(date: string): number {
  if (!FORMAT_DATE.test(date)) {
    throw new Error(`Date invalide, format attendu YYYY-MM-DD : « ${date} »`);
  }
  const [a, m, j] = date.split("-").map(Number) as [number, number, number];
  return Math.floor(Date.UTC(a, m - 1, j) / 86_400_000);
}

/** Convertit un nombre de jours depuis l'époque Unix en « YYYY-MM-DD ». */
function versDate(jours: number): string {
  return new Date(jours * 86_400_000).toISOString().slice(0, 10);
}

/** Ajoute (ou retire, si négatif) un nombre de jours de calendrier à une date. */
export function ajouterJours(date: string, jours: number): string {
  return versDate(versJours(date) + jours);
}

/** Nombre de jours de calendrier entre deux dates (fin - debut). */
export function ecartJours(debut: string, fin: string): number {
  return versJours(fin) - versJours(debut);
}

/**
 * Première date à laquelle le joueur peut être retiré de la liste des blessés.
 * C'est la date de mise sur IR + JOURS_IR jours.
 */
export function calculerEligibilite(dateIr: string): string {
  return ajouterJours(dateIr, JOURS_IR);
}

/**
 * Numéro de journée du séjour, borné entre 0 et JOURS_IR pour l'affichage « X/7 ».
 * La valeur réelle peut dépasser JOURS_IR si le joueur reste sur IR plus longtemps ;
 * on la plafonne pour que l'indicateur reste lisible.
 */
export function jourDuSejour(dateIr: string, aujourdhui: string): number {
  const ecoules = ecartJours(dateIr, aujourdhui);
  if (ecoules < 0) return 0;
  return Math.min(ecoules, JOURS_IR);
}

/**
 * Évalue l'état d'un séjour IR encore ouvert.
 * 🔴 BLOQUE · 🟡 ELIGIBLE_DEMAIN · 🟢 ELIGIBLE
 */
export function statutSejourOuvert(
  dateIr: string,
  aujourdhui: string,
): Exclude<StatutIR, "RETOUR_PREMATURE"> {
  const restants = ecartJours(aujourdhui, calculerEligibilite(dateIr));
  if (restants <= 0) return "ELIGIBLE";
  if (restants === 1) return "ELIGIBLE_DEMAIN";
  return "BLOQUE";
}

/** Nombre de jours restants avant l'éligibilité (0 si déjà éligible). */
export function joursRestants(dateIr: string, aujourdhui: string): number {
  return Math.max(0, ecartJours(aujourdhui, calculerEligibilite(dateIr)));
}

/**
 * Analyse un retour d'IR : le joueur a-t-il été réactivé avant d'avoir purgé
 * ses jours obligatoires ? Le cas échéant, c'est une infraction à signaler.
 */
export function evaluerRetour(
  dateIr: string,
  dateRetour: string,
): { premature: boolean; joursManquants: number } {
  const manquants = ecartJours(dateRetour, calculerEligibilite(dateIr));
  return {
    premature: manquants > 0,
    joursManquants: Math.max(0, manquants),
  };
}

/**
 * Statut d'affichage d'un séjour, ouvert ou fermé.
 * Un séjour fermé prématurément conserve son marqueur d'infraction.
 */
export function statutAffichage(sejour: {
  dateIr: string;
  ouvert: boolean;
  dateRetour: string | null;
  retourPremature: boolean;
}, aujourdhui: string): StatutIR {
  if (sejour.retourPremature) return "RETOUR_PREMATURE";
  if (!sejour.ouvert) return "ELIGIBLE"; // séjour purgé puis clos normalement
  return statutSejourOuvert(sejour.dateIr, aujourdhui);
}

/** Libellé français court, avec pastille, pour l'interface. */
export function libelleStatutIr(statut: StatutIR): string {
  switch (statut) {
    case "BLOQUE":
      return "🔴 Bloqué";
    case "ELIGIBLE_DEMAIN":
      return "🟡 Éligible demain";
    case "ELIGIBLE":
      return "🟢 Éligible maintenant";
    case "RETOUR_PREMATURE":
      return "⚠️ Retour prématuré";
  }
}
