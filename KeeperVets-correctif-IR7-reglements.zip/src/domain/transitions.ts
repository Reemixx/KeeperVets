/**
 * Détection des transitions entre deux relevés d'alignements.
 *
 * Le robot compare le dernier état connu en base avec l'état fraîchement lu
 * chez Fantrax et en déduit les mouvements à enregistrer.
 *
 * Point important : la comparaison se fait par identifiant de joueur et non par
 * couple (équipe, joueur). Un joueur échangé entre deux équipes du pool alors
 * qu'il est blessé ne doit pas être interprété comme un retour de blessure.
 */

import type { TypeStatut } from "./types.js";

/** État d'un joueur au relevé précédent. */
export interface EtatConnu {
  fantraxId: string;
  teamId: string;
  statutType: TypeStatut;
  statutBrut: string;
}

/** État d'un joueur au relevé courant. */
export interface EtatObserve {
  fantraxId: string;
  teamId: string;
  position: string;
  statutBrut: string;
  statutType: TypeStatut;
}

/** Mouvement déduit de la comparaison de deux relevés. */
export type Transition =
  | {
      genre: "ENTREE_IR";
      fantraxId: string;
      teamId: string;
      statutBrut: string;
    }
  | {
      genre: "SORTIE_IR";
      fantraxId: string;
      teamId: string;
      statutApres: string;
    }
  | {
      genre: "RETIRE_DU_POOL";
      fantraxId: string;
      teamId: string;
    }
  | {
      genre: "ENTREE_POOL";
      fantraxId: string;
      teamId: string;
    }
  | {
      genre: "CHANGEMENT_EQUIPE";
      fantraxId: string;
      teamId: string;
      ancienneEquipe: string;
    };

/**
 * Compare deux relevés et retourne la liste des transitions.
 *
 * Un joueur inconnu au relevé précédent qui apparaît directement en IR
 * (nouvelle acquisition déjà blessée, ou tout premier passage du robot)
 * déclenche bien une ENTREE_IR : c'est le comportement voulu, sans quoi son
 * horloge de la liste des blessés ne démarrerait jamais.
 *
 * ENTREE_POOL distingue une véritable acquisition (le joueur n'était dans
 * aucune équipe du pool) d'un simple échange entre deux poolers, qui produit
 * un CHANGEMENT_EQUIPE. C'est cette distinction qui permet de décompter les
 * claims sans se tromper.
 *
 * Aucune ENTREE_POOL n'est produite lorsque le relevé précédent est vide :
 * au tout premier passage du robot, l'ensemble du pool serait autrement
 * interprété comme des acquisitions.
 */
export function detecterTransitions(
  precedents: readonly EtatConnu[],
  observes: readonly EtatObserve[],
): Transition[] {
  const avant = new Map(precedents.map((e) => [e.fantraxId, e]));
  const transitions: Transition[] = [];
  const premierReleve = precedents.length === 0;

  for (const maintenant of observes) {
    const ancien = avant.get(maintenant.fantraxId);

    if (!ancien && !premierReleve) {
      transitions.push({
        genre: "ENTREE_POOL",
        fantraxId: maintenant.fantraxId,
        teamId: maintenant.teamId,
      });
    }

    if (ancien && ancien.teamId !== maintenant.teamId) {
      transitions.push({
        genre: "CHANGEMENT_EQUIPE",
        fantraxId: maintenant.fantraxId,
        teamId: maintenant.teamId,
        ancienneEquipe: ancien.teamId,
      });
    }

    const etaitIr = ancien?.statutType === "IR";
    const estIr = maintenant.statutType === "IR";

    if (estIr && !etaitIr) {
      transitions.push({
        genre: "ENTREE_IR",
        fantraxId: maintenant.fantraxId,
        teamId: maintenant.teamId,
        statutBrut: maintenant.statutBrut,
      });
    } else if (!estIr && etaitIr) {
      transitions.push({
        genre: "SORTIE_IR",
        fantraxId: maintenant.fantraxId,
        teamId: maintenant.teamId,
        statutApres: maintenant.statutBrut,
      });
    }
  }

  // Joueurs disparus des alignements : libérés, ou échangés hors du pool.
  const vus = new Set(observes.map((e) => e.fantraxId));
  for (const ancien of precedents) {
    if (!vus.has(ancien.fantraxId)) {
      transitions.push({
        genre: "RETIRE_DU_POOL",
        fantraxId: ancien.fantraxId,
        teamId: ancien.teamId,
      });
    }
  }

  return transitions;
}

/**
 * Résout le sens métier d'un statut brut à partir du mapping configurable.
 * Un statut absent du mapping est classé INCONNU : l'application continue de
 * fonctionner et l'administrateur pourra le reclasser depuis l'interface.
 */
export function resoudreTypeStatut(
  statutBrut: string,
  mapping: ReadonlyMap<string, TypeStatut>,
): TypeStatut {
  return mapping.get(statutBrut.trim().toUpperCase()) ?? "INCONNU";
}
