/**
 * Construction des vues d'affichage à partir des données brutes de la base.
 * La logique de calcul provient de src/domain : ce module ne fait qu'assembler.
 */

import { CLES_ETAT, type Env } from "../config.js";
import type { Repo } from "../db/repo.js";
import {
  libelleNiveauClaims,
  messageClaims,
  niveauPourSolde,
  resumerParEquipe,
  type NiveauClaims,
} from "../domain/claims.js";
import {
  estAlerte,
  evaluerFarm,
  libelleNiveau,
  messageFacebook,
  poidsNiveau,
  seuilPour,
} from "../domain/farm.js";
import {
  JOURS_IR,
  ajouterJours,
  calculerEligibilite,
  dateDuJour,
  jourDuSejour,
  joursRestants,
  libelleStatutIr,
  statutAffichage,
} from "../domain/ir.js";
import type { LigneBlesse, LigneFarm, NiveauFarm } from "../domain/types.js";
import { periodePourInstant } from "../domain/periodes.js";

export interface VueBlesse extends LigneBlesse {
  libelleStatut: string;
  joursRestants: number;
  dateIrModifiee: boolean;
  /** Période Fantrax ayant servi à établir la date de mise sur IR. */
  periodeIr: number | null;
}

export interface VueFarm extends LigneFarm {
  libelleNiveau: string;
  message: string;
  estAlerte: boolean;
}

/**
 * Nombre de jours pendant lesquels une infraction reste affichée au tableau
 * de bord après le retour du joueur.
 */
export const RETENTION_INFRACTIONS_JOURS = 30;

/** Construit la liste des séjours sur la liste des blessés. */
export async function construireBlesses(
  repo: Repo,
  env: Env,
  options: { historique?: boolean } = {},
): Promise<VueBlesse[]> {
  const aujourdhui = dateDuJour(env.FUSEAU ?? "America/Toronto");
  const lignes = options.historique
    ? await repo.vueSejours("tous")
    : await repo.vueSejours("courant", {
        depuis: ajouterJours(aujourdhui, -RETENTION_INFRACTIONS_JOURS),
      });

  return lignes
    .map((s) => {
      const statut = statutAffichage(
        {
          dateIr: s.date_ir,
          ouvert: s.ouvert === 1,
          dateRetour: s.date_retour,
          retourPremature: s.retour_premature === 1,
        },
        aujourdhui,
      );
      const referenceJour = s.ouvert === 1 ? aujourdhui : (s.date_retour ?? aujourdhui);

      return {
        id: s.id,
        fantraxId: s.fantrax_id,
        nom: s.nom ?? `Joueur ${s.fantrax_id}`,
        equipePool: s.equipe ?? s.team_id,
        position: s.position,
        dateIr: s.date_ir,
        dateIrDetectee: s.date_ir_detectee,
        // Recalculée à partir de la date IR : la règle en vigueur fait foi,
        // même si l'échéance enregistrée date d'une ancienne règle.
        dateEligibilite: calculerEligibilite(s.date_ir),
        jourCourant: jourDuSejour(s.date_ir, referenceJour),
        statut,
        libelleStatut: libelleStatutIr(statut),
        joursRestants: joursRestants(s.date_ir, aujourdhui),
        ouvert: s.ouvert === 1,
        dateRetour: s.date_retour,
        retourPremature: s.retour_premature === 1,
        joursManquants: s.jours_manquants,
        corrigePar: s.corrige_par,
        corrigeLe: s.corrige_le,
        note: s.note,
        dateIrModifiee: s.date_ir !== s.date_ir_detectee,
        periodeIr: s.periode_ir,
      } satisfies VueBlesse;
    })
    .sort((a, b) => {
      // Les infractions en premier, puis les échéances les plus proches.
      if (a.retourPremature !== b.retourPremature) return a.retourPremature ? -1 : 1;
      if (a.ouvert !== b.ouvert) return a.ouvert ? -1 : 1;
      return a.dateEligibilite.localeCompare(b.dateEligibilite);
    });
}

/** Construit la liste des joueurs en slot farm avec leur évaluation. */
export async function construireFarm(repo: Repo): Promise<VueFarm[]> {
  const lignes = await repo.vueFarm();

  return lignes
    .map((f) => {
      const seuil = seuilPour(f.position);
      const { reste, niveau } = evaluerFarm(f.parties_jouees, seuil);
      const nom = f.nom ?? `Joueur ${f.fantrax_id}`;

      return {
        fantraxId: f.fantrax_id,
        nom,
        equipePool: f.equipe ?? f.team_id,
        equipeNhl: f.equipe_nhl,
        position: f.position ?? "",
        seuil,
        partiesJouees: f.parties_jouees,
        reste,
        niveau: niveau as NiveauFarm,
        nhlPlayerId: f.nhl_player_id,
        sourceAppariement: f.source_appariement,
        pjRecupereeLe: f.recupere_le,
        libelleNiveau: libelleNiveau(niveau),
        estAlerte: estAlerte(niveau),
        message: messageFacebook({
          nom,
          partiesJouees: f.parties_jouees,
          seuil,
          reste,
        }),
      } satisfies VueFarm;
    })
    .sort((a, b) => {
      const ecart = poidsNiveau(a.niveau) - poidsNiveau(b.niveau);
      if (ecart !== 0) return ecart;
      if (a.reste !== null && b.reste !== null) return a.reste - b.reste;
      return a.nom.localeCompare(b.nom, "fr");
    });
}

/** Métadonnées de fraîcheur affichées en permanence dans l'interface. */
export async function construireMeta(repo: Repo, env: Env) {
  const etats = await repo.lireTousEtats();
  const executions = await repo.dernieresExecutions(1);
  const derniere = executions[0] as Record<string, unknown> | undefined;
  const mapping = await repo.listerMapping();
  const periodes = await repo.lirePeriodes();
  const periodeCourante = periodePourInstant(periodes, Date.now());

  return {
    aujourdhui: dateDuJour(env.FUSEAU ?? "America/Toronto"),
    /** Nombre de jours à purger sur la liste des blessés (règle en vigueur). */
    joursIr: JOURS_IR,
    fuseau: env.FUSEAU ?? "America/Toronto",
    dernierSuccesFantrax: etats[CLES_ETAT.dernierSuccesFantrax] ?? null,
    dernierSuccesNhl: etats[CLES_ETAT.dernierSuccesNhl] ?? null,
    derniereExecution: etats[CLES_ETAT.derniereExecution] ?? null,
    periodeFantrax: etats[CLES_ETAT.periodeFantrax] ?? null,
    debutSaison: etats[CLES_ETAT.debutSaison] ?? null,
    finSaison: etats[CLES_ETAT.finSaison] ?? null,
    nbPeriodes: periodes.length,
    periodeCourante: periodeCourante
      ? {
          numero: periodeCourante.numero,
          dateDebut: periodeCourante.dateDebut,
          debut: periodeCourante.debut,
          fin: periodeCourante.fin,
          /** Vrai tant que la saison n'a pas commencé. */
          aVenir: periodeCourante.debutMs > Date.now(),
        }
      : null,
    joueursIndexesNhl: await repo.compterIndexNhl(),
    statutsNonClasses: mapping
      .filter((m) => m.type === "INCONNU")
      .map((m) => ({
        statut: m.statut_brut,
        observations: m.nb_observations,
        premiereVue: m.premiere_vue,
      })),
    derniereExecutionDetail: derniere
      ? {
          id: derniere["id"],
          succes: derniere["succes"] === 1,
          fantraxOk: derniere["fantrax_ok"] === 1,
          nhlOk: derniere["nhl_ok"] === 1,
          erreur: derniere["erreur"],
          termineLe: derniere["termine_le"],
          declencheur: derniere["declencheur"],
        }
      : null,
  };
}

/** Recalcule la date d'éligibilité, utilisé lors d'une correction manuelle. */
export function recalculerEligibilite(dateIr: string): string {
  return calculerEligibilite(dateIr);
}

export interface VueClaims {
  teamId: string;
  equipe: string;
  solde: number;
  alloues: number;
  utilises: number;
  recus: number;
  cedes: number;
  corrections: number;
  niveau: NiveauClaims;
  libelleNiveau: string;
  message: string;
}

/**
 * Construit l'état des claims par équipe pour la saison en cours.
 * Les équipes sans aucun mouvement apparaissent tout de même, à zéro : elles
 * seraient autrement invisibles avant la dotation de début de saison.
 */
export async function construireClaims(
  repo: Repo,
): Promise<{
  saison: number | null;
  debutSaison: string | null;
  saisonOuverte: boolean;
  nbEquipes: number;
  equipes: VueClaims[];
  mouvements: unknown[];
}> {
  const periodes = await repo.lirePeriodes();
  const equipes = await repo.listerEquipes();

  if (periodes.length === 0) {
    return {
      saison: null,
      debutSaison: null,
      saisonOuverte: false,
      nbEquipes: equipes.length,
      equipes: [],
      mouvements: [],
    };
  }

  const premiere = periodes.reduce((a, b) => (a.numero <= b.numero ? a : b));
  const saison = Number(premiere.dateDebut.slice(0, 4));
  const saisonOuverte = dateDuJour() >= premiere.dateDebut;
  const mouvements = await repo.lireMouvementsClaims(saison);
  const resume = resumerParEquipe(
    mouvements.map((m) => ({
      teamId: m.team_id,
      type: m.type,
      quantite: m.quantite,
    })),
  );

  const nomParEquipe = new Map(equipes.map((e) => [e.team_id, e.nom]));

  const lignes: VueClaims[] = equipes.map((e) => {
    const r = resume.get(e.team_id) ?? {
      teamId: e.team_id,
      solde: 0,
      alloues: 0,
      utilises: 0,
      recus: 0,
      cedes: 0,
      corrections: 0,
    };
    // Une équipe est « dotée » dès qu'elle a reçu son allocation, ou qu'un
    // administrateur a saisi un mouvement pour elle.
    const dote = r.alloues > 0 || r.recus > 0 || r.cedes > 0 || r.corrections !== 0;
    const niveau = niveauPourSolde(r.solde, dote);
    return {
      teamId: e.team_id,
      equipe: e.nom,
      solde: r.solde,
      alloues: r.alloues,
      utilises: r.utilises,
      recus: r.recus,
      cedes: r.cedes,
      corrections: r.corrections,
      niveau,
      libelleNiveau: libelleNiveauClaims(niveau),
      message: messageClaims(e.nom, r.solde, dote),
    };
  });

  lignes.sort((a, b) => a.solde - b.solde || a.equipe.localeCompare(b.equipe, "fr"));

  return {
    saison,
    debutSaison: premiere.dateDebut,
    saisonOuverte,
    nbEquipes: equipes.length,
    // Avant l'ouverture, rien n'est exposé : le repêchage n'a pas encore eu
    // lieu et afficher des soldes à zéro serait trompeur.
    equipes: saisonOuverte ? lignes : [],
    mouvements: saisonOuverte
      ? mouvements.map((m) => ({
          ...m,
          equipe: nomParEquipe.get(m.team_id) ?? m.team_id,
          contrepartie: m.contrepartie_team_id
            ? (nomParEquipe.get(m.contrepartie_team_id) ?? m.contrepartie_team_id)
            : null,
        }))
      : [],
  };
}
