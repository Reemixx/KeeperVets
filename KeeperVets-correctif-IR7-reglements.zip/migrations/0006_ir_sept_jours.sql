-- Règle de la liste des blessés : 10 jours -> 7 jours.
--
-- La V3 du livre des règlements (29 septembre 2026, règle 6.3.3) ramène la
-- période minimale sur la liste des blessés de 10 à 7 jours, inclusivement.
-- Le code applique la nouvelle valeur (constante JOURS_IR) ; cette migration
-- réaligne les séjours déjà enregistrés avec l'ancienne règle.
--
-- Hypothèse assumée : l'application n'a aucun séjour antérieur à la V3 qui
-- devrait rester jugé selon l'ancienne règle (elle a été mise en service à
-- l'automne 2026, avant le début de la saison régulière). Tous les séjours
-- sont donc recalculés.

-- 1. Échéance d'éligibilité : date de mise sur IR + 7 jours.
UPDATE sejours_ir
SET date_eligibilite = date(date_ir, '+7 days');

-- 2. Verdict des séjours clos par un retour : un retour qui était prématuré
--    avec 10 jours peut ne plus l'être avec 7. Les séjours clos parce que le
--    joueur a quitté le pool ne sont jamais jugés : on n'y touche pas.
UPDATE sejours_ir
SET jours_manquants  = MAX(0, CAST(julianday(date_eligibilite) - julianday(date_retour) AS INTEGER)),
    retour_premature = CASE WHEN date_retour < date_eligibilite THEN 1 ELSE 0 END
WHERE ouvert = 0
  AND date_retour IS NOT NULL
  AND motif_fermeture = 'retour';
