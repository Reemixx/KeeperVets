-- Datation IR : marque « à vérifier ».
--
-- Fantrax renvoie l'alignement de la PROCHAINE période verrouillée : un
-- mouvement IR vise donc cette période. Quand la période de l'alignement a
-- avancé entre deux passages du robot, le mouvement a pu viser la période
-- précédente ou la suivante. Le robot retient la plus tardive (décision de la
-- ligue) et conserve ici la date la plus hâtive possible, pour qu'un admin
-- vérifie. NULL = datation sans ambiguïté, ou déjà vérifiée par un admin.
ALTER TABLE sejours_ir ADD COLUMN date_ir_min TEXT;
