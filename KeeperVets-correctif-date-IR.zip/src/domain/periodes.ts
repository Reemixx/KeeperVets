/**
 * Périodes de roster Fantrax.
 *
 * Une période est la fenêtre pendant laquelle un alignement est figé. Fantrax
 * en compte 194 pour la saison 2026-2027, du 29 septembre au 10 avril.
 *
 * Règle métier centrale : la date de mise sur la liste des blessés est la
 * **date de début de la période visée par le mouvement**, et non la date
 * calendaire à laquelle le robot l'a constaté.
 *
 * ⚠️ Une période commence au premier match de la soirée et l'alignement se
 * verrouille à ce moment. Dès lors, getTeamRosters renvoie l'alignement de la
 * période **suivante** (constaté le 30 septembre 2026 à 19 h 15 : période 1 en
 * cours, `period = 2` renvoyé). Un mouvement fait le 29 au soir, après les
 * matchs, vise donc la période 2, qui commence le 30.
 *
 * Module pur : aucune dépendance réseau ni base de données.
 */

/** Une période de roster, telle que conservée par l'application. */
export interface Periode {
  numero: number;
  /** Début, en ISO 8601 avec décalage horaire. */
  debut: string;
  /** Fin, en ISO 8601 avec décalage horaire. */
  fin: string;
  /** Date civile du début, au format YYYY-MM-DD. */
  dateDebut: string;
  debutMs: number;
  finMs: number;
}

/**
 * Extrait la date civile d'un horodatage Fantrax.
 *
 * Fantrax renvoie ses dates avec un décalage explicite
 * (« 2026-09-29T17:00:00-04:00 ») : les dix premiers caractères sont déjà la
 * date locale recherchée. Un horodatage en UTC (« ...Z ») est en revanche
 * converti vers le fuseau de la ligue, sans quoi une soirée de match
 * basculerait au lendemain.
 */
export function dateCivile(horodatage: string, fuseau = "America/Toronto"): string {
  const brut = horodatage.trim();

  // Décalage explicite non nul : la partie date est déjà locale.
  if (/[+-]\d{2}:?\d{2}$/.test(brut)) return brut.slice(0, 10);

  const instant = new Date(brut);
  if (Number.isNaN(instant.getTime())) {
    throw new Error(`Horodatage de période illisible : « ${horodatage} »`);
  }
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: fuseau,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(instant);
}

/** Convertit une période brute de Fantrax en période applicative. */
export function normaliserPeriode(
  brute: { number?: number; startDate?: string; endDate?: string },
  fuseau = "America/Toronto",
): Periode | null {
  if (
    typeof brute?.number !== "number" ||
    !brute.startDate ||
    !brute.endDate
  ) {
    return null;
  }

  const debutMs = Date.parse(brute.startDate);
  const finMs = Date.parse(brute.endDate);
  if (Number.isNaN(debutMs) || Number.isNaN(finMs)) return null;

  return {
    numero: brute.number,
    debut: brute.startDate,
    fin: brute.endDate,
    dateDebut: dateCivile(brute.startDate, fuseau),
    debutMs,
    finMs,
  };
}

/**
 * Détermine la période applicable à un instant donné.
 *
 * - Avant le début de la saison, c'est la première période qui s'applique :
 *   un mouvement fait hors-saison ne prend effet qu'à l'ouverture.
 * - Entre deux périodes (les bornes ne sont pas jointives à la seconde près),
 *   c'est la période suivante qui est retenue.
 * - Après la fin de la saison, c'est la dernière période.
 *
 * Retourne null si aucune période n'est connue.
 */
export function periodePourInstant(
  periodes: readonly Periode[],
  instantMs: number,
): Periode | null {
  if (periodes.length === 0) return null;

  const triees = [...periodes].sort((a, b) => a.debutMs - b.debutMs);
  const premiere = triees[0] as Periode;
  const derniere = triees[triees.length - 1] as Periode;

  if (instantMs < premiere.debutMs) return premiere;
  if (instantMs > derniere.finMs) return derniere;

  for (const periode of triees) {
    if (instantMs >= periode.debutMs && instantMs <= periode.finMs) {
      return periode;
    }
  }

  // Interstice entre deux périodes : on retient la suivante.
  return triees.find((p) => p.debutMs > instantMs) ?? derniere;
}

/**
 * Date à retenir comme date de mise sur la liste des blessés.
 * Repli sur la date calendaire fournie si aucune période n'est connue —
 * l'application doit rester fonctionnelle même sans les périodes.
 */
export function dateIrDepuisPeriode(
  periodes: readonly Periode[],
  instantMs: number,
  dateDeRepli: string,
): { dateIr: string; periode: number | null } {
  const periode = periodePourInstant(periodes, instantMs);
  if (!periode) return { dateIr: dateDeRepli, periode: null };
  return { dateIr: periode.dateDebut, periode: periode.numero };
}

/** Résultat de la datation d'une mise sur IR. */
export interface DatationIr {
  dateIr: string;
  periode: number | null;
  /**
   * Date la plus hâtive possible lorsque la période visée est ambiguë, sinon
   * null. Une valeur non nulle signifie « date à vérifier par un admin ».
   */
  dateIrMin: string | null;
}

/**
 * Date de mise sur IR établie à partir de la période de l'alignement Fantrax
 * (le `period` de getTeamRosters), c'est-à-dire la période visée par le
 * mouvement.
 *
 * Cas ambigu : si la période de l'alignement a avancé depuis le passage
 * précédent du robot, le mouvement a pu être fait juste avant un verrouillage
 * (il visait alors la période précédente) ou juste après (il vise la période
 * affichée). Le robot ne peut pas trancher : il retient la période affichée
 * par Fantrax (décision de la ligue) et renseigne `dateIrMin` pour qu'un admin
 * vérifie.
 *
 * Repli sur {@link dateIrDepuisPeriode} si la période de l'alignement est
 * absente ou introuvable dans le calendrier.
 */
export function dateIrDepuisAlignement(
  periodes: readonly Periode[],
  periodeAlignement: number | null,
  periodePrecedente: number | null,
  instantMs: number,
  dateDeRepli: string,
): DatationIr {
  const visee =
    periodeAlignement === null
      ? undefined
      : periodes.find((p) => p.numero === periodeAlignement);

  if (!visee) {
    return { ...dateIrDepuisPeriode(periodes, instantMs, dateDeRepli), dateIrMin: null };
  }

  // Période précédente inconnue (première exécution) : on ne sait pas depuis
  // quand l'alignement est dans cet état, on considère donc la période N-1.
  const numeroHatif = periodePrecedente ?? visee.numero - 1;

  let dateIrMin: string | null = null;
  if (numeroHatif < visee.numero) {
    const hative = periodes.find((p) => p.numero === numeroHatif);
    if (hative && hative.dateDebut !== visee.dateDebut) dateIrMin = hative.dateDebut;
  }

  return { dateIr: visee.dateDebut, periode: visee.numero, dateIrMin };
}
