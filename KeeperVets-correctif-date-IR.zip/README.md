# KeeperVets

Outil d'administration du pool keeper de hockey (ligue Fantrax `dj5yxdi4mr3pi83o`, 13 équipes).

Il outille deux responsabilités d'administrateur :

1. **Liste des blessés** — faire respecter la règle des 7 jours de calendrier.
2. **Admissibilité farm** — surveiller le compteur de parties en carrière et
   alerter avant qu'un joueur perde son admissibilité.

Il offre aussi un onglet **📖 Règlements** qui présente le livre des
règlements de la ligue (voir [Livre des règlements](#livre-des-règlements)).

---

## Démarrage rapide

**En un clic** : double-clique sur **`demarrer.cmd`** à la racine du projet.

Le script vérifie Node.js, installe les dépendances si besoin, met la base à
jour, démarre le serveur et ouvre le navigateur dès qu'il répond. Relancé alors
que le serveur tourne déjà, il se contente de rouvrir l'onglet. Pour arrêter :
`Ctrl+C` dans la fenêtre.

Au tout premier lancement, si `.dev.vars` n'existe pas, le script le crée et
ouvre le Bloc-notes pour que tu y inscrives le mot de passe administrateur.

**En ligne de commande**, si tu préfères :

```powershell
npm install

# Créer la base D1 locale et appliquer les migrations
npm run db:init

# Renseigner les secrets locaux
Copy-Item .dev.vars.example .dev.vars
# puis éditer .dev.vars

# Démarrer (http://127.0.0.1:8787)
npm run dev
```

Une fois l'application ouverte : **Connexion admin** → choisir son nom → mot de
passe → **↻ Lancer le robot**. La première exécution prend environ 40 secondes
(elle construit le dictionnaire des ~1690 joueurs de la LNH).

> ⚠️ **En local, le déclencheur Cron ne s'active pas tout seul** : c'est une
> limite de Wrangler, pas un défaut de l'application. Il faut lancer le robot
> depuis l'interface, ou appeler
> `curl "http://127.0.0.1:8787/cdn-cgi/local/scheduled"`.
> Le rythme de deux heures ne prendra effet qu'une fois l'application déployée
> sur Cloudflare.

### Commandes utiles

| Commande | Rôle |
|---|---|
| `demarrer.cmd` | Démarrage local en un clic (double-clic) |
| `deployer.cmd` | Déploiement sur Cloudflare en un clic |
| `npm run dev` | Serveur local |
| `npm test` | Tests de la logique métier |
| `npm run typecheck` | Vérification TypeScript |
| `npm run db:init` | Migrations sur la base locale |
| `npm run db:console "SELECT ..."` | Requête SQL sur la base locale |

Déclencher le robot en ligne de commande :

```powershell
curl "http://127.0.0.1:8787/cdn-cgi/local/scheduled"   # simule le Cron
```

---

## Les deux règles métier

### Règle des 7 jours (liste des blessés)

Un joueur mis sur IR doit y demeurer **7 jours de calendrier complets** à
compter de la date de mise sur IR (règle 6.3.3 du livre des règlements V3 ;
c'était 10 jours auparavant).

> Mis sur IR le 5 novembre → peut revenir le **12 novembre**.

La durée est une seule constante, `JOURS_IR`, dans `src/domain/ir.ts`. L'interface
la reçoit de l'API : la changer ne demande aucune retouche au JavaScript. La
migration `0006_ir_sept_jours.sql` a recalculé l'échéance des séjours déjà en
base lors du passage de 10 à 7 jours ; un changement futur demanderait une
migration du même genre.

**La date de mise sur IR est celle du début de la période Fantrax visée par le
mouvement**, pas la date calendaire à laquelle le robot l'a constaté. Fantrax
fige les alignements par périodes (194 pour la saison 2026-2027), et c'est la
période qui fait foi dans la ligue.

⚠️ `getTeamRosters` renvoie l'alignement de la période **modifiable**, soit
souvent la période suivante et non celle en cours. Le robot retient donc la
période de l'alignement (`period`), et non la période en cours au moment où il
constate le changement.

> Exemple réel : Mathew Barzal mis sur IR avec effet le 30 septembre (période 2),
> constaté pendant la période 1. Date retenue : **30 septembre**,
> éligible le **7 octobre**.

**Marque « ⚠ à vérifier ».** Si la période de l'alignement a avancé depuis le
passage précédent du robot, le mouvement a pu viser l'une ou l'autre période.
Le robot retient alors la plus tardive, celle qu'affiche Fantrax, et mémorise
la plus hâtive (colonne `date_ir_min`, migration `0007`). Le dashboard affiche
« ⚠ à vérifier (possiblement le JJ) ». Un admin tranche avec « Corriger la
date », ce qui efface la marque.

Hypothèse : après une réinitialisation de la base, la période précédente est
inconnue. Le robot suppose alors la période visée moins 1, et marque le séjour
« à vérifier ».

> Exemple réel : Connor Bedard placé sur IR le 1<sup>er</sup> septembre, pendant
> la période 1 qui débute le 29 septembre. Sa date de mise sur IR est donc le
> **29 septembre**, et il devient éligible le **6 octobre**.

Hors-saison, la période courante est la première : un mouvement effectué avant
l'ouverture ne démarre l'horloge qu'au coup d'envoi. La date affichée peut donc
être postérieure à aujourd'hui, c'est normal.

Si le calendrier des périodes est indisponible, l'application retombe sur la
date du jour et le signale : elle ne s'arrête pas.

Convention d'affichage « jour X/7 » : X compte les jours écoulés depuis la
mise sur IR. Le 5 novembre est le jour 0/7, le 12 novembre le jour 7/7, qui
est aussi le premier jour d'éligibilité.

| Pastille | Sens |
|---|---|
| 🔴 Bloqué | Doit rester sur la liste des blessés |
| 🟡 Éligible demain | Dernière journée d'attente |
| 🟢 Éligible maintenant | Peut être réactivé |
| ⚠️ Retour prématuré | **Infraction** : réactivé avant la fin des 7 jours |

Une infraction ferme le séjour, mais reste affichée au tableau de bord pendant
**30 jours** — sans quoi elle disparaîtrait avant même d'avoir été vue.

Un administrateur peut corriger la date de mise sur IR ; la date d'éligibilité
est alors recalculée, et le verdict d'infraction réévalué si le séjour est déjà
clos.

### Seuils d'admissibilité farm

| Position | Seuil de parties de saison régulière en carrière |
|---|---|
| Patineur (F, D) | **168** |
| Gardien (G) | **130** |

Les séries éliminatoires ne comptent pas. La règle est « seuil **ou moins** » :
un joueur pile au seuil reste admissible, et le dépassement ne commence qu'à la
partie suivante. **Dès qu'un joueur dépasse son seuil, il doit être retiré du
farm immédiatement.**

| Parties restantes | Niveau |
|---|---|
| < 0 | ⛔ Dépassé — retrait immédiat |
| 0 | 🔴 À la limite — encore admissible, plus aucune marge |
| 1 à 5 | 🔴 Urgent |
| 6 à 10 | 🔴 Critique |
| 11 à 30 | 🟡 Surveiller |
| > 30 | ✅ OK |

Les seuils sont définis dans `src/domain/farm.ts` (`SEUIL_GARDIEN` et
`SEUIL_PATINEUR`). Les modifier demande une republication.

Le bouton **📋 Copier le message** produit un texte prêt à coller sur le groupe
Facebook pour aviser le pooler concerné.

Un joueur en slot farm qui passe sur la liste des blessés quitte l'onglet Farm
le temps de son séjour : Fantrax remplace son statut `MINORS` par
`INJURED_RESERVE`, et le compteur farm ne suit que les joueurs effectivement
dans les mineures. Son nombre de parties reste évidemment exact à son retour.

### Claims (transactions)

Chaque équipe reçoit **4 claims** au début de la saison. Particularité de la
ligue : **les claims s'échangent entre poolers**, un solde peut donc dépasser 4
ou passer sous zéro.

> Exemple réel : les Gamblers ont cédé un claim aux Déesses de Laval.
> Résultat : Déesses 5, Gamblers 3.

Le suivi prend la forme d'un **grand livre** : le solde n'est jamais stocké, il
est recalculé à partir des mouvements. Chaque ligne conserve son auteur, sa date
et son motif — un solde est donc toujours explicable à un pooler qui le conteste.

| Mouvement | Origine |
|---|---|
| Dotation | Robot, au début de la saison |
| Claim utilisé | Robot, sur détection d'une acquisition |
| Reçu / Cédé | Administrateur, lors d'un échange |
| Ajustement | Administrateur, avec motif obligatoire |

**Détection automatique.** Le robot distingue une véritable acquisition (le
joueur n'appartenait à aucune équipe du pool) d'un simple échange entre deux
poolers. Seule la première consomme un claim. Aucune détection n'a lieu au tout
premier passage du robot, sans quoi l'ensemble du pool serait compté comme des
acquisitions.

**Protection contre le double comptage.** La dotation de début de saison ne
concerne que les équipes n'ayant encore aucun mouvement. Si un administrateur a
déjà saisi un solde à la main, cette équipe est laissée telle quelle.

Le décompte automatique ne démarre qu'une fois la saison ouverte : les
mouvements de préparation et de repêchage ne consomment pas de claim.

| Solde | Affichage |
|---|---|
| Aucun mouvement | ⏳ Pas encore doté |
| < 0 | ⛔ Solde négatif |
| 0 | 🔴 Épuisé |
| 1 | 🟡 Dernier claim |
| 2 | 🟡 Il en reste 2 |
| ≥ 3 | ✅ OK |

> ⚠️ **L'API publique Fantrax n'expose pas les claims restants.** Les trois
> points de terminaison publics ne renvoient que le classement et les
> alignements ; `getTransactions`, `getClaims` et leurs variantes n'existent
> pas. Ce compteur est donc tenu par l'application, pas lu chez Fantrax.

---

## Livre des règlements

L'onglet **📖 Règlements** affiche le livre des règlements de la ligue (version
V3), découpé en sections et en règles numérotées, avec un sommaire et une
recherche. Il est aussi accessible seul, sans l'application autour, à l'adresse
**`/reglements`** — pratique pour partager un lien sur le groupe Facebook.

Le texte barré et le surlignage jaune du document Word sont conservés tels quels.
Les surlignages roses et les commentaires Word ne sont pas repris.

**Mettre à jour le livre** : le contenu vit dans un seul fichier,
`public/reglements.html`. On y modifie le texte de la règle voulue, puis on
republie (`deployer.cmd`). L'onglet et la page seule lisent ce même fichier.

Chaque règle suit ce gabarit :

```html
<div class="regle" id="r-6-3">
  <span class="regle-no">6.3</span>
  <div class="regle-texte">Texte de la règle…</div>
</div>
```

Ajouter `sous` à la classe (`class="regle sous"`) pour une sous-règle (6.3.1).
`<del>…</del>` barre un passage, `<mark>…</mark>` le surligne en jaune.

---

## Architecture

```
src/
├─ domain/      Logique métier pure — aucun réseau, aucune base. C'est ici que
│               vivent la règle des 7 jours, les périodes Fantrax, les seuils
│               et l'appariement des noms. Entièrement couverte par les tests.
├─ sources/     Clients HTTP Fantrax et LNH. Ne lèvent jamais d'exception :
│               ils retournent un résultat « ok » ou « erreur ».
├─ db/          Accès D1.
├─ robot/       Orchestration d'une exécution de synchronisation.
├─ api/         Routage HTTP, authentification, construction des vues.
└─ index.ts     Point d'entrée (fetch + scheduled).

public/         Interface web : HTML, CSS et JS sans build ni dépendance.
                reglements.html contient le livre des règlements.
migrations/     Schéma D1.
tests/          Tests Vitest de src/domain.
```

### Le robot

Déclenché par Cron **aux 2 heures**, ou manuellement depuis l'interface.

1. Lecture des alignements Fantrax.
2. Résolution du sens de chaque statut via le mapping configurable.
3. Détection des transitions vers et hors de la liste des blessés.
4. Rafraîchissement du dictionnaire d'appariement des noms de la LNH.
5. Appariement des joueurs en slot farm et lecture de leurs parties en carrière.

**Travail par lots.** Une synchronisation exhaustive coûte environ 136 appels
externes, or Cloudflare limite à 50 sous-requêtes par exécution sur le plan
gratuit. Le robot traite donc environ 12 sources LNH et 25 fiches de joueurs
par exécution, en rotation : un cycle complet s'étale sur une douzaine
d'heures, ce qui est largement suffisant puisque les alignements bougent peu.

Les joueurs dont la marge est la plus faible sont rafraîchis **en priorité** :
un joueur sur le point de franchir son seuil reste suivi de près même quand le
quota d'appels est serré.

En local, la limite ne s'applique pas : le bouton de l'interface lance une
exécution complète (`?complet=1`).

### Robustesse

- Si Fantrax ne répond pas, **rien n'est effacé** : les dernières données
  connues restent affichées, avec l'horodatage de la dernière lecture réussie.
- Un échec d'appariement laisse le joueur en « ❔ À vérifier ». Il n'est
  **jamais** supposé à zéro partie : un échec d'appariement ne prouve pas
  qu'un joueur n'a jamais joué.
- Les parties en carrière sont mises en cache pendant 18 heures.

---

## Statuts Fantrax

Le mapping « statut brut → sens métier » est **configurable** depuis l'onglet
Administration.

| Statut | Sens | Origine |
|---|---|---|
| `ACTIVE` | Alignement actif | Observé |
| `MINORS` | Slot farm | Observé |
| `INJURED_RESERVE` | Liste des blessés | Observé le 2026-09-01 |

La valeur du statut de blessé n'était pas connue lors de la conception : elle
n'a pas été devinée. Elle a été **confirmée en conditions réelles** le
2026-09-01, quand un administrateur a placé Connor Bedard sur la liste des
blessés dans Fantrax. Elle est désormais amorcée par la migration `0003`.

Le mécanisme de découverte reste actif pour tout statut futur : si Fantrax
introduit une variante (mise sur IR de longue durée, par exemple), le robot
l'enregistrera en `INCONNU` sans s'interrompre et un bandeau d'alerte
apparaîtra en haut de l'interface. Il suffira de la classer dans l'onglet
Administration.

> Un statut resté `INCONNU` n'ouvre **aucun** séjour IR. C'est volontaire :
> mieux vaut une alerte visible qu'une interprétation hasardeuse.

---

## Sources de données

Toutes publiques, aucune authentification.

**Fantrax**
- `getTeamRosters` — alignements et statuts
- `getPlayerIds` — noms au format « Nom, Prénom » (inversé à la lecture).
  ⚠️ Ne contient pas l'identifiant NHL officiel.
- `getStandings` — classement
- `getLeagueInfo` — bornes de saison et **194 périodes de roster**.
  ⚠️ Volumineux (~386 Ko) : relu seulement si les périodes manquent, ou lors
  d'une exécution complète.

**LNH** (`api-web.nhle.com`)
- `standings/now` — les 32 codes d'équipe
- `roster/{TRI}/current` et `prospects/{TRI}` — construction du dictionnaire
- `player/{id}/landing` — parties en carrière (champ parfois absent → 0)
- Filet de sécurité : `records.nhl.com`

> ⛔ **`search.nhle.com` est bloqué par le DNS du réseau corporatif et n'est
> délibérément pas utilisé.**

### Appariement des noms

Fantrax ne fournit pas l'identifiant NHL : les joueurs sont appariés par leur
nom, en trois étapes.

1. **Nom complet normalisé** — accents retirés, minuscules, `[a-z ]`
   uniquement. Le dictionnaire est bâti à partir des 32 alignements et des
   32 listes d'espoirs (~1690 joueurs).
2. **Équipe NHL + nom de famille**, si la clé désigne un joueur unique dans
   l'équipe.
3. **Recherche nominative** dans les archives de la LNH.

Les étapes 2 et 3 corrigent un défaut de la preuve de concept d'origine :

| Fantrax | LNH | Cause |
|---|---|---|
| Benjamin Kindel | **Ben** Kindel | Diminutif |
| Axel Sandin Pellikka | Axel Sandin**-**Pellikka | Trait d'union |

La normalisation supprimait le trait d'union sans le remplacer par un espace
(`sandinpellikka` ≠ `sandin pellikka`). Ces deux joueurs étaient donc classés
« aucun match NHL » et comptés à **0 partie**, alors qu'ils en ont
respectivement **77** et **68**. Deux formes normalisées sont désormais
indexées pour chaque nom.

---

## Accès et traçabilité

- **Vue publique** en lecture seule pour les poolers, sans connexion.
- **Quatre administrateurs** en écriture : Pierre-Luc, Patrick, Dono et Hugo. Ils
  partagent un mot de passe unique ; chacun choisit son nom au moment de se
  connecter, et ce nom est scellé dans un cookie signé (HMAC-SHA256).
- Toutes les actions d'écriture sont journalisées (qui, quoi, quand), y compris
  les tentatives de connexion refusées.

> Limite assumée : ce dispositif n'empêche pas un administrateur de se déclarer
> sous le nom d'un autre. Il répond au besoin de traçabilité, pas à un besoin
> d'authentification forte.

Secrets dans `.dev.vars` (exclu du dépôt) :

| Variable | Rôle |
|---|---|
| `ADMIN_PASSWORD` | Mot de passe partagé |
| `SESSION_SECRET` | Clé de signature du cookie |

---

## API

### Lecture publique

| Route | Description |
|---|---|
| `GET /api/tableau-de-bord` | Vue complète : blessés, farm, anomalies, résumé |
| `GET /api/blesses[?historique=1]` | Séjours IR |
| `GET /api/farm` | Joueurs en slot farm |
| `GET /api/claims` | Soldes de claims et grand livre |
| `GET /api/statuts` | Mapping des statuts |
| `GET /api/executions` | 20 dernières exécutions du robot |
| `GET /api/session` | État de la session |

### Écriture (session administrateur requise)

| Route | Description |
|---|---|
| `POST /api/connexion` | `{ admin, motDePasse }` |
| `POST /api/deconnexion` | |
| `POST /api/blesses/:id/date-ir` | `{ dateIr, note? }` — recalcule l'éligibilité |
| `POST /api/statuts` | `{ statutBrut, type, libelle? }` |
| `POST /api/claims/echange` | `{ deTeamId, versTeamId, quantite, motif? }` |
| `POST /api/claims/ajustement` | `{ teamId, quantite, motif }` — motif obligatoire |
| `DELETE /api/claims/mouvement/:id` | Retire un mouvement du grand livre |
| `POST /api/robot/executer[?complet=1]` | Exécution manuelle |
| `GET /api/journal` | Journal d'audit |

---

## Base de données (D1 / SQLite)

| Table | Rôle |
|---|---|
| `equipes` | Les 13 équipes du pool |
| `joueurs` | Référentiel, avec l'identifiant NHL apparié |
| `nhl_index` | Dictionnaire nom normalisé → identifiant NHL |
| `nhl_index_famille` | Index de repli équipe + nom de famille |
| `nhl_sources` | Rotation des 64 sources LNH |
| `cache_pj` | Cache des parties en carrière |
| `roster_courant` | Dernier état connu — base de la détection de transitions |
| `periodes` | Les 194 périodes de roster Fantrax |
| `mapping_statuts` | Statut brut → sens métier (configurable) |
| `sejours_ir` | Séjours sur la liste des blessés, courants et historiques |
| `claims_mouvements` | Grand livre des claims par équipe |
| `executions` | Journal des exécutions du robot |
| `journal_admin` | Journal d'audit |
| `etat_app` | Clé/valeur : dernières lectures réussies, période |

`roster_courant` a pour clé le seul identifiant du joueur, et non le couple
(équipe, joueur) : un joueur échangé entre deux équipes du pool alors qu'il est
blessé ne doit pas être interprété comme un retour de blessure.

---

## Tests

```powershell
npm test
```

120 tests couvrent la logique métier : calcul des 7 jours (dont changements
d'heure et années bissextiles), résolution des périodes Fantrax, seuils farm,
comptabilité des claims, détection de retour prématuré, détection de transitions
et appariement des noms.

Ils incluent une **non-régression** sur des valeurs réelles observées :
Justin Brazeau 159 PJ, Joseph Woll 117 (G), Mavrik Bourque 156, Joel Hofer
115 (G), Simon Nemec 155, Josh Doan 144.

---

## Déploiement sur Cloudflare

Le même code fonctionne en local et en ligne. Une fois déployé, l'application
est accessible depuis n'importe quel appareil et **le robot tourne tout seul
aux 2 heures, sans qu'aucun ordinateur ne soit allumé**.

**En un clic** : double-clique sur **`deployer.cmd`**. Le script se charge de
tout et il est ré-exécutable — il ne refait que ce qui manque.

Il te faudra un compte Cloudflare : https://dash.cloudflare.com/sign-up
(gratuit, sans carte de crédit).

Le script enchaîne :

1. `wrangler login` — autorisation dans le navigateur ;
2. création de la base D1 et report de son identifiant dans `wrangler.jsonc` ;
3. application des migrations sur la base distante ;
4. saisie des secrets — tu tapes le mot de passe **directement dans le
   terminal**, il ne passe par aucun fichier. La clé de signature est générée
   aléatoirement ;
5. publication.

Ensuite : ouvre l'adresse fournie, connecte-toi, lance le robot une première
fois. Le dictionnaire NHL se remplit sur quelques exécutions, c'est normal.

### Ce que le plan gratuit permet

| Ressource | Limite | Besoin réel |
|---|---|---|
| Requêtes | 100 000 / jour | quelques centaines |
| Temps processeur | **10 ms par exécution** | ≈ 2,7 ms (voir ci-dessous) |
| Sous-requêtes externes | 50 par exécution | ≈ 40 |
| Base D1 | 1 Go, 1 M lectures / jour | quelques Mo |
| Déclencheurs Cron | inclus | 1 |

**Le temps processeur est la contrainte serrée**, et elle a dicté deux choix de
conception :

- Le référentiel Fantrax `getPlayerIds` pèse 1,1 Mo et couvre près de
  9000 joueurs, alors que le pool en compte 227. Il n'est téléchargé que
  lorsqu'un joueur du pool n'a pas encore de fiche, et les noms sont récupérés
  par accès direct plutôt qu'en parcourant tout le référentiel — mesuré à
  0,31 ms au lieu de 4,04 ms.
- Le travail NHL est réparti en lots rotatifs, allégés davantage lorsque le
  référentiel a dû être lu durant la même exécution.

Une exécution ordinaire consomme environ **2,7 ms** de temps processeur, soit
un peu plus du quart du budget.

### Points à savoir

- **La vue publique est réellement publique.** Toute personne connaissant
  l'adresse peut consulter les blessés, le farm et les claims. C'est voulu — les
  poolers y ont accès sans mot de passe — mais l'écriture reste protégée.
- **Choisis un mot de passe solide et unique.** Ne réutilise pas un mot de passe
  employé ailleurs.
- **Le domaine `*.workers.dev` est parfois bloqué sur les réseaux
  d'entreprise** (c'est déjà le cas de `search.nhle.com` chez iA). Si l'adresse
  ne répond pas au bureau, elle fonctionnera tout de même depuis la maison et
  sur téléphone. Un domaine personnalisé contourne ce blocage.
- Les valeurs de `.dev.vars` ne servent qu'au développement local ; les secrets
  de production sont stockés chez Cloudflare, séparément.

### En ligne de commande, si tu préfères

```powershell
npx wrangler login
npx wrangler d1 create keepervets          # reporter l'id dans wrangler.jsonc
npx wrangler d1 migrations apply keepervets --remote
npx wrangler secret put ADMIN_PASSWORD
npx wrangler secret put SESSION_SECRET
npm run deploy
```

