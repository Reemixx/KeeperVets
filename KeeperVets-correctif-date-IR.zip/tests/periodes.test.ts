import { describe, expect, it } from "vitest";
import {
  dateCivile,
  dateIrDepuisAlignement,
  dateIrDepuisPeriode,
  normaliserPeriode,
  periodePourInstant,
  type Periode,
} from "../src/domain/periodes.js";
import { calculerEligibilite } from "../src/domain/ir.js";

/** Périodes réelles de la ligue, telles que renvoyées par getLeagueInfo. */
const P1 = normaliserPeriode({
  number: 1,
  startDate: "2026-09-29T17:00:00-04:00",
  endDate: "2026-09-30T19:29:59-04:00",
}) as Periode;

const P2 = normaliserPeriode({
  number: 2,
  startDate: "2026-09-30T19:30:00-04:00",
  endDate: "2026-10-01T18:59:59-04:00",
}) as Periode;

const P3 = normaliserPeriode({
  number: 3,
  startDate: "2026-10-01T19:00:00-04:00",
  endDate: "2026-10-02T18:29:59-04:00",
}) as Periode;

const P194 = normaliserPeriode({
  number: 194,
  startDate: "2027-04-10T12:30:00-04:00",
  endDate: "2027-04-11T11:59:59-04:00",
}) as Periode;

const PERIODES = [P1, P2, P3, P194];

describe("dateCivile", () => {
  it("conserve la date locale quand le décalage est explicite", () => {
    // 17 h le 29 septembre à Toronto, soit 21 h UTC : la date locale est bien le 29.
    expect(dateCivile("2026-09-29T17:00:00-04:00")).toBe("2026-09-29");
  });

  it("ne bascule pas au lendemain sur une soirée de match", () => {
    // 19 h 30 le 30 septembre en heure de l'Est, soit 23 h 30 UTC.
    expect(dateCivile("2026-09-30T19:30:00-04:00")).toBe("2026-09-30");
  });

  it("convertit un horodatage UTC vers le fuseau de la ligue", () => {
    // 2026-09-30T23:30:00Z correspond au 30 septembre 19 h 30 à Toronto.
    expect(dateCivile("2026-09-30T23:30:00Z", "America/Toronto")).toBe("2026-09-30");
    // 2026-10-01T02:00:00Z correspond au 30 septembre 22 h à Toronto.
    expect(dateCivile("2026-10-01T02:00:00Z", "America/Toronto")).toBe("2026-09-30");
  });

  it("refuse un horodatage illisible", () => {
    expect(() => dateCivile("pas une date")).toThrow();
  });
});

describe("normaliserPeriode", () => {
  it("extrait la date civile du début", () => {
    expect(P1.numero).toBe(1);
    expect(P1.dateDebut).toBe("2026-09-29");
  });

  it("rejette une période incomplète sans planter", () => {
    expect(normaliserPeriode({ number: 1 })).toBeNull();
    expect(normaliserPeriode({ startDate: "2026-09-29T17:00:00-04:00" })).toBeNull();
    expect(
      normaliserPeriode({ number: 1, startDate: "invalide", endDate: "invalide" }),
    ).toBeNull();
  });
});

describe("periodePourInstant", () => {
  it("retient la première période avant le début de la saison", () => {
    // Le 1er septembre, la saison n'a pas commencé.
    const instant = Date.parse("2026-09-01T12:00:00-04:00");
    expect(periodePourInstant(PERIODES, instant)?.numero).toBe(1);
  });

  it("retient la période qui contient l'instant", () => {
    expect(
      periodePourInstant(PERIODES, Date.parse("2026-09-29T20:00:00-04:00"))?.numero,
    ).toBe(1);
    expect(
      periodePourInstant(PERIODES, Date.parse("2026-10-01T10:00:00-04:00"))?.numero,
    ).toBe(2);
  });

  it("bascule à la période suivante juste après une frontière", () => {
    // La période 1 se termine à 19:29:59 ; une seconde plus tard, c'est la 2.
    expect(
      periodePourInstant(PERIODES, Date.parse("2026-09-30T19:29:59-04:00"))?.numero,
    ).toBe(1);
    expect(
      periodePourInstant(PERIODES, Date.parse("2026-09-30T19:30:00-04:00"))?.numero,
    ).toBe(2);
  });

  it("retient la dernière période après la fin de la saison", () => {
    expect(
      periodePourInstant(PERIODES, Date.parse("2027-06-01T12:00:00-04:00"))?.numero,
    ).toBe(194);
  });

  it("retourne null si aucune période n'est connue", () => {
    expect(periodePourInstant([], Date.now())).toBeNull();
  });

  it("n'est pas sensible à l'ordre de la liste fournie", () => {
    const desordre = [P3, P1, P194, P2];
    expect(
      periodePourInstant(desordre, Date.parse("2026-09-01T12:00:00-04:00"))?.numero,
    ).toBe(1);
  });
});

describe("dateIrDepuisPeriode", () => {
  it("retient la date de début de période, pas la date du jour", () => {
    // Cas réel : Bedard placé sur IR le 1er septembre, pendant la période 1.
    const resultat = dateIrDepuisPeriode(
      PERIODES,
      Date.parse("2026-09-01T20:00:00-04:00"),
      "2026-09-01",
    );
    expect(resultat.dateIr).toBe("2026-09-29");
    expect(resultat.periode).toBe(1);
  });

  it("donne bien le 6 octobre comme date d'éligibilité pour Bedard", () => {
    const { dateIr } = dateIrDepuisPeriode(
      PERIODES,
      Date.parse("2026-09-01T20:00:00-04:00"),
      "2026-09-01",
    );
    expect(calculerEligibilite(dateIr)).toBe("2026-10-06");
  });

  it("retombe sur la date du jour si les périodes sont inconnues", () => {
    const resultat = dateIrDepuisPeriode([], Date.now(), "2026-11-05");
    expect(resultat.dateIr).toBe("2026-11-05");
    expect(resultat.periode).toBeNull();
  });

  it("attribue la bonne période à un mouvement fait en cours de saison", () => {
    const resultat = dateIrDepuisPeriode(
      PERIODES,
      Date.parse("2026-10-01T10:00:00-04:00"),
      "2026-10-01",
    );
    expect(resultat.periode).toBe(2);
    expect(resultat.dateIr).toBe("2026-09-30");
    expect(calculerEligibilite(resultat.dateIr)).toBe("2026-10-07");
  });
});

describe("dateIrDepuisAlignement", () => {
  const instant = Date.parse("2026-09-30T19:15:00-04:00");

  it("date le séjour selon la période visée par l'alignement, pas la période en cours", () => {
    // Cas réel : Barzal, constat le 30 septembre à 19 h 15 (période 1 en
    // cours) alors que Fantrax renvoie déjà l'alignement de la période 2.
    const resultat = dateIrDepuisAlignement(PERIODES, 2, 2, instant, "2026-09-30");
    expect(resultat.dateIr).toBe("2026-09-30");
    expect(resultat.periode).toBe(2);
    expect(resultat.dateIrMin).toBeNull();
    expect(calculerEligibilite(resultat.dateIr)).toBe("2026-10-07");
  });

  it("marque « à vérifier » quand la période a avancé depuis le dernier passage", () => {
    // Période 1 au passage précédent, 2 maintenant : le mouvement visait l'une ou l'autre.
    const resultat = dateIrDepuisAlignement(PERIODES, 2, 1, instant, "2026-09-30");
    expect(resultat.dateIr).toBe("2026-09-30");
    expect(resultat.dateIrMin).toBe("2026-09-29");
  });

  it("ne marque rien si la période précédente débute le même jour", () => {
    const memeJour = normaliserPeriode({
      number: 5,
      startDate: "2026-09-30T23:00:00-04:00",
      endDate: "2026-10-01T18:59:59-04:00",
    }) as Periode;
    const resultat = dateIrDepuisAlignement([P1, P2, memeJour], 5, 2, instant, "2026-09-30");
    expect(resultat.dateIr).toBe("2026-09-30");
    expect(resultat.dateIrMin).toBeNull();
  });

  it("suppose la période précédente quand elle est inconnue (première exécution)", () => {
    const resultat = dateIrDepuisAlignement(PERIODES, 2, null, instant, "2026-09-30");
    expect(resultat.dateIr).toBe("2026-09-30");
    expect(resultat.dateIrMin).toBe("2026-09-29");
  });

  it("ne marque rien pour la toute première période", () => {
    // Cas Bedard : placé sur IR avant la saison, alignement de la période 1.
    const resultat = dateIrDepuisAlignement(
      PERIODES, 1, null, Date.parse("2026-09-01T20:00:00-04:00"), "2026-09-01",
    );
    expect(resultat.dateIr).toBe("2026-09-29");
    expect(resultat.dateIrMin).toBeNull();
  });

  it("se replie sur la période en cours si celle de l'alignement est inconnue", () => {
    const sansPeriode = dateIrDepuisAlignement(PERIODES, null, 1, instant, "2026-09-30");
    expect(sansPeriode.periode).toBe(1);
    expect(sansPeriode.dateIr).toBe("2026-09-29");
    expect(sansPeriode.dateIrMin).toBeNull();

    const introuvable = dateIrDepuisAlignement(PERIODES, 99, 1, instant, "2026-09-30");
    expect(introuvable.periode).toBe(1);
    expect(introuvable.dateIrMin).toBeNull();
  });
});