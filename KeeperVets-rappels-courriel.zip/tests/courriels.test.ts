import { describe, expect, it } from "vitest";
import {
  MAX_ADRESSES_PAR_EQUIPE,
  cleEnvoi,
  composerCourriel,
  deciderEnvois,
  echapperHtml,
  typeAvisPour,
  validerCourriels,
  type JoueurAvis,
} from "../src/domain/courriels.js";

function joueur(partiel: Partial<JoueurAvis> & { fantraxId: string }): JoueurAvis {
  const seuil = partiel.seuil ?? 168;
  const partiesJouees = partiel.partiesJouees === undefined ? 160 : partiel.partiesJouees;
  return {
    teamId: "t1",
    equipe: "Les Vets",
    nom: "Joueur Test",
    seuil,
    partiesJouees,
    reste: partiesJouees === null ? null : seuil - partiesJouees,
    ...partiel,
  };
}

describe("typeAvisPour", () => {
  it("ne déclenche rien si les parties sont inconnues", () => {
    expect(typeAvisPour(null)).toBeNull();
  });
  it("signale un dépassement sous zéro", () => {
    expect(typeAvisPour(-1)).toBe("depassement");
  });
  it("envoie un rappel de 0 à 5 parties restantes", () => {
    expect(typeAvisPour(0)).toBe("rappel");
    expect(typeAvisPour(5)).toBe("rappel");
  });
  it("ne déclenche rien à 6 parties restantes ou plus", () => {
    expect(typeAvisPour(6)).toBeNull();
    expect(typeAvisPour(50)).toBeNull();
  });
});

describe("deciderEnvois", () => {
  it("met les dépassements d'abord, puis les marges les plus minces", () => {
    const avis = deciderEnvois(
      [
        joueur({ fantraxId: "a", partiesJouees: 164 }), // reste 4
        joueur({ fantraxId: "b", partiesJouees: 170 }), // dépassement
        joueur({ fantraxId: "c", partiesJouees: 167 }), // reste 1
        joueur({ fantraxId: "d", partiesJouees: 100 }), // rien
        joueur({ fantraxId: "e", partiesJouees: null }), // inconnu
      ],
      new Set(),
    );
    expect(avis.map((a) => `${a.joueur.fantraxId}:${a.type}`)).toEqual([
      "b:depassement",
      "c:rappel",
      "a:rappel",
    ]);
  });

  it("exclut les avis déjà envoyés, par équipe et par type", () => {
    const deja = new Set([cleEnvoi("t1", "a", "rappel")]);
    const avis = deciderEnvois(
      [
        joueur({ fantraxId: "a", partiesJouees: 165 }),
        joueur({ fantraxId: "a", teamId: "t2", partiesJouees: 165 }),
      ],
      deja,
    );
    expect(avis).toHaveLength(1);
    expect(avis[0]!.joueur.teamId).toBe("t2");
  });

  it("envoie le dépassement même si le rappel a déjà été envoyé", () => {
    const deja = new Set([cleEnvoi("t1", "a", "rappel")]);
    const avis = deciderEnvois([joueur({ fantraxId: "a", partiesJouees: 169 })], deja);
    expect(avis).toEqual([expect.objectContaining({ type: "depassement" })]);
  });

  it("applique le seuil des gardiens", () => {
    const avis = deciderEnvois(
      [joueur({ fantraxId: "g", seuil: 130, partiesJouees: 126 })],
      new Set(),
    );
    expect(avis).toHaveLength(1);
    expect(avis[0]!.type).toBe("rappel");
  });
});

describe("validerCourriels", () => {
  it("accepte une saisie vide (aucune adresse)", () => {
    expect(validerCourriels("   ")).toEqual({ ok: true, adresses: [] });
  });
  it("accepte virgules, points-virgules et espaces, en minuscules et sans doublon", () => {
    expect(validerCourriels("A@x.com; b@y.ca , a@X.com  c@z.org")).toEqual({
      ok: true,
      adresses: ["a@x.com", "b@y.ca", "c@z.org"],
    });
  });
  it("refuse une adresse invalide en la nommant", () => {
    const resultat = validerCourriels("ok@x.com, pasbon@, autre");
    expect(resultat.ok).toBe(false);
    if (!resultat.ok) {
      expect(resultat.erreur).toContain("pasbon@");
      expect(resultat.erreur).toContain("autre");
    }
  });
  it(`refuse plus de ${MAX_ADRESSES_PAR_EQUIPE} adresses`, () => {
    const saisie = Array.from({ length: MAX_ADRESSES_PAR_EQUIPE + 1 }, (_, i) => `p${i}@x.com`).join(",");
    expect(validerCourriels(saisie).ok).toBe(false);
  });
});

describe("composerCourriel", () => {
  it("compose un rappel au pluriel", () => {
    const c = composerCourriel(joueur({ fantraxId: "a", nom: "Justin Brazeau", partiesJouees: 165 }), "rappel");
    expect(c.sujet).toBe("🔔 Justin Brazeau : 3 parties avant la limite farm");
    expect(c.texte).toContain("165/168");
    expect(c.texte).toContain("Il lui reste 3 parties");
  });
  it("accorde au singulier à une partie de la limite", () => {
    const c = composerCourriel(joueur({ fantraxId: "a", nom: "X", partiesJouees: 167 }), "rappel");
    expect(c.sujet).toBe("🔔 X : 1 partie avant la limite farm");
    expect(c.texte).toContain("Il lui reste 1 partie avant");
  });
  it("signale le cas pile à la limite", () => {
    const c = composerCourriel(joueur({ fantraxId: "a", nom: "X", partiesJouees: 168 }), "rappel");
    expect(c.sujet).toBe("🔴 X est à la limite farm");
    expect(c.texte).toContain("exactement à la limite");
  });
  it("compose une alerte de dépassement", () => {
    const c = composerCourriel(joueur({ fantraxId: "a", nom: "X", partiesJouees: 170 }), "depassement");
    expect(c.sujet).toBe("⛔ X n'est plus admissible au farm");
    expect(c.texte).toContain("2 parties de trop");
  });
  it("échappe le HTML des noms d'équipe et de joueur", () => {
    const c = composerCourriel(
      joueur({ fantraxId: "a", nom: "<b>X</b>", equipe: "Tom & Jerry", partiesJouees: 165 }),
      "rappel",
    );
    expect(c.html).not.toContain("<b>X</b>");
    expect(c.html).toContain("&lt;b&gt;X&lt;/b&gt;");
    expect(c.html).toContain("Tom &amp; Jerry");
  });
});

describe("echapperHtml", () => {
  it("échappe les cinq caractères spéciaux", () => {
    expect(echapperHtml(`<a href="x">'&'</a>`)).toBe(
      "&lt;a href=&quot;x&quot;&gt;&#39;&amp;&#39;&lt;/a&gt;",
    );
  });
});
