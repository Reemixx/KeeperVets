/**
 * Rappels farm par courriel : logique pure (aucun accès réseau ni base).
 *
 * Deux avis possibles par joueur et par équipe, chacun envoyé une seule fois :
 *   - « rappel »      : il reste 5 parties ou moins avant le seuil (0 compris,
 *                       le joueur étant encore admissible pile au seuil) ;
 *   - « depassement » : le seuil est dépassé, le joueur doit quitter le farm.
 */

import { MARGES } from "./farm.js";

export type TypeAvis = "rappel" | "depassement";

/** Joueur en slot farm, déjà évalué contre son seuil. */
export interface JoueurAvis {
  fantraxId: string;
  teamId: string;
  equipe: string;
  nom: string;
  partiesJouees: number | null;
  seuil: number;
  reste: number | null;
}

export interface AvisAEnvoyer {
  joueur: JoueurAvis;
  type: TypeAvis;
}

/** Nombre maximal d'adresses par équipe (copropriétaires). */
export const MAX_ADRESSES_PAR_EQUIPE = 5;

const FORMAT_COURRIEL = /^[^\s@,;<>"]+@[^\s@,;<>"]+\.[^\s@,;<>"]+$/;

/**
 * Type d'avis correspondant à une marge. Une marge inconnue (parties non
 * récupérées) ne déclenche rien : on n'écrit pas à un pooler sur une supposition.
 */
export function typeAvisPour(reste: number | null): TypeAvis | null {
  if (reste === null) return null;
  if (reste < 0) return "depassement";
  if (reste <= MARGES.urgent) return "rappel";
  return null;
}

/** Clé d'unicité d'un envoi réussi. */
export function cleEnvoi(teamId: string, fantraxId: string, type: TypeAvis): string {
  return `${teamId}|${fantraxId}|${type}`;
}

/**
 * Détermine les avis à envoyer, en excluant ceux déjà envoyés avec succès.
 * Les dépassements passent en premier (urgence), puis les marges les plus
 * minces : si le plafond par exécution est atteint, le reste attend.
 */
export function deciderEnvois(
  joueurs: JoueurAvis[],
  dejaEnvoyes: Set<string>,
): AvisAEnvoyer[] {
  const avis: AvisAEnvoyer[] = [];
  for (const joueur of joueurs) {
    const type = typeAvisPour(joueur.reste);
    if (type === null) continue;
    if (dejaEnvoyes.has(cleEnvoi(joueur.teamId, joueur.fantraxId, type))) continue;
    avis.push({ joueur, type });
  }
  return avis.sort((a, b) => {
    if (a.type !== b.type) return a.type === "depassement" ? -1 : 1;
    return (a.joueur.reste ?? 0) - (b.joueur.reste ?? 0);
  });
}

/**
 * Valide et normalise une saisie d'adresses séparées par des virgules,
 * des points-virgules ou des espaces. Une saisie vide est valide : elle
 * signifie « aucune adresse » pour l'équipe.
 */
export function validerCourriels(
  saisie: string,
): { ok: true; adresses: string[] } | { ok: false; erreur: string } {
  const adresses = [
    ...new Set(
      saisie
        .split(/[,;\s]+/)
        .map((a) => a.trim().toLowerCase())
        .filter((a) => a.length > 0),
    ),
  ];
  const invalides = adresses.filter((a) => a.length > 254 || !FORMAT_COURRIEL.test(a));
  if (invalides.length > 0) {
    return { ok: false, erreur: `Adresse invalide : ${invalides.join(", ")}` };
  }
  if (adresses.length > MAX_ADRESSES_PAR_EQUIPE) {
    return {
      ok: false,
      erreur: `Maximum ${MAX_ADRESSES_PAR_EQUIPE} adresses par équipe.`,
    };
  }
  return { ok: true, adresses };
}

/** Échappe le texte destiné à un gabarit HTML. */
export function echapperHtml(texte: string): string {
  return texte
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

/** Corps d'un avis, en texte brut. */
function paragraphes(joueur: JoueurAvis, type: TypeAvis): string[] {
  const { nom, partiesJouees, seuil, reste } = joueur;
  const pj = partiesJouees ?? 0;

  if (type === "depassement") {
    const excedent = Math.abs(reste ?? 0);
    const parties = excedent <= 1 ? "partie" : "parties";
    return [
      `${nom} a atteint ${pj} parties en carrière dans la LNH, alors que le seuil farm est de ${seuil}.`,
      `Il n'est plus admissible au farm (${excedent} ${parties} de trop) et doit en être retiré immédiatement.`,
      `Contacte un administrateur pour faire le mouvement.`,
    ];
  }

  if (reste === 0) {
    return [
      `${nom} est à ${pj}/${seuil} parties en carrière dans la LNH : exactement à la limite.`,
      `Il est encore admissible au farm, mais dès sa prochaine partie il ne le sera plus. Prévois ton coup maintenant.`,
    ];
  }

  const matchs = (reste ?? 0) <= 1 ? "partie" : "parties";
  return [
    `${nom} est à ${pj}/${seuil} parties en carrière dans la LNH.`,
    `Il lui reste ${reste} ${matchs} avant de perdre son admissibilité au farm. Prévois ton coup.`,
  ];
}

/** Compose le sujet et les corps texte et HTML d'un avis. */
export function composerCourriel(
  joueur: JoueurAvis,
  type: TypeAvis,
): { sujet: string; texte: string; html: string } {
  const sujet =
    type === "depassement"
      ? `⛔ ${joueur.nom} n'est plus admissible au farm`
      : joueur.reste === 0
        ? `🔴 ${joueur.nom} est à la limite farm`
        : `🔔 ${joueur.nom} : ${joueur.reste} partie${(joueur.reste ?? 0) > 1 ? "s" : ""} avant la limite farm`;

  const corps = paragraphes(joueur, type);
  const signature =
    "Avis automatique du Keeper des Vets. Les parties sont celles de la saison régulière (séries exclues).";

  const texte = [
    `Salut ${joueur.equipe},`,
    "",
    ...corps,
    "",
    "—",
    signature,
  ].join("\n");

  const html =
    `<div style="font-family:Arial,Helvetica,sans-serif;font-size:15px;line-height:1.5;color:#1f2937">` +
    `<p>Salut ${echapperHtml(joueur.equipe)},</p>` +
    corps.map((p) => `<p>${echapperHtml(p)}</p>`).join("") +
    `<p style="color:#6b7280;font-size:12px;border-top:1px solid #e5e7eb;padding-top:8px">` +
    `${echapperHtml(signature)}</p>` +
    `</div>`;

  return { sujet, texte, html };
}
