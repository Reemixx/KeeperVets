/**
 * Configuration applicative et typage de l'environnement Worker.
 */

/** Variables et liaisons injectées par Cloudflare Workers. */
export interface Env {
  /** Base D1. */
  DB: D1Database;
  /** Identifiant de la ligue Fantrax. */
  LEAGUE_ID: string;
  /** Fuseau de référence pour les dates de calendrier. */
  FUSEAU: string;
  /** Liste des administrateurs, séparés par des virgules. */
  ADMINS: string;
  /** Mot de passe partagé des administrateurs (secret, via .dev.vars). */
  ADMIN_PASSWORD: string;
  /** Clé de signature du cookie de session (secret, via .dev.vars). */
  SESSION_SECRET: string;
  /**
   * Clé API Brevo pour les rappels farm par courriel (secret, facultatif).
   * Absente : les rappels restent simplement inactifs.
   */
  BREVO_API_KEY?: string;
}

export const CONFIG = {
  /**
   * Cloudflare limite le nombre de sous-requêtes par exécution de Worker
   * (50 sur le plan gratuit). Le robot travaille donc par lots en rotation :
   * les alignements NHL bougent peu, un cycle complet étalé sur quelques
   * heures est amplement suffisant.
   */
  maxSourcesNhlParRun: 12,
  /**
   * Lot réduit, utilisé quand le robot a déjà analysé le gros référentiel
   * Fantrax durant la même exécution : cela préserve le budget de temps
   * processeur, limité à 10 ms par exécution sur le plan gratuit de Cloudflare.
   */
  maxSourcesNhlLotReduit: 4,
  maxFichesJoueursParRun: 25,

  /**
   * En mode complet (déclenchement manuel, typiquement en local où la limite
   * ne s'applique pas), on lève les plafonds.
   */
  maxSourcesNhlComplet: 64,
  maxFichesJoueursComplet: 400,

  /** Durée de validité du cache des parties jouées en carrière. */
  ttlCachePjHeures: 18,

  /** Délai maximal d'un appel réseau. */
  timeoutMs: 25_000,

  /** Durée de validité d'une session administrateur. */
  sessionDureeHeures: 12,

  /** Pause entre deux appels NHL, pour rester courtois envers l'API. */
  pauseEntreAppelsMs: 60,

  /**
   * Nombre maximal de courriels envoyés par exécution du robot. Chaque envoi
   * est une sous-requête : le plafond protège la limite de 50 du plan
   * gratuit. Les avis restants partent au passage suivant (2 heures plus tard).
   */
  maxCourrielsParRun: 5,
  maxCourrielsComplet: 40,
} as const;

/** Clés utilisées dans la table etat_app. */
export const CLES_ETAT = {
  dernierSuccesFantrax: "dernier_succes_fantrax",
  dernierSuccesNhl: "dernier_succes_nhl",
  derniereExecution: "derniere_execution",
  periodeFantrax: "periode_fantrax",
  debutSaison: "debut_saison",
  finSaison: "fin_saison",
  courrielsActifs: "courriels_actifs",
  courrielExpediteur: "courriel_expediteur",
  courrielNomExpediteur: "courriel_nom_expediteur",
} as const;

/** Découpe la liste des administrateurs autorisés. */
export function listeAdmins(env: Env): string[] {
  return (env.ADMINS ?? "")
    .split(",")
    .map((n) => n.trim())
    .filter((n) => n.length > 0);
}
