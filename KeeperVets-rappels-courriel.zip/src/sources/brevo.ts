/**
 * Client d'envoi de courriels transactionnels via Brevo.
 *
 * Comme les autres sources, il ne lève jamais d'exception : un échec est
 * retourné, journalisé en base, puis retenté au passage suivant du robot.
 */

import { CONFIG } from "../config.js";

const URL_BREVO = "https://api.brevo.com/v3/smtp/email";

export interface MessageCourriel {
  expediteur: { email: string; nom: string };
  destinataires: string[];
  sujet: string;
  texte: string;
  html: string;
}

export type ResultatEnvoi = { ok: true } | { ok: false; erreur: string };

export async function envoyerCourriel(
  cleApi: string,
  message: MessageCourriel,
): Promise<ResultatEnvoi> {
  const minuteur = new AbortController();
  const chrono = setTimeout(() => minuteur.abort(), CONFIG.timeoutMs);
  try {
    const reponse = await fetch(URL_BREVO, {
      method: "POST",
      signal: minuteur.signal,
      headers: {
        "api-key": cleApi,
        "content-type": "application/json",
        accept: "application/json",
      },
      body: JSON.stringify({
        sender: { name: message.expediteur.nom, email: message.expediteur.email },
        to: message.destinataires.map((email) => ({ email })),
        subject: message.sujet,
        htmlContent: message.html,
        textContent: message.texte,
      }),
    });

    if (reponse.status === 201 || reponse.status === 202 || reponse.ok) {
      return { ok: true };
    }

    // Brevo renvoie { code, message } : utile pour diagnostiquer une clé
    // invalide ou un expéditeur non vérifié. La clé n'y figure jamais.
    const detail = await reponse
      .json()
      .then((j: unknown) => {
        const corps = j as { code?: string; message?: string } | null;
        return [corps?.code, corps?.message].filter(Boolean).join(" — ");
      })
      .catch(() => "");
    return {
      ok: false,
      erreur: `HTTP ${reponse.status}${detail ? ` : ${detail}` : ""}`.slice(0, 500),
    };
  } catch (e) {
    return {
      ok: false,
      erreur: (e instanceof Error ? `${e.name}: ${e.message}` : String(e)).slice(0, 500),
    };
  } finally {
    clearTimeout(chrono);
  }
}
