-- Rappels farm par courriel.
--
-- Fantrax n'expose aucune adresse courriel : les administrateurs saisissent
-- eux-mêmes celles de chaque équipe. Une équipe peut avoir plusieurs
-- destinataires (copropriétaires), séparés par des virgules.
CREATE TABLE IF NOT EXISTS courriels_equipes (
  team_id   TEXT PRIMARY KEY,
  courriels TEXT NOT NULL,
  maj_par   TEXT,
  maj_le    TEXT NOT NULL
);

-- Historique des envois.
--   type   : 'rappel' (5 parties restantes ou moins) ou 'depassement'
--   statut : 'envoye' ou 'echec'
CREATE TABLE IF NOT EXISTS envois_courriels (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  team_id       TEXT NOT NULL,
  fantrax_id    TEXT NOT NULL,
  nom_joueur    TEXT,
  type          TEXT NOT NULL CHECK (type IN ('rappel', 'depassement')),
  parties       INTEGER,
  seuil         INTEGER,
  destinataires TEXT NOT NULL,
  envoye_le     TEXT NOT NULL,
  statut        TEXT NOT NULL CHECK (statut IN ('envoye', 'echec')),
  erreur        TEXT
);

-- Un envoi réussi n'est jamais répété pour le même joueur, la même équipe et
-- le même type d'avis. Un échec, lui, sera retenté au passage suivant.
CREATE UNIQUE INDEX IF NOT EXISTS ux_envois_reussis
  ON envois_courriels (team_id, fantrax_id, type)
  WHERE statut = 'envoye';

CREATE INDEX IF NOT EXISTS ix_envois_date ON envois_courriels (envoye_le);
