@echo off
REM ===========================================================================
REM  Le Keeper des Vets - demarrage en un clic
REM
REM  Double-clique sur ce fichier : il prepare tout ce qu'il faut, demarre le
REM  serveur local et ouvre le navigateur.
REM
REM  Pour arreter : Ctrl+C dans la fenetre, ou ferme-la simplement.
REM ===========================================================================

title Le Keeper des Vets
cd /d "%~dp0"

if not exist "scripts\demarrer.ps1" goto :incomplet

powershell -NoProfile -ExecutionPolicy Bypass -File "scripts\demarrer.ps1"
echo.
pause
exit /b

:incomplet
echo.
echo   ================================================
echo      Fichiers manquants
echo   ================================================
echo.
echo   Le dossier "scripts" est introuvable a cet endroit :
echo   %CD%
echo.
echo   Cause la plus frequente : le fichier a ete lance DIRECTEMENT
echo   depuis l'apercu du zip. Windows n'extrait alors que ce seul
echo   fichier dans un dossier temporaire, sans le reste du projet.
echo.
echo   Marche a suivre :
echo     1. Clic droit sur KeeperVets-source.zip
echo     2. "Extraire tout..." puis choisir un dossier
echo        (par exemple C:\KeeperVets)
echo     3. Ouvrir le dossier extrait
echo     4. Double-cliquer sur demarrer.cmd a cet endroit
echo.
echo   Le dossier doit contenir : demarrer.cmd, src, public,
echo   migrations, scripts, package.json
echo.
pause
exit /b 1
