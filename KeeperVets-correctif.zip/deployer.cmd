@echo off
REM ===========================================================================
REM  Le Keeper des Vets - deploiement sur Cloudflare
REM
REM  Double-clique sur ce fichier pour publier l'application en ligne.
REM  Le script est re-executable : il ne refait que ce qui manque.
REM ===========================================================================

title Le Keeper des Vets - deploiement
cd /d "%~dp0"

if not exist "scripts\deployer.ps1" goto :incomplet

powershell -NoProfile -ExecutionPolicy Bypass -File "scripts\deployer.ps1"
echo.
pause
exit /b

:incomplet
echo.
echo   ================================================
echo      Fichiers manquants
echo   ================================================
echo.
echo   Le dossier "scripts" est introuvable a cet endroit :
echo   %CD%
echo.
echo   Cause la plus frequente : le fichier a ete lance DIRECTEMENT
echo   depuis l'apercu du zip. Windows n'extrait alors que ce seul
echo   fichier dans un dossier temporaire, sans le reste du projet.
echo.
echo   Extrais l'archive complete, puis relance depuis le dossier
echo   extrait.
echo.
pause
exit /b 1
