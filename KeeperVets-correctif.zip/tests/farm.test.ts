import { describe, expect, it } from "vitest";
import {
  SEUIL_GARDIEN,
  SEUIL_PATINEUR,
  evaluerFarm,
  messageFacebook,
  niveauPourReste,
  poidsNiveau,
  seuilPour,
} from "../src/domain/farm.js";

describe("seuilPour", () => {
  it("applique 125 parties aux gardiens", () => {
    expect(seuilPour("G")).toBe(SEUIL_GARDIEN);
    expect(seuilPour("g")).toBe(125);
    expect(seuilPour("Goalie")).toBe(125);
  });

  it("applique 164 parties aux patineurs", () => {
    expect(seuilPour("F")).toBe(SEUIL_PATINEUR);
    expect(seuilPour("D")).toBe(164);
    expect(seuilPour("C")).toBe(164);
    expect(seuilPour("RW")).toBe(164);
    expect(seuilPour("LW")).toBe(164);
  });

  it("retombe sur le seuil patineur si la position est absente", () => {
    expect(seuilPour(null)).toBe(164);
    expect(seuilPour("")).toBe(164);
  });
});

describe("niveauPourReste", () => {
  it("classe selon les paliers demandés", () => {
    expect(niveauPourReste(-1102)).toBe("DEPASSE");
    expect(niveauPourReste(-1)).toBe("DEPASSE");
    expect(niveauPourReste(1)).toBe("URGENT");
    expect(niveauPourReste(5)).toBe("URGENT");
    expect(niveauPourReste(6)).toBe("CRITIQUE");
    expect(niveauPourReste(10)).toBe("CRITIQUE");
    expect(niveauPourReste(11)).toBe("SURVEILLER");
    expect(niveauPourReste(30)).toBe("SURVEILLER");
    expect(niveauPourReste(31)).toBe("OK");
  });

  it("traite le seuil exact comme encore admissible, pas comme dépassé", () => {
    // La règle est « seuil OU MOINS » : à 164/164, le joueur reste admissible.
    // Le dépassement ne commence qu'à la partie suivante.
    expect(niveauPourReste(0)).toBe("LIMITE");
    expect(niveauPourReste(-1)).toBe("DEPASSE");
  });
});

describe("evaluerFarm", () => {
  it("ne suppose jamais 0 partie quand l'information manque", () => {
    expect(evaluerFarm(null, 164)).toEqual({ reste: null, niveau: "A_VERIFIER" });
    expect(evaluerFarm(undefined, 124)).toEqual({
      reste: null,
      niveau: "A_VERIFIER",
    });
  });

  it("traite un joueur sans partie NHL comme largement admissible", () => {
    expect(evaluerFarm(0, 164)).toEqual({ reste: 164, niveau: "OK" });
  });
});

/**
 * Non-régression : valeurs réellement observées le 2026-08-31 par la preuve
 * de concept (reference/farm-status-exemple.csv). Toute dérive de la logique
 * de seuil sera détectée ici.
 *
 * Note : le seuil des gardiens est passé de 124 à 125 le 2026-09-01, à la
 * demande de l'administrateur. Les marges des gardiens sont donc supérieures
 * d'une unité à celles du fichier de référence.
 */
describe("non-régression sur les données réelles du 2026-08-31", () => {
  const cas = [
    { nom: "Justin Brazeau", pos: "F", pj: 159, reste: 5, niveau: "URGENT" },
    { nom: "Joseph Woll", pos: "G", pj: 117, reste: 8, niveau: "CRITIQUE" },
    { nom: "Mavrik Bourque", pos: "F", pj: 156, reste: 8, niveau: "CRITIQUE" },
    { nom: "Joel Hofer", pos: "G", pj: 115, reste: 10, niveau: "CRITIQUE" },
    { nom: "Simon Nemec", pos: "D", pj: 155, reste: 9, niveau: "CRITIQUE" },
    { nom: "Josh Doan", pos: "F", pj: 144, reste: 20, niveau: "SURVEILLER" },
  ] as const;

  for (const c of cas) {
    it(`${c.nom} : ${c.pj} PJ -> ${c.reste} parties restantes`, () => {
      const seuil = seuilPour(c.pos);
      const resultat = evaluerFarm(c.pj, seuil);
      expect(resultat.reste).toBe(c.reste);
      expect(resultat.niveau).toBe(c.niveau);
    });
  }

  it("détecte les anomalies hors-saison en slot farm", () => {
    // John Tavares : 1266 parties, largement au-delà du seuil patineur.
    expect(evaluerFarm(1266, seuilPour("F"))).toEqual({
      reste: -1102,
      niveau: "DEPASSE",
    });
    // Ivan Barbashev : 667 parties.
    expect(evaluerFarm(667, seuilPour("F"))).toEqual({
      reste: -503,
      niveau: "DEPASSE",
    });
  });

  it("Pyotr Kochetkov, 125 PJ, est pile à la limite du seuil gardien", () => {
    // Avec l'ancien seuil de 124, il était dépassé d'une partie.
    // Avec 125, il est exactement à la limite : encore admissible, sans marge.
    expect(evaluerFarm(125, seuilPour("G"))).toEqual({
      reste: 0,
      niveau: "LIMITE",
    });
    // Une partie de plus et il ne l'est plus.
    expect(evaluerFarm(126, seuilPour("G"))).toEqual({
      reste: -1,
      niveau: "DEPASSE",
    });
  });
});

describe("poidsNiveau", () => {
  it("place les cas les plus graves en tête de tri", () => {
    const ordre = [
      "OK",
      "SURVEILLER",
      "DEPASSE",
      "A_VERIFIER",
      "URGENT",
      "LIMITE",
      "CRITIQUE",
    ] as const;
    const trie = [...ordre].sort((a, b) => poidsNiveau(a) - poidsNiveau(b));
    expect(trie).toEqual([
      "DEPASSE",
      "LIMITE",
      "URGENT",
      "CRITIQUE",
      "SURVEILLER",
      "A_VERIFIER",
      "OK",
    ]);
  });
});

describe("messageFacebook", () => {
  it("reprend la formulation demandée pour un avis préventif", () => {
    const message = messageFacebook({
      nom: "Mavrik Bourque",
      partiesJouees: 156,
      seuil: 164,
      reste: 8,
    });
    expect(message).toBe(
      "Salut, avis amical : Mavrik Bourque est à 156/164 parties. " +
        "Il lui reste 8 matchs avant de perdre son admissibilité farm — prévois ton coup.",
    );
  });

  it("accorde le singulier quand il ne reste qu'un match", () => {
    const message = messageFacebook({
      nom: "Test Joueur",
      partiesJouees: 163,
      seuil: 164,
      reste: 1,
    });
    expect(message).toContain("Il lui reste 1 match avant");
  });

  it("bascule sur un message d'urgence quand le seuil est franchi", () => {
    const message = messageFacebook({
      nom: "Pyotr Kochetkov",
      partiesJouees: 126,
      seuil: 125,
      reste: -1,
    });
    expect(message).toContain("126/125 parties");
    expect(message).toContain("n'est plus admissible au farm");
    expect(message).toContain("1 partie de trop");
    expect(message).toContain("retiré du farm immédiatement");
  });

  it("distingue le joueur pile à la limite de celui qui a dépassé", () => {
    const message = messageFacebook({
      nom: "Pyotr Kochetkov",
      partiesJouees: 125,
      seuil: 125,
      reste: 0,
    });
    expect(message).toContain("exactement à la limite");
    expect(message).toContain("encore admissible");
    expect(message).not.toContain("n'est plus admissible");
  });

  it("accorde le pluriel sur un dépassement important", () => {
    const message = messageFacebook({
      nom: "John Tavares",
      partiesJouees: 1266,
      seuil: 164,
      reste: -1102,
    });
    expect(message).toContain("1102 parties de trop");
  });

  it("demande une vérification manuelle si les parties sont inconnues", () => {
    const message = messageFacebook({
      nom: "Joueur Inconnu",
      partiesJouees: null,
      seuil: 164,
      reste: null,
    });
    expect(message).toContain("je n'arrive pas à confirmer");
    expect(message).toContain("164 parties");
  });
});
