/**
 * KeeperVets — interface web.
 *
 * Aucune dépendance ni étape de compilation : le fichier est servi tel quel.
 * Tout contenu provenant des API externes (noms d'équipes saisis par les
 * poolers, notamment) est échappé avant insertion dans le document.
 */

"use strict";

const etat = {
  donnees: null,
  historique: [],
  claims: null,
  admin: null,
  admins: [],
  vue: "blesses",
};

// ---------------------------------------------------------------- Utilitaires

const $ = (selecteur) => document.querySelector(selecteur);
const $$ = (selecteur) => [...document.querySelectorAll(selecteur)];

/** Échappe le HTML : indispensable, les noms d'équipes sont saisis librement. */
function echapper(valeur) {
  if (valeur === null || valeur === undefined) return "";
  return String(valeur)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

async function appelApi(chemin, options = {}) {
  const reponse = await fetch(chemin, {
    headers: { "content-type": "application/json" },
    ...options,
  });
  const donnees = await reponse.json().catch(() => ({}));
  if (!reponse.ok) throw new Error(donnees.erreur || `Erreur HTTP ${reponse.status}`);
  return donnees;
}

let minuteurToast;
function toast(message) {
  const element = $("#toast");
  element.textContent = message;
  element.classList.remove("masque");
  clearTimeout(minuteurToast);
  minuteurToast = setTimeout(() => element.classList.add("masque"), 3200);
}

/** Formate un horodatage ISO en date-heure lisible au Québec. */
function formaterInstant(iso) {
  if (!iso) return "jamais";
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "jamais";
  return date.toLocaleString("fr-CA", {
    timeZone: "America/Toronto",
    dateStyle: "short",
    timeStyle: "short",
  });
}

/** Formate une date « AAAA-MM-JJ » en « 5 nov. 2026 ». */
function formaterDate(date) {
  if (!date) return "—";
  const [a, m, j] = date.split("-").map(Number);
  return new Date(Date.UTC(a, m - 1, j)).toLocaleDateString("fr-CA", {
    timeZone: "UTC",
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

/** Écart en heures entre un horodatage et maintenant. */
function heuresDepuis(iso) {
  if (!iso) return Infinity;
  return (Date.now() - new Date(iso).getTime()) / 3_600_000;
}

const CLASSE_BADGE_IR = {
  BLOQUE: "badge-rouge",
  ELIGIBLE_DEMAIN: "badge-jaune",
  ELIGIBLE: "badge-vert",
  RETOUR_PREMATURE: "badge-orange",
};

const CLASSE_BADGE_FARM = {
  DEPASSE: "badge-rouge",
  LIMITE: "badge-rouge",
  URGENT: "badge-rouge",
  CRITIQUE: "badge-orange",
  SURVEILLER: "badge-jaune",
  A_VERIFIER: "badge-gris",
  OK: "badge-vert",
};

// ------------------------------------------------------------------ Chargement

async function charger() {
  try {
    etat.donnees = await appelApi("/api/tableau-de-bord");
    etat.admin = etat.donnees.admin;
    dessinerTout();
  } catch (e) {
    // L'application ne doit jamais rester muette : on affiche l'incident
    // tout en conservant à l'écran les dernières données déjà chargées.
    afficherBandeau(
      `Impossible de joindre le serveur : ${echapper(e.message)}. Les données affichées peuvent être périmées.`,
      true,
    );
  }
}

async function chargerSession() {
  try {
    const session = await appelApi("/api/session");
    etat.admin = session.admin;
    etat.admins = session.admins || [];
    dessinerSession();
  } catch {
    /* La vue publique reste utilisable même si la session est indisponible. */
  }
}

// -------------------------------------------------------------------- Rendu

function dessinerTout() {
  dessinerSession();
  dessinerFraicheur();
  dessinerBandeau();
  dessinerCompteurs();
  dessinerBlesses();
  dessinerFarm();
  dessinerAnomalies();
}

function dessinerSession() {
  const zone = $("#zone-session");
  if (etat.admin) {
    zone.innerHTML =
      `<span class="doux">Connecté : <strong>${echapper(etat.admin)}</strong></span> ` +
      `<button class="bouton-mini" id="btn-deconnexion">Se déconnecter</button>`;
    $("#btn-deconnexion").addEventListener("click", deconnecter);
    $("#btn-rafraichir").classList.remove("masque");
    $("#admin-verrouille").classList.add("masque");
    $("#admin-contenu").classList.remove("masque");
    if (etat.vue === "admin") chargerAdmin();
    if (etat.vue === "claims") dessinerClaims();
  } else {
    zone.innerHTML = `<button class="bouton" id="btn-connexion">Connexion admin</button>`;
    $("#btn-connexion").addEventListener("click", ouvrirConnexion);
    $("#btn-rafraichir").classList.add("masque");
    $("#admin-verrouille").classList.remove("masque");
    $("#admin-contenu").classList.add("masque");
  }
}

function dessinerFraicheur() {
  const meta = etat.donnees?.meta;
  if (!meta) return;

  const fantrax = meta.dernierSuccesFantrax;
  const lnh = meta.dernierSuccesNhl;

  // Les deux sources sont lues dans la même exécution : leurs horodatages sont
  // normalement identiques. On n'affiche donc qu'une seule date, celle de la
  // lecture la plus ancienne — c'est elle qui reflète la fraîcheur réelle.
  const connues = [fantrax, lnh].filter(Boolean);
  const reference = connues.length
    ? connues.reduce((a, b) => (Date.parse(a) < Date.parse(b) ? a : b))
    : null;

  const age = heuresDepuis(reference);
  const classe = !reference ? "echec" : age > 5 ? "perime" : "";

  let html = `<div class="${classe}">Mise à jour : ${echapper(formaterInstant(reference))}</div>`;

  // Le détail par source n'apparaît que si l'une d'elles a décroché : c'est
  // précisément le cas où savoir laquelle est utile.
  const ecart =
    fantrax && lnh ? Math.abs(Date.parse(fantrax) - Date.parse(lnh)) : 0;
  if (!fantrax || !lnh || ecart > 3_600_000) {
    html +=
      `<div class="perime">` +
      `Fantrax ${echapper(formaterInstant(fantrax))} · ` +
      `LNH ${echapper(formaterInstant(lnh))}</div>`;
  }

  if (meta.periodeCourante) {
    html +=
      `<div>Période ${meta.periodeCourante.numero}/${meta.nbPeriodes}` +
      ` — début ${echapper(formaterDate(meta.periodeCourante.dateDebut))}` +
      (meta.periodeCourante.aVenir ? " <em>(à venir)</em>" : "") +
      `</div>`;
  }

  $("#fraicheur").innerHTML = html;
}

function afficherBandeau(html, grave) {
  const bandeau = $("#bandeau-alerte");
  bandeau.innerHTML = html;
  bandeau.classList.toggle("grave", Boolean(grave));
  bandeau.classList.remove("masque");
}

function dessinerBandeau() {
  const meta = etat.donnees?.meta;
  const messages = [];
  let grave = false;

  const nonClasses = meta?.statutsNonClasses ?? [];
  if (nonClasses.length > 0) {
    const liste = nonClasses.map((s) => `<code>${echapper(s.statut)}</code>`).join(", ");
    messages.push(
      `Statut${nonClasses.length > 1 ? "s" : ""} Fantrax non classé${nonClasses.length > 1 ? "s" : ""} : ${liste}. ` +
        `Va dans <strong>Administration</strong> pour indiquer s'il s'agit du statut de blessé — ` +
        `sans quoi l'horloge des 10 jours ne démarrera pas.`,
    );
    grave = true;
  }

  const derniere = meta?.derniereExecutionDetail;
  if (derniere && !derniere.fantraxOk) {
    messages.push(
      `La dernière lecture Fantrax a échoué (${echapper(derniere.erreur || "cause inconnue")}). ` +
        `Les données ci-dessous sont les dernières connues.`,
    );
    grave = true;
  } else if (heuresDepuis(meta?.dernierSuccesFantrax) > 5) {
    messages.push(
      `Aucune lecture Fantrax réussie depuis plus de 5 heures. Les données peuvent être périmées.`,
    );
  }

  const retours = etat.donnees?.resume?.retoursPrematures ?? 0;
  if (retours > 0) {
    messages.push(
      `⚠️ ${retours} retour${retours > 1 ? "s" : ""} prématuré${retours > 1 ? "s" : ""} détecté${retours > 1 ? "s" : ""} : ` +
        `un joueur a été réactivé avant d'avoir purgé ses 10 jours.`,
    );
    grave = true;
  }

  if (messages.length === 0) {
    $("#bandeau-alerte").classList.add("masque");
  } else {
    afficherBandeau(messages.map((m) => `<div>${m}</div>`).join(""), grave);
  }
}

function dessinerCompteurs() {
  const r = etat.donnees?.resume;
  if (!r) return;
  const majPastille = (id, valeur) => {
    const element = $(id);
    element.textContent = valeur;
    element.classList.toggle("zero", valeur === 0);
  };
  majPastille("#cpt-blesses", r.blessesOuverts);
  majPastille("#cpt-farm", r.farmTotal);
  majPastille("#cpt-anomalies", r.farmDepasses);

  $("#resume-blesses").innerHTML = [
    carte(r.blessesOuverts, "sur la liste des blessés", ""),
    carte(r.eligiblesMaintenant, "éligibles maintenant", "vert"),
    carte(r.retoursPrematures, "retours prématurés", r.retoursPrematures > 0 ? "rouge" : ""),
  ].join("");

  $("#resume-farm").innerHTML = [
    carte(r.farmTotal, "joueurs en slot farm", ""),
    carte(r.farmAlertes, "à surveiller (≤ 30 parties)", r.farmAlertes > 0 ? "jaune" : ""),
    carte(r.farmDepasses, "non admissibles", r.farmDepasses > 0 ? "rouge" : ""),
    carte(r.farmAVerifier, "à vérifier manuellement", ""),
  ].join("");
}

function carte(valeur, etiquette, classe) {
  return `<div class="carte ${classe}"><div class="valeur">${valeur}</div><div class="etiquette">${echapper(etiquette)}</div></div>`;
}

// ------------------------------------------------------------------ Blessés

function dessinerBlesses() {
  const filtre = $("#filtre-blesses").value.trim().toLowerCase();
  const seulementEligibles = $("#filtre-eligibles").checked;

  const lignes = (etat.donnees?.blesses ?? []).filter((b) => {
    if (seulementEligibles && b.statut !== "ELIGIBLE") return false;
    if (!filtre) return true;
    return `${b.nom} ${b.equipePool}`.toLowerCase().includes(filtre);
  });

  const corps = $("#table-blesses tbody");
  corps.innerHTML = lignes.map(ligneBlesse).join("");
  $("#vide-blesses").classList.toggle("masque", lignes.length > 0);
  $("#table-blesses").classList.toggle("masque", lignes.length === 0);

  corps.querySelectorAll("[data-corriger]").forEach((bouton) => {
    bouton.addEventListener("click", () => ouvrirCorrectionDate(bouton.dataset.corriger));
  });
}

function ligneBlesse(b) {
  const pourcentage = Math.round((b.jourCourant / 10) * 100);
  const classeJauge = b.jourCourant >= 10 ? "pleine" : b.jourCourant >= 9 ? "presque" : "";
  const boutonAdmin = etat.admin
    ? `<button class="bouton-mini" data-corriger="${b.id}">Corriger la date</button>`
    : "";
  const marqueCorrection = b.dateIrModifiee
    ? `<div class="doux" title="Date corrigée par ${echapper(b.corrigePar || "un admin")}">✎ corrigée (détectée le ${echapper(formaterDate(b.dateIrDetectee))})</div>`
    : b.periodeIr
      ? `<div class="doux" title="La date retenue est celle du début de la période Fantrax">période ${b.periodeIr}</div>`
      : "";
  const infraction =
    b.retourPremature && b.joursManquants
      ? `<div class="doux">${b.joursManquants} jour${b.joursManquants > 1 ? "s" : ""} écourté${b.joursManquants > 1 ? "s" : ""}</div>`
      : "";

  return `<tr>
    <td><span class="badge ${CLASSE_BADGE_IR[b.statut] || "badge-gris"}">${echapper(b.libelleStatut)}</span>${infraction}</td>
    <td>${echapper(b.equipePool)}</td>
    <td class="joueur">${echapper(b.nom)}${b.position ? ` <span class="doux">${echapper(b.position)}</span>` : ""}</td>
    <td>${echapper(formaterDate(b.dateIr))}${marqueCorrection}</td>
    <td>
      <div class="progression">
        <div class="jauge ${classeJauge}"><span style="width:${pourcentage}%"></span></div>
        <span class="jours">${b.jourCourant}/10</span>
      </div>
    </td>
    <td>${echapper(formaterDate(b.dateEligibilite))}${b.ouvert && b.joursRestants > 0 ? `<div class="doux">dans ${b.joursRestants} j</div>` : ""}</td>
    <td>${boutonAdmin}</td>
  </tr>`;
}

// --------------------------------------------------------------------- Farm

function dessinerFarm() {
  const filtre = $("#filtre-farm").value.trim().toLowerCase();
  const seulementAlertes = $("#filtre-alertes").checked;

  const lignes = (etat.donnees?.farm ?? []).filter((f) => {
    if (seulementAlertes && !f.estAlerte) return false;
    if (!filtre) return true;
    return `${f.nom} ${f.equipePool}`.toLowerCase().includes(filtre);
  });

  const corps = $("#table-farm tbody");
  corps.innerHTML = lignes.map((f) => ligneFarm(f, false)).join("");
  $("#vide-farm").classList.toggle("masque", lignes.length > 0);
  $("#table-farm").classList.toggle("masque", lignes.length === 0);
  brancherBoutonsCopie(corps);
}

function dessinerAnomalies() {
  const lignes = etat.donnees?.anomalies ?? [];
  const corps = $("#table-anomalies tbody");
  corps.innerHTML = lignes.map((f) => ligneFarm(f, true)).join("");
  $("#vide-anomalies").classList.toggle("masque", lignes.length > 0);
  $("#table-anomalies").classList.toggle("masque", lignes.length === 0);
  brancherBoutonsCopie(corps);
}

function ligneFarm(f, estAnomalie) {
  const pj = f.partiesJouees === null ? "—" : f.partiesJouees;
  const reste = f.reste === null ? "—" : f.reste;
  const depassement = f.reste === null ? "—" : `+${Math.abs(f.reste)}`;
  const source =
    f.sourceAppariement === "records"
      ? `<div class="doux" title="Apparié via les archives de la LNH">via archives</div>`
      : f.nhlPlayerId === null
        ? `<div class="doux">non apparié</div>`
        : "";

  const colonnes = estAnomalie
    ? `<td class="num">${pj}</td><td class="num doux">${f.seuil}</td><td class="num"><strong>${depassement}</strong></td>`
    : `<td class="num">${pj}</td><td class="num doux">${f.seuil}</td><td class="num"><strong>${reste}</strong></td>`;

  const badge = estAnomalie
    ? ""
    : `<td><span class="badge ${CLASSE_BADGE_FARM[f.niveau] || "badge-gris"}">${echapper(f.libelleNiveau)}</span></td>`;

  return `<tr>
    ${badge}
    <td>${echapper(f.equipePool)}</td>
    <td class="joueur">${echapper(f.nom)}${source}</td>
    <td class="doux">${echapper(f.equipeNhl || "—")}</td>
    <td class="doux">${echapper(f.position || "—")}</td>
    ${colonnes}
    <td><button class="bouton-mini" data-copier="${echapper(f.message)}">📋 Copier le message</button></td>
  </tr>`;
}

function brancherBoutonsCopie(racine) {
  racine.querySelectorAll("[data-copier]").forEach((bouton) => {
    bouton.addEventListener("click", async () => {
      const texte = bouton.dataset.copier;
      try {
        await navigator.clipboard.writeText(texte);
        toast("Message copié — prêt à coller sur Facebook.");
      } catch {
        // Le presse-papiers peut être refusé : on offre une solution de repli.
        window.prompt("Copie ce message :", texte);
      }
    });
  });
}

// --------------------------------------------------------------------- Claims

const CLASSE_BADGE_CLAIMS = {
  NON_DOTE: "badge-gris",
  NEGATIF: "badge-rouge",
  EPUISE: "badge-rouge",
  DERNIER: "badge-orange",
  FAIBLE: "badge-jaune",
  OK: "badge-vert",
};

async function chargerClaims() {
  try {
    etat.claims = await appelApi("/api/claims");
    dessinerClaims();
  } catch (e) {
    toast(`Claims indisponibles : ${e.message}`);
  }
}

function dessinerClaims() {
  const donnees = etat.claims;
  const equipes = donnees?.equipes ?? [];
  const mouvements = donnees?.mouvements ?? [];

  // Avant l'ouverture, le tableau est volontairement vide : le repêchage fait
  // entrer beaucoup de joueurs et aucun d'eux ne consomme de claim.
  const explication = donnees?.saisonOuverte
    ? `<strong>Chaque équipe reçoit 4 claims au début de la saison</strong>, et les claims
       s'échangent entre poolers — un solde peut donc dépasser 4 ou passer sous zéro.
       Le robot décompte automatiquement un claim lorsqu'une équipe fait entrer un joueur
       venu de l'extérieur du pool ; un échange entre deux poolers ne consomme rien.
       Les échanges de claims, eux, se saisissent ici.`
    : `<strong>Le suivi des claims démarre le ${echapper(formaterDate(donnees?.debutSaison))}.</strong>
       Jusque-là, rien n'est doté ni décompté : le repêchage fait entrer beaucoup de
       nouveaux joueurs, et aucun d'eux ne doit consommer de claim.
       À l'ouverture, le robot donnera automatiquement 4 claims à chacune des
       ${donnees?.nbEquipes ?? 13} équipes. Tu pourras ensuite saisir ici les échanges déjà
       conclus entre poolers.`;

  $("#claims-explication").innerHTML = explication;
  // Les actions ne s'ouvrent qu'une fois la saison commencée : saisir un
  // échange avant le repêchage n'aurait aucun sens.
  $("#claims-actions").classList.toggle(
    "masque",
    !etat.admin || !donnees?.saisonOuverte,
  );

  $("#table-claims tbody").innerHTML = equipes
    .map(
      (c) => `<tr>
        <td><span class="badge ${CLASSE_BADGE_CLAIMS[c.niveau] || "badge-gris"}">${echapper(c.libelleNiveau)}</span></td>
        <td>${echapper(c.equipe)}</td>
        <td class="num"><strong>${c.solde}</strong></td>
        <td class="num doux">${c.alloues}</td>
        <td class="num doux">${c.utilises}</td>
        <td class="num doux">${c.recus || ""}</td>
        <td class="num doux">${c.cedes || ""}</td>
        <td class="num doux">${c.corrections || ""}</td>
        <td><button class="bouton-mini" data-copier="${echapper(c.message)}">📋 Copier</button></td>
      </tr>`,
    )
    .join("");

  const vide = equipes.length === 0;
  $("#vide-claims").classList.toggle("masque", !vide);
  $("#table-claims").classList.toggle("masque", vide);
  brancherBoutonsCopie($("#table-claims tbody"));

  // La pastille de l'onglet reste discrète tant que la saison n'a pas commencé.
  const total = equipes.reduce((somme, c) => somme + c.solde, 0);
  const pastille = $("#cpt-claims");
  pastille.textContent = donnees?.saisonOuverte ? total : "—";
  pastille.classList.toggle("zero", !donnees?.saisonOuverte || total === 0);

  $("#table-claims-mouvements tbody").innerHTML = mouvements
    .map(
      (m) => `<tr>
        <td class="doux">${echapper(m.date_effet)}</td>
        <td>${echapper(m.equipe)}</td>
        <td>${echapper(libelleTypeMouvement(m.type))}${m.contrepartie ? ` <span class="doux">(${echapper(m.contrepartie)})</span>` : ""}</td>
        <td class="num"><strong>${m.quantite > 0 ? "+" : ""}${m.quantite}</strong></td>
        <td class="doux">${echapper(m.motif || "")}</td>
        <td class="doux">${echapper(m.auteur)}</td>
        <td>${etat.admin ? `<button class="bouton-mini" data-supprimer-claim="${m.id}">Supprimer</button>` : ""}</td>
      </tr>`,
    )
    .join("");

  const videMouv = mouvements.length === 0;
  $("#vide-claims-mouvements").classList.toggle("masque", !videMouv);
  $("#table-claims-mouvements").classList.toggle("masque", videMouv);

  $$("#table-claims-mouvements [data-supprimer-claim]").forEach((bouton) => {
    bouton.addEventListener("click", () => supprimerMouvementClaim(bouton.dataset.supprimerClaim));
  });
}

function libelleTypeMouvement(type) {
  switch (type) {
    case "ALLOCATION": return "Dotation";
    case "UTILISE": return "Claim utilisé";
    case "RECU": return "Reçu de";
    case "CEDE": return "Cédé à";
    case "CORRECTION": return "Ajustement";
    default: return type;
  }
}

function remplirSelectEquipes(selecteur) {
  const options = (etat.claims?.equipes ?? [])
    .slice()
    .sort((a, b) => a.equipe.localeCompare(b.equipe, "fr"))
    .map((c) => `<option value="${echapper(c.teamId)}">${echapper(c.equipe)} (${c.solde})</option>`)
    .join("");
  $(selecteur).innerHTML = options;
}

function ouvrirEchangeClaims() {
  remplirSelectEquipes("#claims-de");
  remplirSelectEquipes("#claims-vers");
  $("#claims-quantite").value = 1;
  $("#claims-motif").value = "";
  $("#erreur-echange-claims").classList.add("masque");
  $("#dlg-echange-claims").showModal();
}

async function enregistrerEchangeClaims(evenement) {
  evenement.preventDefault();
  const erreur = $("#erreur-echange-claims");
  try {
    await appelApi("/api/claims/echange", {
      method: "POST",
      body: JSON.stringify({
        deTeamId: $("#claims-de").value,
        versTeamId: $("#claims-vers").value,
        quantite: Number($("#claims-quantite").value),
        motif: $("#claims-motif").value,
      }),
    });
    $("#dlg-echange-claims").close();
    await chargerClaims();
    toast("Échange de claims enregistré.");
  } catch (e) {
    erreur.textContent = e.message;
    erreur.classList.remove("masque");
  }
}

function ouvrirAjustementClaims() {
  remplirSelectEquipes("#ajust-equipe");
  $("#ajust-quantite").value = 1;
  $("#ajust-motif").value = "";
  $("#erreur-ajustement-claims").classList.add("masque");
  $("#dlg-ajustement-claims").showModal();
}

async function enregistrerAjustementClaims(evenement) {
  evenement.preventDefault();
  const erreur = $("#erreur-ajustement-claims");
  try {
    await appelApi("/api/claims/ajustement", {
      method: "POST",
      body: JSON.stringify({
        teamId: $("#ajust-equipe").value,
        quantite: Number($("#ajust-quantite").value),
        motif: $("#ajust-motif").value,
      }),
    });
    $("#dlg-ajustement-claims").close();
    await chargerClaims();
    toast("Solde ajusté.");
  } catch (e) {
    erreur.textContent = e.message;
    erreur.classList.remove("masque");
  }
}

async function supprimerMouvementClaim(id) {
  if (!window.confirm("Supprimer ce mouvement ? Le solde sera recalculé.")) return;
  try {
    await appelApi(`/api/claims/mouvement/${id}`, { method: "DELETE" });
    await chargerClaims();
    toast("Mouvement supprimé.");
  } catch (e) {
    toast(`Échec : ${e.message}`);
  }
}

// --------------------------------------------------------------- Historique

async function chargerHistorique() {
  try {
    etat.historique = await appelApi("/api/blesses?historique=1");
    dessinerHistorique();
  } catch (e) {
    toast(`Historique indisponible : ${e.message}`);
  }
}

function dessinerHistorique() {
  const filtre = $("#filtre-historique").value.trim().toLowerCase();
  const lignes = etat.historique.filter(
    (b) => !filtre || `${b.nom} ${b.equipePool}`.toLowerCase().includes(filtre),
  );

  $("#table-historique tbody").innerHTML = lignes
    .map((b) => {
      const duree = b.dateRetour
        ? Math.round(
            (Date.parse(`${b.dateRetour}T00:00:00Z`) - Date.parse(`${b.dateIr}T00:00:00Z`)) /
              86_400_000,
          )
        : null;
      const etiquetteDuree =
        duree === null
          ? `<span class="doux">en cours</span>`
          : `${duree} jour${duree > 1 ? "s" : ""}`;
      return `<tr>
        <td><span class="badge ${CLASSE_BADGE_IR[b.statut] || "badge-gris"}">${echapper(b.libelleStatut)}</span></td>
        <td>${echapper(b.equipePool)}</td>
        <td class="joueur">${echapper(b.nom)}</td>
        <td>${echapper(formaterDate(b.dateIr))}</td>
        <td>${echapper(formaterDate(b.dateRetour))}</td>
        <td>${etiquetteDuree}</td>
        <td class="doux">${echapper(b.note || "")}</td>
      </tr>`;
    })
    .join("");

  $("#vide-historique").classList.toggle("masque", lignes.length > 0);
  $("#table-historique").classList.toggle("masque", lignes.length === 0);
}

// ------------------------------------------------------------ Administration

async function chargerAdmin() {
  if (!etat.admin) return;
  try {
    const [statuts, executions, journal] = await Promise.all([
      appelApi("/api/statuts"),
      appelApi("/api/executions"),
      appelApi("/api/journal"),
    ]);

    $("#table-statuts tbody").innerHTML = statuts
      .map(
        (s) => `<tr>
          <td><code>${echapper(s.statut_brut)}</code></td>
          <td>
            <select class="champ" data-statut="${echapper(s.statut_brut)}" style="min-width:150px">
              ${["ACTIF", "FARM", "IR", "INCONNU"]
                .map(
                  (t) =>
                    `<option value="${t}"${t === s.type ? " selected" : ""}>${t}</option>`,
                )
                .join("")}
            </select>
          </td>
          <td class="num">${s.nb_observations}</td>
          <td class="doux">${echapper(formaterInstant(s.derniere_vue))}</td>
          <td>${s.type === "INCONNU" ? '<span class="badge badge-jaune">à classer</span>' : ""}</td>
        </tr>`,
      )
      .join("");

    $$("#table-statuts select").forEach((select) => {
      select.addEventListener("change", () => enregistrerStatut(select.dataset.statut, select.value));
    });

    $("#table-executions tbody").innerHTML = executions
      .map(
        (e) => `<tr>
          <td class="doux">${echapper(formaterInstant(e.termine_le))}</td>
          <td>${echapper(e.declencheur)}${e.complet ? ' <span class="doux">(complet)</span>' : ""}</td>
          <td>${e.succes ? '<span class="badge badge-vert">succès</span>' : '<span class="badge badge-rouge">échec</span>'}</td>
          <td class="num">${e.joueurs_vus}</td>
          <td class="num">${e.ir_ouverts} / ${e.ir_fermes}</td>
          <td class="num">${e.pj_rafraichies}</td>
          <td class="doux">${echapper(e.erreur || "")}</td>
        </tr>`,
      )
      .join("");

    $("#table-journal tbody").innerHTML = journal
      .map(
        (j) => `<tr>
          <td class="doux">${echapper(formaterInstant(j.le))}</td>
          <td><strong>${echapper(j.admin)}</strong></td>
          <td>${echapper(j.action)}</td>
          <td class="doux">${echapper(j.cible || "")} ${echapper(j.cible_id || "")}</td>
          <td class="doux">${echapper(j.details || "")}</td>
        </tr>`,
      )
      .join("");
  } catch (e) {
    toast(`Section administration indisponible : ${e.message}`);
  }
}

async function enregistrerStatut(statutBrut, type) {
  try {
    await appelApi("/api/statuts", {
      method: "POST",
      body: JSON.stringify({ statutBrut, type }),
    });
    toast(`Statut ${statutBrut} classé comme ${type}.`);
    await charger();
    await chargerAdmin();
  } catch (e) {
    toast(`Échec : ${e.message}`);
  }
}

// -------------------------------------------------------------- Connexion

function ouvrirConnexion() {
  const choix = $("#choix-admin");
  choix.innerHTML = etat.admins
    .map((a) => `<option value="${echapper(a)}">${echapper(a)}</option>`)
    .join("");
  $("#erreur-connexion").classList.add("masque");
  $("#mot-de-passe").value = "";
  $("#dlg-connexion").showModal();
}

async function connecter(evenement) {
  evenement.preventDefault();
  const erreur = $("#erreur-connexion");
  try {
    await appelApi("/api/connexion", {
      method: "POST",
      body: JSON.stringify({
        admin: $("#choix-admin").value,
        motDePasse: $("#mot-de-passe").value,
      }),
    });
    $("#dlg-connexion").close();
    await chargerSession();
    await charger();
    toast("Connexion réussie.");
  } catch (e) {
    erreur.textContent = e.message;
    erreur.classList.remove("masque");
  }
}

async function deconnecter() {
  await appelApi("/api/deconnexion", { method: "POST" }).catch(() => {});
  etat.admin = null;
  await charger();
  toast("Déconnexion effectuée.");
}

// ------------------------------------------------- Correction de la date IR

let sejourEnCours = null;

function ouvrirCorrectionDate(id) {
  const sejour = (etat.donnees?.blesses ?? []).find((b) => String(b.id) === String(id));
  if (!sejour) return;
  sejourEnCours = sejour;

  $("#date-ir-contexte").innerHTML =
    `<strong>${echapper(sejour.nom)}</strong> — ${echapper(sejour.equipePool)}<br>` +
    (sejour.periodeIr
      ? `Date retenue : début de la <strong>période ${sejour.periodeIr}</strong> ` +
        `(${echapper(formaterDate(sejour.dateIrDetectee))}), conformément à la règle de la ligue.`
      : `Date détectée par le robot : ${echapper(formaterDate(sejour.dateIrDetectee))}. ` +
        `Le robot s'exécute aux 2 heures : la date réelle peut être antérieure.`);

  $("#champ-date-ir").value = sejour.dateIr;
  $("#champ-date-ir").max = "";
  $("#champ-note").value = sejour.note || "";
  $("#erreur-date-ir").classList.add("masque");
  majApercuEligibilite();
  $("#dlg-date-ir").showModal();
}

function majApercuEligibilite() {
  const valeur = $("#champ-date-ir").value;
  if (!/^\d{4}-\d{2}-\d{2}$/.test(valeur)) {
    $("#apercu-eligibilite").textContent = "";
    return;
  }
  const [a, m, j] = valeur.split("-").map(Number);
  const eligible = new Date(Date.UTC(a, m - 1, j + 10)).toISOString().slice(0, 10);
  $("#apercu-eligibilite").textContent = `Nouvelle date d'éligibilité : ${formaterDate(eligible)}.`;
}

async function enregistrerDateIr(evenement) {
  evenement.preventDefault();
  const erreur = $("#erreur-date-ir");
  try {
    await appelApi(`/api/blesses/${sejourEnCours.id}/date-ir`, {
      method: "POST",
      body: JSON.stringify({
        dateIr: $("#champ-date-ir").value,
        note: $("#champ-note").value,
      }),
    });
    $("#dlg-date-ir").close();
    await charger();
    if (etat.vue === "historique") await chargerHistorique();
    toast("Date de mise sur IR corrigée.");
  } catch (e) {
    erreur.textContent = e.message;
    erreur.classList.remove("masque");
  }
}

// ------------------------------------------------------------------ Robot

async function lancerRobot() {
  const bouton = $("#btn-rafraichir");
  bouton.disabled = true;
  bouton.textContent = "⏳ Exécution…";
  try {
    const bilan = await appelApi("/api/robot/executer", { method: "POST" });
    await charger();
    if (etat.vue === "admin") await chargerAdmin();
    if (etat.vue === "claims") await chargerClaims();
    toast(
      bilan.succes
        ? `Robot terminé : ${bilan.joueursVus} joueurs lus, ${bilan.pjRafraichies} fiches NHL rafraîchies` +
          (bilan.claimsUtilises ? `, ${bilan.claimsUtilises} claim(s) décompté(s)` : "") +
          `.`
        : `Robot terminé avec un incident : ${bilan.erreur || "voir Administration"}.`,
    );
  } catch (e) {
    toast(`Échec du robot : ${e.message}`);
  } finally {
    bouton.disabled = false;
    bouton.textContent = "↻ Lancer le robot";
  }
}

// ------------------------------------------------------------------ Onglets

function changerVue(nom) {
  etat.vue = nom;
  $$(".onglet").forEach((o) => o.classList.toggle("actif", o.dataset.vue === nom));
  $$(".vue").forEach((v) => v.classList.toggle("masque", v.id !== `vue-${nom}`));
  if (nom === "historique") chargerHistorique();
  if (nom === "claims") chargerClaims();
  if (nom === "admin") chargerAdmin();
}

// -------------------------------------------------------------- Démarrage

function brancherEvenements() {
  $$(".onglet").forEach((onglet) => {
    onglet.addEventListener("click", () => changerVue(onglet.dataset.vue));
  });

  $("#filtre-blesses").addEventListener("input", dessinerBlesses);
  $("#filtre-eligibles").addEventListener("change", dessinerBlesses);
  $("#filtre-farm").addEventListener("input", dessinerFarm);
  $("#filtre-alertes").addEventListener("change", dessinerFarm);
  $("#filtre-historique").addEventListener("input", dessinerHistorique);

  $("#form-connexion").addEventListener("submit", connecter);
  $("#annuler-connexion").addEventListener("click", () => $("#dlg-connexion").close());

  $("#form-date-ir").addEventListener("submit", enregistrerDateIr);
  $("#annuler-date-ir").addEventListener("click", () => $("#dlg-date-ir").close());
  $("#champ-date-ir").addEventListener("input", majApercuEligibilite);

  $("#btn-rafraichir").addEventListener("click", lancerRobot);

  $("#btn-echange-claims").addEventListener("click", ouvrirEchangeClaims);
  $("#form-echange-claims").addEventListener("submit", enregistrerEchangeClaims);
  $("#annuler-echange-claims").addEventListener("click", () => $("#dlg-echange-claims").close());

  $("#btn-ajustement-claims").addEventListener("click", ouvrirAjustementClaims);
  $("#form-ajustement-claims").addEventListener("submit", enregistrerAjustementClaims);
  $("#annuler-ajustement-claims").addEventListener("click", () => $("#dlg-ajustement-claims").close());
}

async function demarrer() {
  brancherEvenements();
  await chargerSession();
  await charger();
  // Rafraîchissement passif : le robot travaille en arrière-plan.
  setInterval(charger, 5 * 60 * 1000);
}

demarrer();
