/**
 * Routage de l'API.
 *
 * Les routes de lecture sont publiques (vue des poolers).
 * Les routes d'écriture exigent une session administrateur et sont journalisées.
 */

import { listeAdmins, type Env } from "../config.js";
import { Repo } from "../db/repo.js";
import { validerEchange } from "../domain/claims.js";
import { calculerEligibilite, dateDuJour, evaluerRetour } from "../domain/ir.js";
import { periodePourInstant } from "../domain/periodes.js";
import type { TypeStatut } from "../domain/types.js";
import { executerRobot } from "../robot/synchroniser.js";
import {
  comparerConstant,
  cookieFermeture,
  cookieOuverture,
  creerJeton,
  sessionCourante,
} from "./auth.js";
import { construireBlesses, construireClaims, construireFarm, construireMeta } from "./vues.js";

const TYPES_VALIDES: TypeStatut[] = ["ACTIF", "FARM", "IR", "INCONNU"];
const FORMAT_DATE = /^\d{4}-\d{2}-\d{2}$/;

function json(donnees: unknown, statut = 200, entetes: HeadersInit = {}): Response {
  return new Response(JSON.stringify(donnees), {
    status: statut,
    headers: { "content-type": "application/json; charset=utf-8", ...entetes },
  });
}

function erreur(message: string, statut = 400): Response {
  return json({ erreur: message }, statut);
}

export async function router(
  requete: Request,
  env: Env,
  ctx: ExecutionContext,
): Promise<Response> {
  const url = new URL(requete.url);
  const chemin = url.pathname;
  const methode = requete.method.toUpperCase();
  const repo = new Repo(env.DB);
  const maintenant = new Date().toISOString();

  // -------------------------------------------------------------------------
  // Session
  // -------------------------------------------------------------------------

  if (chemin === "/api/session" && methode === "GET") {
    const session = await sessionCourante(requete, env);
    return json({
      connecte: session !== null,
      admin: session?.admin ?? null,
      admins: listeAdmins(env),
    });
  }

  if (chemin === "/api/connexion" && methode === "POST") {
    const corps = (await requete.json().catch(() => null)) as {
      admin?: string;
      motDePasse?: string;
    } | null;

    const admin = corps?.admin?.trim() ?? "";
    // Les espaces et retours de ligne en bordure sont retirés des deux côtés :
    // « wrangler secret put » et les copier-coller en ajoutent facilement, et
    // un tel caractère invisible rendrait le mot de passe impossible à deviner.
    const motDePasse = (corps?.motDePasse ?? "").trim();

    if (!listeAdmins(env).includes(admin)) {
      return erreur("Administrateur inconnu.", 401);
    }
    if (!env.ADMIN_PASSWORD) {
      // En local, le mot de passe vient de .dev.vars ; en production, d'un
      // secret Cloudflare. Les deux sont indépendants, d'où ce message précis.
      return erreur(
        "Le mot de passe administrateur n'est pas configuré sur ce serveur. " +
          "En local : renseigner ADMIN_PASSWORD dans .dev.vars. " +
          "En ligne : exécuter « npx wrangler secret put ADMIN_PASSWORD ».",
        500,
      );
    }
    if (!env.SESSION_SECRET) {
      return erreur(
        "La clé de signature des sessions n'est pas configurée sur ce serveur. " +
          "En local : renseigner SESSION_SECRET dans .dev.vars. " +
          "En ligne : exécuter « npx wrangler secret put SESSION_SECRET ».",
        500,
      );
    }
    if (!comparerConstant(motDePasse, env.ADMIN_PASSWORD.trim())) {
      // On journalise l'échec sans révéler la saisie.
      await repo.journaliser({
        admin,
        action: "connexion-refusee",
        maintenant,
      });
      return erreur("Mot de passe incorrect.", 401);
    }

    const jeton = await creerJeton(admin, env.SESSION_SECRET);
    await repo.journaliser({ admin, action: "connexion", maintenant });

    return json(
      { connecte: true, admin },
      200,
      { "set-cookie": cookieOuverture(jeton, url.protocol === "https:") },
    );
  }

  if (chemin === "/api/deconnexion" && methode === "POST") {
    const session = await sessionCourante(requete, env);
    if (session) {
      await repo.journaliser({
        admin: session.admin,
        action: "deconnexion",
        maintenant,
      });
    }
    return json({ connecte: false }, 200, { "set-cookie": cookieFermeture() });
  }

  // -------------------------------------------------------------------------
  // Lecture publique
  // -------------------------------------------------------------------------

  if (chemin === "/api/tableau-de-bord" && methode === "GET") {
    const [blesses, farm, meta] = await Promise.all([
      construireBlesses(repo, env),
      construireFarm(repo),
      construireMeta(repo, env),
    ]);
    const session = await sessionCourante(requete, env);

    return json({
      meta,
      admin: session?.admin ?? null,
      blesses,
      farm: farm.filter((f) => f.niveau !== "DEPASSE"),
      // Un joueur non admissible occupant un slot farm est une anomalie :
      // en saison c'est une infraction, hors-saison c'est fréquent et normal.
      anomalies: farm.filter((f) => f.niveau === "DEPASSE"),
      resume: {
        blessesOuverts: blesses.filter((b) => b.ouvert).length,
        retoursPrematures: blesses.filter((b) => b.retourPremature).length,
        eligiblesMaintenant: blesses.filter(
          (b) => b.ouvert && b.statut === "ELIGIBLE",
        ).length,
        farmTotal: farm.length,
        farmAlertes: farm.filter((f) => f.estAlerte && f.niveau !== "DEPASSE")
          .length,
        farmDepasses: farm.filter((f) => f.niveau === "DEPASSE").length,
        farmAVerifier: farm.filter((f) => f.niveau === "A_VERIFIER").length,
      },
    });
  }

  if (chemin === "/api/blesses" && methode === "GET") {
    const historique = url.searchParams.get("historique") === "1";
    return json(await construireBlesses(repo, env, { historique }));
  }

  if (chemin === "/api/farm" && methode === "GET") {
    return json(await construireFarm(repo));
  }

  if (chemin === "/api/equipes" && methode === "GET") {
    return json(await repo.listerEquipes());
  }

  if (chemin === "/api/statuts" && methode === "GET") {
    return json(await repo.listerMapping());
  }

  if (chemin === "/api/claims" && methode === "GET") {
    return json(await construireClaims(repo));
  }

  if (chemin === "/api/executions" && methode === "GET") {
    return json(await repo.dernieresExecutions(20));
  }

  // -------------------------------------------------------------------------
  // Écriture : session administrateur obligatoire
  // -------------------------------------------------------------------------

  const session = await sessionCourante(requete, env);

  if (chemin === "/api/journal" && methode === "GET") {
    if (!session) return erreur("Connexion administrateur requise.", 401);
    return json(await repo.lireJournal(150));
  }

  if (chemin.startsWith("/api/blesses/") && chemin.endsWith("/date-ir") && methode === "POST") {
    if (!session) return erreur("Connexion administrateur requise.", 401);

    const id = Number(chemin.split("/")[3]);
    if (!Number.isInteger(id) || id <= 0) return erreur("Identifiant de séjour invalide.");

    const corps = (await requete.json().catch(() => null)) as {
      dateIr?: string;
      note?: string;
    } | null;
    const dateIr = corps?.dateIr?.trim() ?? "";

    if (!FORMAT_DATE.test(dateIr)) {
      return erreur("Date attendue au format AAAA-MM-JJ.");
    }
    const aujourdhui = dateDuJour(env.FUSEAU ?? "America/Toronto");
    // Hors-saison, la période courante démarre dans le futur : une date de
    // mise sur IR postérieure à aujourd'hui est donc légitime, tant qu'elle ne
    // dépasse pas le début de la période en cours.
    const periodes = await repo.lirePeriodes();
    const periodeCourante = periodePourInstant(periodes, Date.now());
    const dateMaximale =
      periodeCourante && periodeCourante.dateDebut > aujourdhui
        ? periodeCourante.dateDebut
        : aujourdhui;

    if (dateIr > dateMaximale) {
      return erreur(
        `La date de mise sur la liste des blessés ne peut pas dépasser le ${dateMaximale}.`,
      );
    }

    const sejour = await repo.lireSejour(id);
    if (!sejour) return erreur("Séjour introuvable.", 404);

    // Corriger la date décale l'échéance : si le séjour est déjà clos,
    // le verdict d'infraction doit être réévalué.
    const eligibilite = calculerEligibilite(dateIr);
    let premature = false;
    let joursManquants: number | null = null;
    if (sejour.date_retour) {
      const evaluation = evaluerRetour(dateIr, sejour.date_retour);
      premature = evaluation.premature;
      joursManquants = evaluation.joursManquants;
    }

    await repo.corrigerDateIr({
      id,
      dateIr,
      dateEligibilite: eligibilite,
      retourPremature: premature,
      joursManquants,
      admin: session.admin,
      note: corps?.note?.trim() || null,
      maintenant,
    });

    await repo.journaliser({
      admin: session.admin,
      action: "correction-date-ir",
      cible: "sejour_ir",
      cibleId: String(id),
      details: {
        avant: sejour.date_ir,
        apres: dateIr,
        nouvelleEligibilite: eligibilite,
        note: corps?.note ?? null,
      },
      maintenant,
    });

    return json({ ok: true, dateIr, dateEligibilite: eligibilite });
  }

  if (chemin === "/api/statuts" && methode === "POST") {
    if (!session) return erreur("Connexion administrateur requise.", 401);

    const corps = (await requete.json().catch(() => null)) as {
      statutBrut?: string;
      type?: string;
      libelle?: string;
    } | null;

    const statutBrut = corps?.statutBrut?.trim().toUpperCase() ?? "";
    const type = corps?.type?.trim().toUpperCase() as TypeStatut;

    if (!statutBrut) return erreur("Statut brut manquant.");
    if (!TYPES_VALIDES.includes(type)) {
      return erreur(`Type invalide. Valeurs acceptées : ${TYPES_VALIDES.join(", ")}.`);
    }

    await repo.majTypeStatut(
      statutBrut,
      type,
      corps?.libelle?.trim() || null,
      session.admin,
      maintenant,
    );
    await repo.journaliser({
      admin: session.admin,
      action: "mapping-statut",
      cible: "mapping_statuts",
      cibleId: statutBrut,
      details: { type, libelle: corps?.libelle ?? null },
      maintenant,
    });

    return json({ ok: true, statutBrut, type });
  }

  if (chemin === "/api/robot/executer" && methode === "POST") {
    if (!session) return erreur("Connexion administrateur requise.", 401);

    const complet = url.searchParams.get("complet") === "1";
    await repo.journaliser({
      admin: session.admin,
      action: complet ? "robot-execution-complete" : "robot-execution",
      maintenant,
    });

    const bilan = await executerRobot(env, { declencheur: "manuel", complet });
    return json(bilan);
  }

  if (chemin === "/api/claims/echange" && methode === "POST") {
    if (!session) return erreur("Connexion administrateur requise.", 401);

    const corps = (await requete.json().catch(() => null)) as {
      deTeamId?: string;
      versTeamId?: string;
      quantite?: number;
      motif?: string;
    } | null;

    const claims = await construireClaims(repo);
    if (claims.saison === null) {
      return erreur(
        "Le calendrier de la saison n'est pas encore chargé. Lance le robot d'abord.",
      );
    }
    if (!claims.saisonOuverte) {
      return erreur(
        `Le suivi des claims démarre le ${claims.debutSaison}, après le repêchage. ` +
          `Les échanges se saisissent à partir de cette date.`,
      );
    }

    const deTeamId = corps?.deTeamId?.trim() ?? "";
    const versTeamId = corps?.versTeamId?.trim() ?? "";
    const quantite = Number(corps?.quantite ?? 0);
    const source = claims.equipes.find((e) => e.teamId === deTeamId);
    const destination = claims.equipes.find((e) => e.teamId === versTeamId);

    if (!source || !destination) return erreur("Équipe inconnue.");

    const validation = validerEchange({
      deTeamId,
      versTeamId,
      quantite,
      soldeSource: source.solde,
    });
    if (!validation.ok) return erreur(validation.erreur);

    const aujourdhui = dateDuJour(env.FUSEAU ?? "America/Toronto");
    const motif =
      corps?.motif?.trim() ||
      `Échange de claims entre ${source.equipe} et ${destination.equipe}`;

    // Les deux écritures forment une paire : le total de la ligue est conservé.
    await repo.ajouterMouvementClaim({
      teamId: deTeamId,
      saison: claims.saison,
      type: "CEDE",
      quantite: -quantite,
      dateEffet: aujourdhui,
      motif,
      contrepartieTeamId: versTeamId,
      auteur: session.admin,
      maintenant,
    });
    await repo.ajouterMouvementClaim({
      teamId: versTeamId,
      saison: claims.saison,
      type: "RECU",
      quantite,
      dateEffet: aujourdhui,
      motif,
      contrepartieTeamId: deTeamId,
      auteur: session.admin,
      maintenant,
    });

    await repo.journaliser({
      admin: session.admin,
      action: "claims-echange",
      cible: "claims_mouvements",
      details: { de: source.equipe, vers: destination.equipe, quantite, motif },
      maintenant,
    });

    return json({ ok: true });
  }

  if (chemin === "/api/claims/ajustement" && methode === "POST") {
    if (!session) return erreur("Connexion administrateur requise.", 401);

    const corps = (await requete.json().catch(() => null)) as {
      teamId?: string;
      quantite?: number;
      motif?: string;
    } | null;

    const claims = await construireClaims(repo);
    if (claims.saison === null) {
      return erreur(
        "Le calendrier de la saison n'est pas encore chargé. Lance le robot d'abord.",
      );
    }
    if (!claims.saisonOuverte) {
      return erreur(
        `Le suivi des claims démarre le ${claims.debutSaison}, après le repêchage. ` +
          `Les ajustements se saisissent à partir de cette date.`,
      );
    }

    const teamId = corps?.teamId?.trim() ?? "";
    const quantite = Number(corps?.quantite ?? 0);
    const equipe = claims.equipes.find((e) => e.teamId === teamId);

    if (!equipe) return erreur("Équipe inconnue.");
    if (!Number.isInteger(quantite) || quantite === 0) {
      return erreur("L'ajustement doit être un nombre entier non nul (par exemple -1 ou 2).");
    }
    if (!corps?.motif?.trim()) {
      return erreur("Un motif est obligatoire pour un ajustement manuel.");
    }

    await repo.ajouterMouvementClaim({
      teamId,
      saison: claims.saison,
      type: "CORRECTION",
      quantite,
      dateEffet: dateDuJour(env.FUSEAU ?? "America/Toronto"),
      motif: corps.motif.trim(),
      auteur: session.admin,
      maintenant,
    });

    await repo.journaliser({
      admin: session.admin,
      action: "claims-ajustement",
      cible: "claims_mouvements",
      cibleId: teamId,
      details: { equipe: equipe.equipe, quantite, motif: corps.motif.trim() },
      maintenant,
    });

    return json({ ok: true });
  }

  if (chemin.startsWith("/api/claims/mouvement/") && methode === "DELETE") {
    if (!session) return erreur("Connexion administrateur requise.", 401);

    const id = Number(chemin.split("/")[4]);
    if (!Number.isInteger(id) || id <= 0) return erreur("Identifiant invalide.");

    const supprime = await repo.supprimerMouvementClaim(id);
    if (!supprime) return erreur("Mouvement introuvable.", 404);

    await repo.journaliser({
      admin: session.admin,
      action: "claims-suppression",
      cible: "claims_mouvements",
      cibleId: String(id),
      maintenant,
    });

    return json({ ok: true });
  }

  return erreur("Route inconnue.", 404);
}
